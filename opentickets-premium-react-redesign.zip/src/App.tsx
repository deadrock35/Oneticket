import { useEffect } from "react";
import { ArrowRight, Compass, Ticket } from "lucide-react";
import { AppProvider } from "./context/AppContext";
import { RouterProvider, useRouter, Link } from "./lib/router";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";
import { Toast } from "./components/overlays/Toast";
import { SearchOverlay } from "./components/overlays/SearchOverlay";
import { CartDrawer } from "./components/overlays/CartDrawer";
import { AuthModal } from "./components/overlays/AuthModal";
import { CheckoutModal } from "./components/overlays/CheckoutModal";
import { HomePage } from "./pages/HomePage";
import { SearchPage } from "./pages/SearchPage";
import { EventDetailPage } from "./pages/EventDetailPage";
import { FaqsPage } from "./pages/FaqsPage";
import { getEvent } from "./data/events";

const PAGE_TITLES: Record<string, string> = {
  "/": "OpenTickets — Live moments, beautifully booked",
  "/events": "All events — OpenTickets",
  "/search": "Search live events — OpenTickets",
  "/faqs": "Help & FAQs — OpenTickets",
};

function NotFoundPage() {
  return (
    <section className="relative flex min-h-[78vh] items-center overflow-hidden pb-16 pt-[130px]">
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[140px]"
        style={{ background: "rgba(228,199,142,0.1)" }}
      />
      <div className="shell relative text-center">
        <span className="eyebrow no-rule justify-center">Off stage</span>
        <p className="mt-3 font-display text-[clamp(6rem,16vw,12rem)] leading-[0.8] tracking-[-0.04em] text-cream/12">404</p>
        <h1 className="-mt-8 text-[clamp(2.6rem,5vw,4rem)] leading-none text-cream sm:-mt-12">
          This page missed <em className="text-gold">the show.</em>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-[0.83rem] font-light leading-relaxed text-mist">
          The link may be old, or the page may have moved. Either way, there&apos;s still a great night waiting for you.
        </p>
        <div className="mt-7 flex flex-col justify-center gap-2.5 sm:flex-row">
          <Link
            to="/events"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[10px] bg-gold px-5 text-[0.72rem] font-bold uppercase tracking-[0.06em] text-ink transition-colors hover:bg-gold-bright"
          >
            <Compass size={15} /> Explore all events
          </Link>
          <Link
            to="/"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[10px] border border-line px-5 text-[0.72rem] font-semibold text-cream transition-colors hover:border-gold/40 hover:text-gold"
          >
            <ArrowRight size={15} className="rotate-180" /> Back home
          </Link>
        </div>
      </div>
    </section>
  );
}

function AppRoutes() {
  const { path } = useRouter();
  const segments = path.split("/").filter(Boolean);
  const isEventDetail = segments[0] === "events" && Boolean(segments[1]);

  useEffect(() => {
    if (isEventDetail) {
      const event = getEvent(segments[1]);
      document.title = event ? `${event.title} — OpenTickets` : PAGE_TITLES["/events"];
      return;
    }
    document.title = PAGE_TITLES[path] ?? "OpenTickets — Live moments, beautifully booked";
  }, [path, isEventDetail, segments]);

  let page: React.ReactNode;
  if (path === "/") page = <HomePage />;
  else if (path === "/events") page = <SearchPage />;
  else if (path === "/search") page = <SearchPage />;
  else if (path === "/faqs") page = <FaqsPage />;
  else if (isEventDetail) page = <EventDetailPage slug={segments[1]} />;
  else page = <NotFoundPage />;

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main id="main" className="flex-1">
        <div key={path} className="page-enter">
          {page}
        </div>
      </main>
      <Footer />
      <SearchOverlay />
      <CartDrawer />
      <AuthModal />
      <CheckoutModal />
      <Toast />
      <a
        href="#main"
        className="fixed left-3 top-3 z-[130] -translate-y-24 rounded-lg bg-gold px-4 py-2 text-[0.7rem] font-bold text-ink transition-transform focus:translate-y-0"
      >
        Skip to content
      </a>
      <span className="sr-only">
        <Ticket size={1} /> OpenTickets South Africa
      </span>
    </div>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AppProvider>
        <AppRoutes />
      </AppProvider>
    </RouterProvider>
  );
}
