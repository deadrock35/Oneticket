import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type AnchorHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from "react";

interface ParsedRoute {
  path: string;
  query: URLSearchParams;
  href: string;
}

interface RouterValue extends ParsedRoute {
  navigate: (to: string, options?: { replace?: boolean }) => void;
  isActive: (path: string) => boolean;
}

const RouterContext = createContext<RouterValue | null>(null);

const parseHash = (rawHash: string): ParsedRoute => {
  const raw = rawHash.replace(/^#/, "") || "/";
  const [pathPart, queryString = ""] = raw.split("?");
  const cleanPath = pathPart.startsWith("/") ? pathPart : `/${pathPart}`;
  const path = cleanPath.length > 1 ? cleanPath.replace(/\/+$/, "") : "/";
  return {
    path,
    query: new URLSearchParams(queryString),
    href: raw,
  };
};

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<ParsedRoute>(() => parseHash(window.location.hash));

  useEffect(() => {
    if (!window.location.hash) {
      window.history.replaceState(null, "", "#/");
    }
    const onHashChange = () => {
      setRoute(parseHash(window.location.hash));
      window.scrollTo({ top: 0, behavior: "auto" });
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const navigate = useCallback(
    (to: string, options?: { replace?: boolean }) => {
      const nextHash = `#${to.startsWith("/") ? to : `/${to}`}`;
      if (window.location.hash === nextHash) {
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      if (options?.replace) {
        window.history.replaceState(null, "", nextHash);
        setRoute(parseHash(nextHash));
        window.scrollTo({ top: 0, behavior: "auto" });
      } else {
        window.location.hash = nextHash;
      }
    },
    []
  );

  const value = useMemo<RouterValue>(
    () => ({
      ...route,
      navigate,
      isActive: (path: string) => {
        if (path === "/") return route.path === "/";
        return route.path === path || route.path.startsWith(`${path}/`);
      },
    }),
    [route, navigate]
  );

  return <RouterContext.Provider value={value}>{children}</RouterContext.Provider>;
}

export function useRouter() {
  const context = useContext(RouterContext);
  if (!context) throw new Error("useRouter must be used within RouterProvider");
  return context;
}

interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
  children: ReactNode;
}

export function Link({ to, children, onClick, ...rest }: LinkProps) {
  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(event);
    if (event.defaultPrevented) event.preventDefault();
  };

  return (
    <a href={`#${to}`} onClick={handleClick} {...rest}>
      {children}
    </a>
  );
}
