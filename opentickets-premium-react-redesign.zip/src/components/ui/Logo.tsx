import { cn } from "../../utils/cn";

export function Logo({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("group inline-flex items-center gap-2.5", className)}>
      <span className="relative grid size-9 shrink-0 place-items-center overflow-hidden rounded-[11px] border border-gold/40 bg-gradient-to-br from-gold-bright via-gold to-gold-deep text-ink shadow-[0_8px_24px_-10px_rgba(228,199,142,0.65)] transition-transform duration-500 group-hover:rotate-[-5deg]">
        <svg viewBox="0 0 32 32" className="size-[23px]" fill="none" aria-hidden="true">
          <path
            d="M7.4 9.8a2 2 0 0 1 2-2h13.2a2 2 0 0 1 2 2v2.05a2.3 2.3 0 0 0 0 4.3v2.05a2.3 2.3 0 0 0 0 4.3v.7a2 2 0 0 1-2 2H9.4a2 2 0 0 1-2-2v-.7a2.3 2.3 0 0 0 0-4.3v-2.05a2.3 2.3 0 0 0 0-4.3V9.8Z"
            fill="currentColor"
            opacity="0.95"
          />
          <path
            d="M15 10.3v2.1M15 15.3v1.5M15 19.7v2.1"
            stroke="#f5f0e6"
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.75"
          />
          <path d="M18.2 13.1h3.2M18.2 16h2.6M18.2 18.9h3.2" stroke="#0b111b" strokeWidth="1.2" strokeLinecap="round" opacity="0.55" />
        </svg>
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-sans text-[1.02rem] font-extrabold tracking-[-0.035em] text-cream">
            Open<span className="text-gold">Tickets</span>
          </span>
          <span className="mt-[4px] font-sans text-[0.45rem] font-bold uppercase tracking-[0.31em] text-mist-dim">
            Live, unlocked
          </span>
        </span>
      )}
    </span>
  );
}
