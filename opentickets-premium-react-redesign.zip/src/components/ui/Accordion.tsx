import { useId, useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "../../utils/cn";

export interface AccordionItem {
  q: string;
  a: string;
}

interface AccordionProps {
  items: AccordionItem[];
  defaultOpen?: number | null;
  className?: string;
  highlight?: string;
}

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function Highlights({ text, term }: { text: string; term?: string }) {
  if (!term || term.trim().length < 2) return <>{text}</>;
  const parts = text.split(new RegExp(`(${escapeRegExp(term.trim())})`, "gi"));
  return (
    <>
      {parts.map((part, index) =>
        part.toLowerCase() === term.trim().toLowerCase() ? (
          <mark key={index} className="rounded-sm bg-gold/25 px-0.5 text-gold-bright">
            {part}
          </mark>
        ) : (
          <span key={index}>{part}</span>
        )
      )}
    </>
  );
}

export function Accordion({ items, defaultOpen = 0, className, highlight }: AccordionProps) {
  const [open, setOpen] = useState<number | null>(defaultOpen);
  const baseId = useId();

  if (items.length === 0) return null;

  return (
    <div className={cn("divide-y divide-line-soft border-y border-line-soft", className)}>
      {items.map((item, index) => {
        const isOpen = open === index;
        return (
          <div key={`${item.q}-${index}`} className="group">
            <h3>
              <button
                type="button"
                id={`${baseId}-trigger-${index}`}
                aria-expanded={isOpen}
                aria-controls={`${baseId}-panel-${index}`}
                onClick={() => setOpen(isOpen ? null : index)}
                className="flex w-full items-start justify-between gap-5 py-5 text-left transition-colors hover:text-gold-bright sm:py-6"
              >
                <span className="pr-2 font-sans text-[0.93rem] font-semibold leading-relaxed tracking-[-0.01em] text-cream sm:text-[1rem]">
                  <Highlights text={item.q} term={highlight} />
                </span>
                <span
                  className={cn(
                    "mt-0.5 grid size-7 shrink-0 place-items-center rounded-full border transition-all duration-300",
                    isOpen ? "rotate-45 border-gold bg-gold text-ink" : "border-line text-gold group-hover:border-gold/50"
                  )}
                >
                  <Plus size={14} strokeWidth={2} />
                </span>
              </button>
            </h3>
            <div
              id={`${baseId}-panel-${index}`}
              role="region"
              aria-labelledby={`${baseId}-trigger-${index}`}
              className={cn(
                "grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
                isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
              )}
            >
              <div className="overflow-hidden">
                <p className="max-w-2xl pb-6 pr-8 text-[0.88rem] font-light leading-[1.85] text-mist">
                  <Highlights text={item.a} term={highlight} />
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
