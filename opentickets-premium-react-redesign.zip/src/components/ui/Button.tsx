import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import { cn } from "../../utils/cn";

type Variant = "primary" | "secondary" | "ghost" | "outline" | "dark";
type Size = "sm" | "md" | "lg";

const variants: Record<Variant, string> = {
  primary:
    "bg-gold text-ink hover:bg-gold-bright shadow-[0_10px_30px_-12px_rgba(228,199,142,0.55)] hover:shadow-[0_14px_38px_-12px_rgba(228,199,142,0.65)]",
  secondary:
    "glass text-cream hover:border-gold/40 hover:bg-raised/80",
  ghost:
    "text-cream/80 hover:text-cream hover:bg-white/[0.06] border border-transparent",
  outline:
    "border border-gold/45 text-gold hover:bg-gold/10 hover:border-gold/70",
  dark:
    "bg-ink text-cream border border-white/10 hover:border-gold/35 hover:bg-ink-deep",
};

const sizes: Record<Size, string> = {
  sm: "min-h-9 px-3.5 py-2 text-[0.72rem] gap-1.5",
  md: "min-h-11 px-5 py-2.5 text-[0.8rem] gap-2",
  lg: "min-h-[52px] px-7 py-3.5 text-[0.84rem] gap-2.5",
};

export function buttonStyles({
  variant = "primary",
  size = "md",
  className,
}: {
  variant?: Variant;
  size?: Size;
  className?: string;
} = {}) {
  return cn(
    "inline-flex select-none items-center justify-center rounded-[10px] font-sans font-bold tracking-[0.045em] transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:pointer-events-none disabled:opacity-50",
    variants[variant],
    sizes[size],
    className
  );
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  children: ReactNode;
}

export function Button({
  variant = "primary",
  size = "md",
  loading = false,
  className,
  children,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={buttonStyles({ variant, size, className })}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <LoaderCircle size={17} className="animate-spin" aria-hidden="true" /> : null}
      {children}
    </button>
  );
}
