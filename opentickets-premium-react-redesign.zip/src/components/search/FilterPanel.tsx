import { CalendarDays, ChevronDown, MapPin, RotateCcw, SlidersHorizontal, Tag, Ticket } from "lucide-react";
import { CATEGORIES, EVENTS, VENUES, type Category } from "../../data/events";
import { formatZAR } from "../../data/events";
import { cn } from "../../utils/cn";

const SEASONS = [
  { label: "Any time", value: "any", from: "", to: "" },
  { label: "Late 2026", value: "2026", from: "2026-10-27", to: "2026-12-31" },
  { label: "Early 2027", value: "2027-q1", from: "2027-01-01", to: "2027-03-31" },
  { label: "Mid 2027", value: "2027-q2", from: "2027-04-01", to: "2027-06-30" },
  { label: "Spring 2027", value: "2027-q3", from: "2027-07-01", to: "2027-09-30" },
  { label: "Late 2027", value: "2027-q4", from: "2027-10-01", to: "2027-12-31" },
];

export interface FilterState {
  categories: Category[];
  city: string;
  venue: string;
  dateFrom: string;
  dateTo: string;
  season: string;
  maxPrice: number;
}

interface FilterPanelProps {
  filters: FilterState;
  onChange: (next: Partial<FilterState>) => void;
  onReset: () => void;
  onSeason: (value: string) => void;
  onToggleCategory: (category: Category) => void;
  resultCount: number;
  className?: string;
}

const CITIES = ["All cities", ...Array.from(new Set(Object.values(VENUES).map((venue) => venue.city))).sort()];
const VENUE_OPTIONS = Object.values(VENUES).sort((a, b) => a.name.localeCompare(b.name));

export function FilterPanel({
  filters,
  onChange,
  onReset,
  onSeason,
  onToggleCategory,
  resultCount,
  className,
}: FilterPanelProps) {
  return (
    <div className={cn("rounded-2xl border border-line bg-surface/40 p-5", className)}>
      <div className="flex items-center justify-between border-b border-line-soft pb-4">
        <h2 className="inline-flex items-center gap-2 font-sans text-[0.72rem] font-bold uppercase tracking-[0.14em] text-cream">
          <SlidersHorizontal size={14} className="text-gold" /> Filter events
        </h2>
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1 text-[0.62rem] font-semibold text-mist transition-colors hover:text-gold"
        >
          <RotateCcw size={10} /> Reset
        </button>
      </div>

      <div className="mt-5">
        <label htmlFor="filter-city" className="mb-2 flex items-center gap-1.5 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist">
          <MapPin size={10} className="text-gold/80" /> City
        </label>
        <div className="relative">
          <select
            id="filter-city"
            value={filters.city}
            onChange={(event) => onChange({ city: event.target.value })}
            className="field py-2.5 text-[0.75rem]"
          >
            {CITIES.map((city) => (
              <option key={city} value={city} className="bg-raised">
                {city}
              </option>
            ))}
          </select>
          <ChevronDown size={12} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
        </div>
      </div>

      <div className="mt-5 border-t border-line-soft pt-5">
        <div className="mb-2 flex items-center gap-1.5 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist">
          <CalendarDays size={10} className="text-gold/80" /> Date range
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="sr-only" htmlFor="date-from">
            From date
          </label>
          <input
            id="date-from"
            type="date"
            value={filters.dateFrom}
            onChange={(event) => onChange({ dateFrom: event.target.value, season: "custom" })}
            className="field px-2 py-2 text-[0.66rem]"
          />
          <label className="sr-only" htmlFor="date-to">
            To date
          </label>
          <input
            id="date-to"
            type="date"
            value={filters.dateTo}
            min={filters.dateFrom || undefined}
            onChange={(event) => onChange({ dateTo: event.target.value, season: "custom" })}
            className="field px-2 py-2 text-[0.66rem]"
          />
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {SEASONS.map((season) => (
            <button
              key={season.value}
              type="button"
              onClick={() => onSeason(season.value)}
              className={cn(
                "rounded-full border px-2 py-1 text-[0.57rem] font-semibold transition-all",
                filters.season === season.value
                  ? "border-gold/60 bg-gold/12 text-gold"
                  : "border-line-soft text-mist hover:border-line-strong hover:text-cream"
              )}
            >
              {season.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 border-t border-line-soft pt-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist">
            <Tag size={10} className="text-gold/80" /> Maximum price
          </span>
          <span className="text-[0.68rem] font-semibold text-gold">
            {filters.maxPrice >= 3500 ? "Any" : `≤ ${formatZAR(filters.maxPrice)}`}
          </span>
        </div>
        <input
          type="range"
          min={250}
          max={3500}
          step={50}
          value={filters.maxPrice}
          onChange={(event) => onChange({ maxPrice: Number(event.target.value) })}
          aria-label="Maximum ticket price"
          className="range-gold"
          style={{ "--pct": `${((filters.maxPrice - 250) / (3500 - 250)) * 100}%` } as React.CSSProperties}
        />
        <div className="mt-2 flex justify-between text-[0.55rem] text-mist-dim">
          <span>R250</span>
          <span>R3,500+</span>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {[500, 1000, 2000, 3500].map((price) => (
            <button
              key={price}
              type="button"
              onClick={() => onChange({ maxPrice: price })}
              className={cn(
                "rounded-md border px-2 py-1 text-[0.56rem] font-semibold transition-all",
                filters.maxPrice === price
                  ? "border-gold/50 bg-gold/10 text-gold"
                  : "border-line-soft text-mist hover:text-cream"
              )}
            >
              {price === 3500 ? "Any" : `R${price}`}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 border-t border-line-soft pt-5">
        <div className="mb-3 flex items-center gap-1.5 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist">
          <Ticket size={10} className="text-gold/80" /> Category
        </div>
        <div className="space-y-2">
          {CATEGORIES.map((category) => {
            const checked = filters.categories.includes(category.label);
            const count = EVENTS.filter((event) => event.category === category.label).length;
            return (
              <label
                key={category.label}
                className="group flex cursor-pointer items-center justify-between text-[0.73rem] text-cream/80 transition-colors hover:text-cream"
              >
                <span className="inline-flex items-center gap-2">
                  <span
                    className={cn(
                      "grid size-4 place-items-center rounded-[4px] border transition-all",
                      checked ? "border-gold bg-gold text-ink" : "border-line-strong bg-transparent text-transparent"
                    )}
                  >
                    <svg viewBox="0 0 12 12" className="size-2.5" fill="none" aria-hidden="true">
                      <path d="m2 6 2.5 2.5L10 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => onToggleCategory(category.label)}
                    className="sr-only"
                  />
                  {category.label}
                </span>
                <span className="text-[0.6rem] text-mist-dim">{count}</span>
              </label>
            );
          })}
        </div>
      </div>

      <div className="mt-5 border-t border-line-soft pt-5">
        <label htmlFor="filter-venue" className="mb-2 flex items-center gap-1.5 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist">
          <MapPin size={10} className="text-gold/80" /> Venue
        </label>
        <div className="relative">
          <select
            id="filter-venue"
            value={filters.venue}
            onChange={(event) => onChange({ venue: event.target.value })}
            className="field py-2.5 text-[0.75rem]"
          >
            <option value="All venues" className="bg-raised">
              All venues
            </option>
            {VENUE_OPTIONS.map((venue) => (
              <option key={venue.key} value={venue.name} className="bg-raised">
                {venue.name}
              </option>
            ))}
          </select>
          <ChevronDown size={12} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
        </div>
      </div>

      <div className="mt-5 rounded-lg border border-gold/15 bg-gold/[0.04] px-3 py-2.5">
        <p className="text-[0.57rem] font-bold uppercase tracking-[0.1em] text-gold">{resultCount} events match</p>
        <p className="mt-1 text-[0.62rem] font-light leading-relaxed text-mist">Prices include booking fees and VAT.</p>
      </div>
    </div>
  );
}

export { SEASONS, CITIES };
