import { ArrowUpRight, CalendarDays, Heart, MapPin, Ticket } from "lucide-react";
import { useApp } from "../../context/AppContext";
import {
  eventImage,
  formatEventDate,
  formatZAR,
  getDateBadge,
  getVenue,
  type EventItem,
} from "../../data/events";
import { Link } from "../../lib/router";

export function EventListItem({ event }: { event: EventItem }) {
  const { saved, toggleSaved } = useApp();
  const isSaved = saved.includes(event.slug);
  const venue = getVenue(event);
  const badge = getDateBadge(event.date);

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-line-soft bg-surface/45 transition-all duration-500 hover:border-gold/25 hover:bg-surface/65 sm:min-h-[218px] sm:flex-row">
      <Link
        to={`/events/${event.slug}`}
        aria-label={`View ${event.title}`}
        className="relative block shrink-0 overflow-hidden sm:w-[228px] lg:w-[248px]"
      >
        <img
          src={eventImage(event, "card")}
          alt={`${event.title} — ${event.artist}`}
          loading="lazy"
          className="h-[190px] w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04] sm:h-full"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent sm:bg-gradient-to-r" />
        <div className="absolute left-3.5 top-3.5 overflow-hidden rounded-[8px] border border-white/15 bg-cream text-center text-ink">
          <span className="block px-2.5 pb-0.5 pt-1 font-display text-lg leading-none">{badge.day}</span>
          <span className="block bg-ink/90 px-2.5 pb-0.5 pt-0.5 text-[0.47rem] font-extrabold tracking-[0.16em] text-gold">
            {badge.month}
          </span>
        </div>
        <span className="absolute bottom-3 left-3.5 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-ink/55 px-2.5 py-1 text-[0.54rem] font-bold uppercase tracking-[0.13em] text-cream backdrop-blur-md">
          <span
            className={`size-1.5 rounded-full ${
              event.category === "Music"
                ? "bg-gold"
                : event.category === "Comedy"
                  ? "bg-coral"
                  : event.category === "Theatre"
                    ? "bg-violet"
                    : "bg-sage"
            }`}
          />
          {event.category}
        </span>
      </Link>

      <div className="flex min-w-0 flex-1 flex-col p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[0.6rem] font-semibold uppercase tracking-[0.1em] text-mist-dim">
              <span className="inline-flex items-center gap-1">
                <CalendarDays size={10} className="text-gold/80" /> {formatEventDate(event.date)} · {event.time}
              </span>
              {event.badge && (
                <span className="rounded-full border border-gold/20 bg-gold/[0.06] px-2 py-0.5 text-[0.5rem] tracking-[0.1em] text-gold">
                  {event.badge}
                </span>
              )}
            </div>
            <h3 className="mt-1.5 font-display text-[1.55rem] leading-[1.04] tracking-[-0.015em] text-cream transition-colors group-hover:text-gold-bright">
              <Link to={`/events/${event.slug}`}>{event.title}</Link>
            </h3>
            <p className="mt-1 text-[0.72rem] font-light text-mist">{event.artist}</p>
          </div>
          <button
            type="button"
            onClick={() => toggleSaved(event.slug)}
            aria-label={isSaved ? `Remove ${event.title} from saved events` : `Save ${event.title}`}
            aria-pressed={isSaved}
            className={`grid size-8 shrink-0 place-items-center rounded-full border transition-all ${
              isSaved
                ? "border-gold/50 bg-gold text-ink"
                : "border-line text-mist hover:border-gold/40 hover:text-gold"
            }`}
          >
            <Heart size={13} fill={isSaved ? "currentColor" : "none"} />
          </button>
        </div>

        <p className="mt-2.5 line-clamp-2 max-w-xl text-[0.73rem] font-light leading-relaxed text-mist/90">
          {event.tagline} {event.description[0].slice(0, 145)}…
        </p>

        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[0.64rem] text-mist">
          <span className="inline-flex min-w-0 items-center gap-1">
            <MapPin size={10} className="shrink-0 text-gold/80" />
            <span className="truncate">
              {venue.name}, {venue.city}
            </span>
          </span>
          <span className="inline-flex items-center gap-1">
            <Ticket size={10} className="text-gold/80" /> {event.tiers.length} ticket types
          </span>
          <span className={event.status === "Few left" ? "font-semibold text-coral" : "text-mist-dim"}>{event.status}</span>
        </div>

        <div className="mt-auto flex items-end justify-between gap-3 border-t border-line-soft pt-3">
          <div>
            <span className="text-[0.53rem] font-bold uppercase tracking-[0.14em] text-mist-dim">From </span>
            <span className="text-[0.92rem] font-bold text-gold">{formatZAR(event.priceFrom)}</span>
            <span className="ml-1 text-[0.54rem] text-mist-dim">incl. fees</span>
          </div>
          <Link
            to={`/events/${event.slug}`}
            className="inline-flex items-center gap-1.5 rounded-lg border border-gold/30 px-3 py-2 text-[0.62rem] font-bold uppercase tracking-[0.08em] text-gold transition-all hover:bg-gold hover:text-ink"
          >
            View seats <ArrowUpRight size={12} />
          </Link>
        </div>
      </div>
    </article>
  );
}
