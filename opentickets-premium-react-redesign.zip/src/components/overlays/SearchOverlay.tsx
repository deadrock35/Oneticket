import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, ArrowUpRight, Clock3, MapPin, Search, Sparkles, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { EVENTS, eventImage, formatShortDate, formatZAR, getVenue } from "../../data/events";
import { Link, useRouter } from "../../lib/router";

const QUICK_SEARCHES = ["Amapiano", "Comedy", "Cape Town", "Festivals", "Theatre"];

export function SearchOverlay() {
  const { overlay, closeOverlay } = useApp();
  const { navigate } = useRouter();
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const open = overlay === "search";

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => inputRef.current?.focus(), 80);
    return () => window.clearTimeout(timer);
  }, [open]);

  const results = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return [];
    return EVENTS.filter((event) => {
      const venue = getVenue(event);
      return [event.title, event.artist, event.category, venue.city, venue.name, event.tagline]
        .join(" ")
        .toLowerCase()
        .includes(term);
    }).slice(0, 5);
  }, [query]);

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    navigate(`/search${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ""}`);
    closeOverlay();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[85] flex justify-center bg-ink/78 backdrop-blur-md animate-overlay" onClick={closeOverlay}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Search OpenTickets"
        onClick={(event) => event.stopPropagation()}
        className="mt-0 h-fit max-h-[100dvh] w-full overflow-y-auto border-b border-line bg-midnight/95 shadow-2xl backdrop-blur-2xl sm:mt-[8vh] sm:max-h-[82vh] sm:max-w-3xl sm:rounded-3xl sm:border"
      >
        <div className="sticky top-0 z-10 border-b border-line-soft bg-midnight/95 px-4 pb-4 pt-4 backdrop-blur-xl sm:px-6 sm:pt-5">
          <div className="mb-4 flex items-center justify-between">
            <span className="eyebrow">Discover something extraordinary</span>
            <button
              type="button"
              onClick={closeOverlay}
              aria-label="Close search"
              className="grid size-8 place-items-center rounded-full border border-line text-mist transition-all hover:border-gold/40 hover:text-cream"
            >
              <X size={15} />
            </button>
          </div>
          <form onSubmit={submit} className="relative">
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gold" aria-hidden="true" />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search events, artists, venues or cities"
              aria-label="Search events, artists, venues or cities"
              className="field min-h-[58px] rounded-xl border-line bg-ink/65 pl-12 pr-24 text-base text-cream placeholder:text-mist-dim"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 inline-flex h-11 -translate-y-1/2 items-center gap-1.5 rounded-lg bg-gold px-4 text-[0.7rem] font-bold tracking-[0.04em] text-ink transition-colors hover:bg-gold-bright"
            >
              Search <ArrowRight size={14} />
            </button>
          </form>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-[0.6rem] font-bold uppercase tracking-[0.14em] text-mist-dim">Try</span>
            {QUICK_SEARCHES.map((term) => (
              <button
                key={term}
                type="button"
                onClick={() => setQuery(term)}
                className="rounded-full border border-line-soft bg-white/[0.035] px-2.5 py-1 text-[0.66rem] text-mist transition-colors hover:border-gold/35 hover:text-gold"
              >
                {term}
              </button>
            ))}
          </div>
        </div>

        <div className="p-4 sm:p-6">
          {query.trim().length > 0 ? (
            <>
              <div className="mb-3 flex items-center justify-between">
                <p className="text-[0.63rem] font-bold uppercase tracking-[0.16em] text-mist-dim">
                  {results.length} result{results.length === 1 ? "" : "s"} for “{query.trim()}”
                </p>
                <button onClick={submit} className="inline-flex items-center gap-1 text-[0.68rem] font-semibold text-gold">
                  View all <ArrowUpRight size={12} />
                </button>
              </div>
              {results.length ? (
                <div className="space-y-1.5">
                  {results.map((event) => {
                    const venue = getVenue(event);
                    return (
                      <Link
                        key={event.slug}
                        to={`/events/${event.slug}`}
                        onClick={closeOverlay}
                        className="group flex items-center gap-3.5 rounded-xl border border-transparent p-2 transition-all hover:border-line-soft hover:bg-white/[0.035]"
                      >
                        <img
                          src={eventImage(event, "card")}
                          alt=""
                          className="h-[66px] w-[58px] shrink-0 rounded-lg object-cover"
                        />
                        <span className="min-w-0 flex-1">
                          <span className="block text-[0.58rem] font-bold uppercase tracking-[0.16em] text-gold">
                            {event.category}
                          </span>
                          <span className="mt-0.5 block truncate font-display text-xl text-cream group-hover:text-gold-bright">
                            {event.title}
                          </span>
                          <span className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[0.65rem] text-mist">
                            <span className="inline-flex items-center gap-1">
                              <Clock3 size={10} /> {formatShortDate(event.date)} · {event.time}
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <MapPin size={10} /> {venue.city}
                            </span>
                          </span>
                        </span>
                        <span className="hidden text-right sm:block">
                          <span className="block text-[0.55rem] uppercase tracking-[0.1em] text-mist-dim">From</span>
                          <span className="font-semibold text-gold">{formatZAR(event.priceFrom)}</span>
                        </span>
                        <ArrowUpRight size={15} className="shrink-0 text-mist-dim transition-colors group-hover:text-gold" />
                      </Link>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-xl border border-line-soft bg-surface/40 px-5 py-10 text-center">
                  <Sparkles size={22} className="mx-auto text-gold/60" />
                  <p className="mt-3 font-display text-2xl text-cream">Nothing matched that one.</p>
                  <p className="mt-1.5 text-[0.76rem] font-light text-mist">
                    Try an artist, city or category — or explore everything that&apos;s on.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      navigate("/events");
                      closeOverlay();
                    }}
                    className="mt-4 text-[0.7rem] font-bold uppercase tracking-[0.12em] text-gold"
                  >
                    Browse all events →
                  </button>
                </div>
              )}
            </>
          ) : (
            <>
              <p className="mb-3 text-[0.63rem] font-bold uppercase tracking-[0.16em] text-mist-dim">Trending right now</p>
              <div className="grid gap-2 sm:grid-cols-2">
                {EVENTS.filter((event) => event.trending)
                  .slice(0, 4)
                  .map((event) => (
                    <Link
                      key={event.slug}
                      to={`/events/${event.slug}`}
                      onClick={closeOverlay}
                      className="group flex items-center gap-3 rounded-xl border border-line-soft bg-surface/40 p-2.5 transition-all hover:border-gold/30 hover:bg-raised"
                    >
                      <img src={eventImage(event, "card")} alt="" className="h-14 w-12 rounded-lg object-cover" />
                      <span className="min-w-0">
                        <span className="block truncate font-sans text-[0.8rem] font-semibold text-cream group-hover:text-gold-bright">
                          {event.title}
                        </span>
                        <span className="mt-0.5 block text-[0.62rem] text-mist">
                          {getVenue(event).city} · From {formatZAR(event.priceFrom)}
                        </span>
                      </span>
                    </Link>
                  ))}
              </div>
              <p className="mt-5 border-t border-line-soft pt-4 text-[0.67rem] font-light leading-relaxed text-mist-dim">
                Tip: press <kbd className="rounded border border-line px-1 py-0.5 font-sans text-[0.6rem] text-mist">Esc</kbd> to
                close, or search for a venue like “Kirstenbosch”.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
