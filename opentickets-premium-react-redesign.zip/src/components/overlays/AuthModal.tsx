import { useState } from "react";
import { ArrowRight, Check, Eye, EyeOff, Heart, LockKeyhole, Mail, ShieldCheck, Sparkles, Ticket, UserRound, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { getEvent, eventImage, formatShortDate, formatZAR } from "../../data/events";
import { Link } from "../../lib/router";
import { Button } from "../ui/Button";
import { Logo } from "../ui/Logo";

export function AuthModal() {
  const { overlay, closeOverlay, user, signIn, signOut, saved, orders, notify } = useApp();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"tickets" | "saved">("tickets");

  if (overlay !== "auth") return null;

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (mode === "signup" && name.trim().length < 2) nextErrors.name = "Please tell us your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) nextErrors.email = "Enter a valid email address.";
    if (password.length < 6) nextErrors.password = "Use at least 6 characters.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setLoading(true);
    window.setTimeout(() => {
      const firstName = name.trim() || email.split("@")[0].replace(/[._-]/g, " ");
      signIn({
        name: firstName.replace(/\b\w/g, (character) => character.toUpperCase()),
        email: email.trim(),
      });
      setLoading(false);
    }, 650);
  };

  const savedEvents = saved.map((slug) => getEvent(slug)).filter((event) => event !== undefined);

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center overflow-y-auto bg-ink/80 p-4 backdrop-blur-md animate-overlay"
      onClick={closeOverlay}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={user ? "Your OpenTickets account" : "Sign in to OpenTickets"}
        onClick={(event) => event.stopPropagation()}
        className="animate-modal relative my-auto w-full max-w-[880px] overflow-hidden rounded-3xl border border-line bg-midnight shadow-2xl"
      >
        <button
          type="button"
          onClick={closeOverlay}
          aria-label="Close"
          className="absolute right-4 top-4 z-20 grid size-8 place-items-center rounded-full border border-line bg-ink/50 text-mist transition-colors hover:border-gold/40 hover:text-cream"
        >
          <X size={15} />
        </button>

        {user ? (
          <div>
            <div className="border-b border-line-soft bg-surface/35 px-6 py-6 sm:px-8">
              <span className="eyebrow">Your OpenTickets</span>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <span className="grid size-12 place-items-center rounded-full border border-gold/40 bg-gold/15 font-sans text-sm font-extrabold uppercase text-gold-bright">
                    {user.name
                      .split(" ")
                      .map((part) => part[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                  <div>
                    <h2 className="font-display text-[2rem] leading-none text-cream">Hello, {user.name.split(" ")[0]}.</h2>
                    <p className="mt-1 text-[0.74rem] text-mist">{user.email}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={signOut}
                  className="rounded-lg border border-line px-3 py-2 text-[0.65rem] font-semibold uppercase tracking-[0.1em] text-mist transition-colors hover:border-coral/40 hover:text-coral"
                >
                  Sign out
                </button>
              </div>
            </div>

            <div className="grid gap-0 md:grid-cols-[0.72fr_1.28fr]">
              <div className="border-b border-line-soft p-6 md:border-b-0 md:border-r sm:p-8">
                <div className="rounded-xl border border-line-soft bg-ink/30 p-4">
                  <ShieldCheck size={19} className="text-gold" />
                  <p className="mt-3 font-sans text-[0.77rem] font-semibold text-cream">You&apos;re all set.</p>
                  <p className="mt-1 text-[0.68rem] font-light leading-relaxed text-mist">
                    Your e-tickets and saved events live here. Show your QR code at the door — no printing required.
                  </p>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-2.5">
                  <div className="rounded-xl border border-line-soft p-3">
                    <p className="font-display text-2xl text-gold">{orders.length}</p>
                    <p className="mt-0.5 text-[0.6rem] uppercase tracking-[0.12em] text-mist-dim">Orders</p>
                  </div>
                  <div className="rounded-xl border border-line-soft p-3">
                    <p className="font-display text-2xl text-gold">{saved.length}</p>
                    <p className="mt-0.5 text-[0.6rem] uppercase tracking-[0.12em] text-mist-dim">Saved</p>
                  </div>
                </div>
                <p className="mt-5 flex items-start gap-1.5 text-[0.62rem] font-light leading-relaxed text-mist-dim">
                  <LockKeyhole size={11} className="mt-0.5 shrink-0" /> Your account is protected with secure sign-in.
                </p>
              </div>

              <div className="p-6 sm:p-8">
                <div className="flex gap-1 border-b border-line-soft">
                  {[
                    { id: "tickets", label: "My tickets", icon: Ticket },
                    { id: "saved", label: "Saved events", icon: Heart },
                  ].map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setTab(id as "tickets" | "saved")}
                      className={`relative inline-flex items-center gap-1.5 px-3 pb-3 pt-1 text-[0.71rem] font-semibold transition-colors ${
                        tab === id ? "text-cream" : "text-mist hover:text-cream"
                      }`}
                    >
                      <Icon size={13} /> {label}
                      {tab === id && <span className="absolute inset-x-2 bottom-0 h-px bg-gold" />}
                    </button>
                  ))}
                </div>

                {tab === "tickets" ? (
                  <div className="mt-5 space-y-3">
                    {orders.length === 0 ? (
                      <div className="rounded-xl border border-line-soft px-5 py-8 text-center">
                        <Sparkles size={20} className="mx-auto text-gold/60" />
                        <p className="mt-3 font-display text-xl text-cream">No tickets just yet.</p>
                        <p className="mt-1 text-[0.7rem] font-light text-mist">Your next great night is one click away.</p>
                        <Link
                          to="/events"
                          onClick={closeOverlay}
                          className="mt-3 inline-flex items-center gap-1 text-[0.68rem] font-bold uppercase tracking-[0.1em] text-gold"
                        >
                          Browse events <ArrowRight size={12} />
                        </Link>
                      </div>
                    ) : (
                      orders.slice(0, 3).map((order) => (
                        <div key={order.reference} className="rounded-xl border border-line-soft bg-surface/35 p-3.5">
                          <div className="flex items-center justify-between gap-3">
                            <span className="text-[0.58rem] font-bold uppercase tracking-[0.13em] text-mist-dim">
                              {order.reference}
                            </span>
                            <span className="inline-flex items-center gap-1 rounded-full bg-sage/10 px-2 py-0.5 text-[0.55rem] font-bold uppercase tracking-[0.1em] text-sage">
                              <Check size={9} /> Confirmed
                            </span>
                          </div>
                          {order.items.map((item) => (
                            <div key={item.key} className="mt-2.5 flex items-center justify-between gap-3 border-t border-line-soft pt-2.5">
                              <div className="min-w-0">
                                <p className="truncate text-[0.77rem] font-semibold text-cream">{item.eventTitle}</p>
                                <p className="mt-0.5 text-[0.62rem] text-mist">
                                  {item.quantity} × {item.tierName} · {formatShortDate(item.eventDate)}
                                </p>
                              </div>
                              <span className="shrink-0 text-[0.7rem] font-semibold text-gold">{formatZAR(item.price * item.quantity)}</span>
                            </div>
                          ))}
                          <div className="mt-2.5 flex items-center justify-between border-t border-line-soft pt-2 text-[0.65rem]">
                            <span className="text-mist-dim">Total paid</span>
                            <span className="font-semibold text-cream">{formatZAR(order.total)}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                ) : (
                  <div className="mt-5 space-y-2.5">
                    {savedEvents.length === 0 ? (
                      <div className="rounded-xl border border-line-soft px-5 py-8 text-center">
                        <Heart size={20} className="mx-auto text-gold/60" />
                        <p className="mt-3 font-display text-xl text-cream">Your shortlist is waiting.</p>
                        <p className="mt-1 text-[0.7rem] font-light text-mist">Tap the heart on any event to save it here.</p>
                        <Link
                          to="/events"
                          onClick={closeOverlay}
                          className="mt-3 inline-flex items-center gap-1 text-[0.68rem] font-bold uppercase tracking-[0.1em] text-gold"
                        >
                          Find something <ArrowRight size={12} />
                        </Link>
                      </div>
                    ) : (
                      savedEvents.slice(0, 4).map((event) => (
                        <Link
                          key={event.slug}
                          to={`/events/${event.slug}`}
                          onClick={closeOverlay}
                          className="group flex items-center gap-3 rounded-xl border border-line-soft p-2 transition-all hover:border-gold/30 hover:bg-surface/40"
                        >
                          <img src={eventImage(event, "card")} alt="" className="h-12 w-11 rounded-lg object-cover" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[0.77rem] font-semibold text-cream group-hover:text-gold-bright">
                              {event.title}
                            </span>
                            <span className="mt-0.5 block text-[0.62rem] text-mist">
                              {formatShortDate(event.date)} · From {formatZAR(event.priceFrom)}
                            </span>
                          </span>
                          <ArrowRight size={13} className="text-mist-dim group-hover:text-gold" />
                        </Link>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-[0.9fr_1fr]">
            <div className="relative hidden overflow-hidden border-r border-line-soft bg-surface/40 p-8 md:flex md:flex-col md:justify-between">
              <div
                className="pointer-events-none absolute -left-16 bottom-0 h-64 w-64 rounded-full blur-[80px]"
                style={{ background: "rgba(228,199,142,0.13)" }}
              />
              <div className="relative">
                <Logo />
                <p className="mt-10 font-display text-[2.7rem] leading-[0.98] text-cream">
                  More nights.<br />
                  <em className="text-gold">Less admin.</em>
                </p>
                <p className="mt-4 max-w-[260px] text-[0.78rem] font-light leading-[1.8] text-mist">
                  Save your favourite events, keep every ticket in one place and get first access to new releases.
                </p>
              </div>
              <ul className="relative mt-10 space-y-3">
                {[
                  "Instant mobile tickets, always on hand",
                  "Early access to presales and new tours",
                  "Your shortlist, across every device",
                ].map((benefit) => (
                  <li key={benefit} className="flex items-start gap-2.5 text-[0.72rem] font-light text-cream-muted">
                    <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-gold/15 text-gold">
                      <Check size={9} />
                    </span>
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-6 sm:p-9">
              <span className="eyebrow">{mode === "signin" ? "Welcome back" : "Join the list"}</span>
              <h2 className="mt-3 font-display text-[2.3rem] leading-none text-cream">
                {mode === "signin" ? "Sign in to your night out." : "Create your account."}
              </h2>
              <p className="mt-2 text-[0.74rem] font-light leading-relaxed text-mist">
                {mode === "signin"
                  ? "Access your tickets, saved events and booking history."
                  : "One account for every unforgettable night in South Africa."}
              </p>

              <div className="mt-5 grid grid-cols-2 rounded-lg border border-line-soft bg-ink/30 p-1">
                {(["signin", "signup"] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => {
                      setMode(value);
                      setErrors({});
                    }}
                    className={`rounded-md py-2 text-[0.7rem] font-semibold transition-all ${
                      mode === value ? "bg-gold text-ink" : "text-mist hover:text-cream"
                    }`}
                  >
                    {value === "signin" ? "Sign in" : "Create account"}
                  </button>
                ))}
              </div>

              <form onSubmit={submit} className="mt-5 space-y-4" noValidate>
                {mode === "signup" && (
                  <div>
                    <label htmlFor="auth-name" className="mb-1.5 block text-[0.61rem] font-bold uppercase tracking-[0.13em] text-mist">
                      Full name
                    </label>
                    <div className="relative">
                      <UserRound size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                      <input
                        id="auth-name"
                        value={name}
                        onChange={(event) => setName(event.target.value)}
                        autoComplete="name"
                        className="field pl-10"
                        placeholder="Thandi Mokoena"
                        aria-invalid={Boolean(errors.name)}
                      />
                    </div>
                    {errors.name && <p className="mt-1 text-[0.64rem] text-coral">{errors.name}</p>}
                  </div>
                )}
                <div>
                  <label htmlFor="auth-email" className="mb-1.5 block text-[0.61rem] font-bold uppercase tracking-[0.13em] text-mist">
                    Email address
                  </label>
                  <div className="relative">
                    <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                    <input
                      id="auth-email"
                      type="email"
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                      autoComplete="email"
                      className="field pl-10"
                      placeholder="you@example.co.za"
                      aria-invalid={Boolean(errors.email)}
                    />
                  </div>
                  {errors.email && <p className="mt-1 text-[0.64rem] text-coral">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="auth-password" className="mb-1.5 block text-[0.61rem] font-bold uppercase tracking-[0.13em] text-mist">
                    Password
                  </label>
                  <div className="relative">
                    <LockKeyhole size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                    <input
                      id="auth-password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      autoComplete={mode === "signin" ? "current-password" : "new-password"}
                      className="field pl-10 pr-10"
                      placeholder="At least 6 characters"
                      aria-invalid={Boolean(errors.password)}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((value) => !value)}
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-mist-dim transition-colors hover:text-cream"
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                  {errors.password && <p className="mt-1 text-[0.64rem] text-coral">{errors.password}</p>}
                </div>

                <Button type="submit" size="lg" loading={loading} className="w-full">
                  {loading ? "Signing you in" : mode === "signin" ? "Sign in" : "Create my account"}
                  {!loading && <ArrowRight size={16} />}
                </Button>
              </form>

              <div className="mt-4 flex items-center justify-between gap-3 text-[0.62rem]">
                <button
                  type="button"
                  onClick={() => {
                    closeOverlay();
                    notify("You can complete checkout as a guest.");
                  }}
                  className="text-mist-dim underline-offset-4 transition-colors hover:text-cream hover:underline"
                >
                  Continue as a guest
                </button>
                <span className="inline-flex items-center gap-1 text-mist-dim">
                  <ShieldCheck size={11} /> Secure sign-in
                </span>
              </div>
              <p className="mt-4 border-t border-line-soft pt-3 text-[0.6rem] font-light leading-relaxed text-mist-dim">
                By continuing you agree to our Terms of Use and Privacy Promise. We never share your details, and your
                session stays securely on this device.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
