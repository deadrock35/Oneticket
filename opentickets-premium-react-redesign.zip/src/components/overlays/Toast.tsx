import { Check, X } from "lucide-react";
import { useApp } from "../../context/AppContext";

export function Toast() {
  const { toast, dismissToast } = useApp();
  if (!toast) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="animate-modal fixed left-1/2 top-[78px] z-[72] flex w-[calc(100%-2rem)] max-w-md -translate-x-1/2 items-center gap-3 rounded-xl border border-gold/30 bg-raised/95 px-4 py-3 text-cream shadow-2xl backdrop-blur-xl sm:top-[82px]"
    >
      <span className="grid size-7 shrink-0 place-items-center rounded-full bg-gold/15 text-gold">
        <Check size={14} strokeWidth={2.2} />
      </span>
      <p className="flex-1 text-[0.76rem] font-medium leading-snug">{toast.message}</p>
      <button
        type="button"
        onClick={dismissToast}
        aria-label="Dismiss notification"
        className="grid size-6 shrink-0 place-items-center rounded-full text-mist transition-colors hover:bg-white/10 hover:text-cream"
      >
        <X size={13} />
      </button>
    </div>
  );
}
