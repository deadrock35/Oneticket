import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  CalendarDays,
  Check,
  CreditCard,
  Download,
  LockKeyhole,
  Mail,
  MapPin,
  ShieldCheck,
  Smartphone,
  Ticket,
  X,
} from "lucide-react";
import { useApp, type Order } from "../../context/AppContext";
import { formatShortDate, formatZAR, getEvent, getVenue } from "../../data/events";
import { Button } from "../ui/Button";
import { Logo } from "../ui/Logo";

type PaymentMethod = "card" | "snapscan" | "eft";

const PAYMENT_OPTIONS = [
  { id: "card" as const, label: "Card", detail: "Visa, Mastercard, Amex", icon: CreditCard },
  { id: "snapscan" as const, label: "SnapScan", detail: "Scan & approve", icon: Smartphone },
  { id: "eft" as const, label: "Instant EFT", detail: "All major banks", icon: Building2 },
];

export function CheckoutModal() {
  const { overlay, closeOverlay, cart, cartSubtotal, placeOrder, notify } = useApp();
  const [stage, setStage] = useState<"form" | "success">("form");
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("card");
  const [cardName, setCardName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvc, setCvc] = useState("");
  const [terms, setTerms] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (overlay !== "checkout" && stage === "success") {
      setStage("form");
    }
    if (overlay === "checkout" && cart.length > 0 && stage === "success") {
      setStage("form");
    }
    // Deliberately react only to the overlay and new cart selections.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overlay]);

  const orderSummary = useMemo(() => {
    const items = lastOrder?.items ?? cart;
    const total = lastOrder?.total ?? cartSubtotal;
    return { items, total };
  }, [lastOrder, cart, cartSubtotal]);

  if (overlay !== "checkout") return null;

  const validate = () => {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Enter the lead guest's full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email for your e-tickets.";
    if (phone.replace(/\D/g, "").length < 9) next.phone = "Enter a valid South African mobile number.";
    if (payment === "card") {
      if (cardNumber.replace(/\D/g, "").length !== 16) next.cardNumber = "Enter all 16 digits.";
      if (!/^\d{2}\/\d{2}$/.test(expiry) || Number(expiry.slice(0, 2)) > 12 || Number(expiry.slice(0, 2)) === 0)
        next.expiry = "Use MM/YY.";
      if (cvc.replace(/\D/g, "").length < 3) next.cvc = "Enter the 3-digit CVC.";
      if (cardName.trim().length < 2) next.cardName = "Enter the name on your card.";
    }
    if (!terms) next.terms = "Please accept the ticket terms to continue.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!validate()) return;
    setProcessing(true);
    window.setTimeout(() => {
      const order = placeOrder({ name, email });
      setLastOrder(order);
      setStage("success");
      setProcessing(false);
    }, 1100);
  };

  const downloadCalendar = () => {
    if (!lastOrder) return;
    const stamp = (date: Date) => date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
    const events = lastOrder.items
      .map((item, index) => {
        const eventItem = getEvent(item.eventSlug);
        if (!eventItem) return "";
        const start = new Date(eventItem.date);
        const end = new Date(start.getTime() + 2.5 * 60 * 60 * 1000);
        const venue = getVenue(eventItem);
        return [
          "BEGIN:VEVENT",
          `UID:${lastOrder.reference}-${index}@opentickets.co.za`,
          `DTSTAMP:${stamp(new Date())}`,
          `DTSTART:${stamp(start)}`,
          `DTEND:${stamp(end)}`,
          `SUMMARY:${eventItem.title} — OpenTickets`,
          `LOCATION:${venue.name}, ${venue.address}`,
          `DESCRIPTION:${item.quantity} x ${item.tierName}. Booking ${lastOrder.reference}.`,
          "END:VEVENT",
        ].join("\r\n");
      })
      .join("\r\n");
    const calendar = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//OpenTickets//EN",
      "CALSCALE:GREGORIAN",
      events,
      "END:VCALENDAR",
    ].join("\r\n");
    const blob = new Blob([calendar], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `opentickets-${lastOrder.reference}.ics`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    notify("Calendar invitation downloaded");
  };

  const inputError = (key: string) =>
    errors[key] ? <p className="mt-1 text-[0.63rem] text-coral">{errors[key]}</p> : null;

  return (
    <div
      className="fixed inset-0 z-[95] flex items-start justify-center overflow-y-auto bg-ink/88 p-0 backdrop-blur-md animate-overlay sm:items-center sm:p-5"
      onClick={closeOverlay}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="checkout-title"
        onClick={(event) => event.stopPropagation()}
        className="animate-modal my-0 w-full max-w-[1080px] bg-midnight shadow-2xl sm:my-auto sm:rounded-3xl sm:border sm:border-line"
      >
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-line-soft bg-midnight/95 px-5 py-4 backdrop-blur-xl sm:rounded-t-3xl sm:px-7">
          <div className="flex items-center gap-3.5">
            <Logo compact />
            <span className="hidden h-5 w-px bg-line sm:block" />
            <div className="hidden sm:block">
              <p className="text-[0.55rem] font-bold uppercase tracking-[0.18em] text-gold">Secure checkout</p>
              <p className="mt-0.5 text-[0.7rem] text-mist">A few details and the night is yours.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1.5 text-[0.6rem] text-mist-dim sm:inline-flex">
              <LockKeyhole size={11} /> 256-bit encrypted
            </span>
            <button
              type="button"
              onClick={closeOverlay}
              aria-label="Close checkout"
              className="grid size-8 place-items-center rounded-full border border-line text-mist transition-colors hover:border-gold/40 hover:text-cream"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {stage === "success" && lastOrder ? (
          <div className="px-5 py-8 sm:px-10 sm:py-12">
            <div className="mx-auto max-w-2xl text-center">
              <span className="mx-auto grid size-16 place-items-center rounded-full border border-gold/30 bg-gold/12 text-gold shadow-[0_0_60px_-15px_rgba(228,199,142,0.45)]">
                <Check size={28} strokeWidth={2} />
              </span>
              <span className="eyebrow no-rule mt-5 justify-center text-gold">Booking confirmed · {lastOrder.reference}</span>
              <h2 id="checkout-title" className="mt-3 font-display text-[2.8rem] leading-[0.95] text-cream sm:text-[3.6rem]">
                You&apos;re <em className="text-gold">going.</em>
              </h2>
              <p className="mx-auto mt-3 max-w-md text-[0.82rem] font-light leading-relaxed text-mist">
                Your e-tickets are on their way to <span className="text-cream">{lastOrder.email}</span>. They&apos;re also
                available in your account — no printing needed.
              </p>
            </div>

            <div className="mx-auto mt-8 max-w-2xl overflow-hidden rounded-2xl border border-line bg-surface/45">
              {lastOrder.items.map((item) => {
                const eventItem = getEvent(item.eventSlug);
                const venue = eventItem ? getVenue(eventItem) : null;
                return (
                  <div key={item.key} className="flex gap-4 border-b border-line-soft p-4 last:border-0 sm:p-5">
                    <img src={item.image} alt="" className="h-[92px] w-[76px] rounded-lg object-cover sm:h-[104px] sm:w-[88px]" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[0.56rem] font-bold uppercase tracking-[0.14em] text-gold">{eventItem?.category}</span>
                        <span className="rounded-full border border-sage/25 bg-sage/10 px-2 py-0.5 text-[0.53rem] font-bold uppercase tracking-[0.09em] text-sage">
                          Confirmed
                        </span>
                      </div>
                      <p className="mt-1 truncate font-display text-2xl leading-tight text-cream">{item.eventTitle}</p>
                      <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[0.63rem] text-mist">
                        <span className="inline-flex items-center gap-1">
                          <CalendarDays size={10} className="text-gold/80" /> {formatShortDate(item.eventDate)}
                        </span>
                        {venue && (
                          <span className="inline-flex items-center gap-1">
                            <MapPin size={10} className="text-gold/80" /> {venue.name}, {venue.city}
                          </span>
                        )}
                      </div>
                      <div className="mt-2 flex items-center justify-between gap-2 border-t border-line-soft pt-2">
                        <span className="inline-flex items-center gap-1 text-[0.68rem] text-cream-muted">
                          <Ticket size={11} /> {item.quantity} × {item.tierName}
                        </span>
                        <span className="text-[0.72rem] font-bold text-gold">{formatZAR(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div className="flex items-center justify-between bg-ink/30 px-4 py-3 text-[0.7rem] sm:px-5">
                <span className="text-mist">Total paid</span>
                <span className="font-sans text-[1rem] font-bold text-cream">{formatZAR(lastOrder.total)}</span>
              </div>
            </div>

            <div className="mx-auto mt-6 flex max-w-2xl flex-col justify-center gap-2.5 sm:flex-row">
              <Button onClick={downloadCalendar} size="md">
                <Download size={15} /> Add to calendar
              </Button>
              <Button variant="secondary" size="md" onClick={closeOverlay}>
                Done <ArrowRight size={15} />
              </Button>
            </div>
            <p className="mx-auto mt-4 max-w-2xl text-center text-[0.64rem] font-light text-mist-dim">
              Need to change something? Email support@opentickets.co.za with your booking reference and we&apos;ll take
              care of it.
            </p>
          </div>
        ) : cart.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <Ticket size={28} className="mx-auto text-gold/70" />
            <h2 id="checkout-title" className="mt-4 font-display text-3xl text-cream">Your selection is empty.</h2>
            <p className="mt-2 text-[0.8rem] text-mist">Choose your tickets first, then we&apos;ll bring you back here.</p>
            <Button variant="secondary" onClick={closeOverlay} className="mt-5">
              Back to events
            </Button>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="grid lg:grid-cols-[1.18fr_0.82fr]">
            <div className="p-5 sm:p-7 lg:p-8">
              <button
                type="button"
                onClick={closeOverlay}
                className="mb-5 inline-flex items-center gap-1.5 text-[0.65rem] font-semibold text-mist transition-colors hover:text-gold"
              >
                <ArrowLeft size={13} /> Back to your selection
              </button>
              <h2 id="checkout-title" className="font-display text-[2.3rem] leading-none text-cream sm:text-[2.6rem]">
                Almost there<span className="text-gold">.</span>
              </h2>
              <p className="mt-1.5 text-[0.76rem] font-light text-mist">All fields marked * are required.</p>

              <section className="mt-6">
                <div className="mb-3 flex items-center gap-2">
                  <span className="grid size-5 place-items-center rounded-full bg-gold/15 font-sans text-[0.58rem] font-bold text-gold">1</span>
                  <h3 className="font-sans text-[0.68rem] font-bold uppercase tracking-[0.15em] text-cream">Your details</h3>
                </div>
                <div className="grid gap-3.5 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label htmlFor="co-name" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                      Lead guest full name *
                    </label>
                    <input
                      id="co-name"
                      value={name}
                      onChange={(event) => setName(event.target.value)}
                      autoComplete="name"
                      className="field"
                      placeholder="Thandi Mokoena"
                      aria-invalid={Boolean(errors.name)}
                    />
                    {inputError("name")}
                  </div>
                  <div>
                    <label htmlFor="co-email" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                      Email for e-tickets *
                    </label>
                    <div className="relative">
                      <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                      <input
                        id="co-email"
                        type="email"
                        value={email}
                        onChange={(event) => setEmail(event.target.value)}
                        autoComplete="email"
                        className="field pl-10"
                        placeholder="you@example.co.za"
                        aria-invalid={Boolean(errors.email)}
                      />
                    </div>
                    {inputError("email")}
                  </div>
                  <div>
                    <label htmlFor="co-phone" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                      Mobile number *
                    </label>
                    <input
                      id="co-phone"
                      type="tel"
                      value={phone}
                      onChange={(event) => setPhone(event.target.value)}
                      autoComplete="tel"
                      className="field"
                      placeholder="082 123 4567"
                      aria-invalid={Boolean(errors.phone)}
                    />
                    {inputError("phone")}
                  </div>
                </div>
              </section>

              <section className="mt-6 border-t border-line-soft pt-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="grid size-5 place-items-center rounded-full bg-gold/15 font-sans text-[0.58rem] font-bold text-gold">2</span>
                  <h3 className="font-sans text-[0.68rem] font-bold uppercase tracking-[0.15em] text-cream">Payment</h3>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {PAYMENT_OPTIONS.map(({ id, label, detail, icon: Icon }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setPayment(id)}
                      role="radio"
                      aria-checked={payment === id}
                      className={`rounded-xl border p-2.5 text-left transition-all sm:p-3 ${
                        payment === id
                          ? "border-gold/65 bg-gold/[0.07] shadow-[inset_0_0_0_1px_rgba(228,199,142,0.15)]"
                          : "border-line-soft bg-ink/25 hover:border-line-strong"
                      }`}
                    >
                      <Icon size={15} className={payment === id ? "text-gold" : "text-mist"} />
                      <span className="mt-2 block text-[0.67rem] font-semibold text-cream">{label}</span>
                      <span className="mt-0.5 block text-[0.54rem] text-mist-dim">{detail}</span>
                    </button>
                  ))}
                </div>

                {payment === "card" ? (
                  <div className="mt-4 grid gap-3.5 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <label htmlFor="co-card-name" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                        Name on card *
                      </label>
                      <input
                        id="co-card-name"
                        value={cardName}
                        onChange={(event) => setCardName(event.target.value)}
                        autoComplete="cc-name"
                        className="field"
                        placeholder="T Mokoena"
                        aria-invalid={Boolean(errors.cardName)}
                      />
                      {inputError("cardName")}
                    </div>
                    <div className="sm:col-span-2">
                      <label htmlFor="co-card-number" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                        Card number *
                      </label>
                      <div className="relative">
                        <CreditCard size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                        <input
                          id="co-card-number"
                          inputMode="numeric"
                          value={cardNumber}
                          onChange={(event) =>
                            setCardNumber(
                              event.target.value
                                .replace(/\D/g, "")
                                .slice(0, 16)
                                .replace(/(\d{4})(?=\d)/g, "$1 ")
                            )
                          }
                          autoComplete="cc-number"
                          className="field pl-10 tracking-[0.08em]"
                          placeholder="0000 0000 0000 0000"
                          aria-invalid={Boolean(errors.cardNumber)}
                        />
                      </div>
                      {inputError("cardNumber")}
                    </div>
                    <div>
                      <label htmlFor="co-expiry" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                        Expiry *
                      </label>
                      <input
                        id="co-expiry"
                        inputMode="numeric"
                        value={expiry}
                        onChange={(event) => {
                          const digits = event.target.value.replace(/\D/g, "").slice(0, 4);
                          setExpiry(digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits);
                        }}
                        autoComplete="cc-exp"
                        className="field"
                        placeholder="MM/YY"
                        aria-invalid={Boolean(errors.expiry)}
                      />
                      {inputError("expiry")}
                    </div>
                    <div>
                      <label htmlFor="co-cvc" className="mb-1.5 block text-[0.61rem] font-semibold text-mist">
                        CVC *
                      </label>
                      <input
                        id="co-cvc"
                        inputMode="numeric"
                        value={cvc}
                        onChange={(event) => setCvc(event.target.value.replace(/\D/g, "").slice(0, 4))}
                        autoComplete="cc-csc"
                        className="field"
                        placeholder="123"
                        aria-invalid={Boolean(errors.cvc)}
                      />
                      {inputError("cvc")}
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 flex items-start gap-3 rounded-xl border border-line-soft bg-ink/30 p-3.5">
                    <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-gold/10 text-gold">
                      {payment === "snapscan" ? <Smartphone size={17} /> : <Building2 size={17} />}
                    </span>
                    <div>
                      <p className="text-[0.72rem] font-semibold text-cream">
                        {payment === "snapscan" ? "Pay in a snap." : "Pay from your bank."}
                      </p>
                      <p className="mt-0.5 text-[0.64rem] font-light leading-relaxed text-mist">
                        {payment === "snapscan"
                          ? "Place your order, then approve the secure SnapScan request on your phone. Your tickets are released instantly."
                          : "Place your order and you'll be redirected to your bank's secure interface to approve an Instant EFT."}
                      </p>
                    </div>
                  </div>
                )}
              </section>

              <label className="mt-6 flex cursor-pointer items-start gap-2.5 text-[0.66rem] font-light leading-relaxed text-mist">
                <input
                  type="checkbox"
                  checked={terms}
                  onChange={(event) => setTerms(event.target.checked)}
                  className="mt-0.5 size-4 shrink-0 accent-[#e4c78e]"
                  aria-invalid={Boolean(errors.terms)}
                />
                <span>
                  I accept the ticket terms and venue rules, and confirm I am the lead guest for this booking. I understand
                  tickets are non-refundable unless the event is cancelled.
                </span>
              </label>
              {inputError("terms")}
              <p className="mt-4 flex items-center gap-1.5 text-[0.6rem] font-light text-mist-dim">
                <ShieldCheck size={11} /> This is a preview checkout — no real payment will be processed.
              </p>
            </div>

            <aside className="border-t border-line-soft bg-surface/35 p-5 sm:p-7 lg:border-l lg:border-t-0 lg:p-8">
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-[0.68rem] font-bold uppercase tracking-[0.15em] text-cream">Order summary</h3>
                <span className="rounded-full border border-line px-2 py-0.5 text-[0.55rem] uppercase tracking-[0.1em] text-mist">
                  {orderSummary.items.reduce((sum, item) => sum + item.quantity, 0)} tickets
                </span>
              </div>
              <div className="mt-4 space-y-3">
                {orderSummary.items.map((item) => (
                  <div key={item.key} className="flex gap-3 border-b border-line-soft pb-3">
                    <img src={item.image} alt="" className="h-14 w-12 shrink-0 rounded-lg object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-sans text-[0.73rem] font-semibold text-cream">{item.eventTitle}</p>
                      <p className="mt-0.5 truncate text-[0.61rem] text-mist">{item.quantity} × {item.tierName}</p>
                      <p className="mt-0.5 text-[0.58rem] text-mist-dim">{formatShortDate(item.eventDate)}</p>
                    </div>
                    <span className="shrink-0 text-[0.7rem] font-semibold text-gold">{formatZAR(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-[0.7rem] text-mist">
                  <span>Subtotal</span>
                  <span className="text-cream">{formatZAR(orderSummary.total)}</span>
                </div>
                <div className="flex justify-between text-[0.7rem] text-mist">
                  <span>Booking fee</span>
                  <span className="text-sage">Included</span>
                </div>
                <div className="flex items-end justify-between border-t border-line pt-3">
                  <span className="text-[0.64rem] font-bold uppercase tracking-[0.12em] text-cream">Total</span>
                  <span className="font-sans text-[1.4rem] font-bold tracking-tight text-gold">{formatZAR(orderSummary.total)}</span>
                </div>
              </div>
              <Button type="submit" size="lg" loading={processing} className="mt-4 w-full justify-between px-4">
                <span>{processing ? "Securing your tickets" : `Pay ${formatZAR(orderSummary.total)}`}</span>
                {!processing && <ArrowRight size={17} />}
              </Button>
              <p className="mt-3 flex items-start justify-center gap-1.5 text-center text-[0.6rem] leading-relaxed text-mist-dim">
                <LockKeyhole size={10} className="mt-0.5 shrink-0" />
                Secure payment. Instant e-ticket delivery. No hidden fees.
              </p>
              <div className="mt-4 flex items-center justify-center gap-2 border-t border-line-soft pt-3">
                {["VISA", "MC", "SnapScan", "EFT"].map((label) => (
                  <span key={label} className="rounded border border-white/10 px-1.5 py-1 text-[0.48rem] font-bold uppercase tracking-wide text-mist">
                    {label}
                  </span>
                ))}
              </div>
            </aside>
          </form>
        )}
      </div>
    </div>
  );
}
