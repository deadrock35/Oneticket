import { ArrowRight, LockKeyhole, Minus, Plus, ShoppingBag, Ticket, Trash2, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { formatShortDate, formatZAR } from "../../data/events";
import { Link, useRouter } from "../../lib/router";
import { Button } from "../ui/Button";

export function CartDrawer() {
  const { overlay, closeOverlay, cart, cartCount, cartSubtotal, setQuantity, removeLine, openOverlay } = useApp();
  const { navigate } = useRouter();
  if (overlay !== "cart") return null;

  const goBrowse = () => {
    closeOverlay();
    navigate("/events");
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex justify-end bg-ink/72 backdrop-blur-sm animate-overlay"
      onClick={closeOverlay}
      role="presentation"
    >
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-title"
        onClick={(event) => event.stopPropagation()}
        className="animate-slide-in flex h-full w-full max-w-[440px] flex-col border-l border-line bg-midnight shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-line-soft px-5 py-4 sm:px-6">
          <div>
            <p className="text-[0.58rem] font-bold uppercase tracking-[0.18em] text-gold">Your night out</p>
            <h2 id="cart-title" className="mt-0.5 font-display text-[1.8rem] leading-none text-cream">
              Your selection
            </h2>
          </div>
          <button
            type="button"
            onClick={closeOverlay}
            aria-label="Close ticket selection"
            className="grid size-9 place-items-center rounded-full border border-line text-mist transition-colors hover:border-gold/40 hover:text-cream"
          >
            <X size={16} />
          </button>
        </div>

        {cart.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <span className="relative grid size-16 place-items-center rounded-2xl border border-gold/25 bg-gold/[0.07] text-gold">
              <ShoppingBag size={25} strokeWidth={1.5} />
              <span className="absolute -right-1.5 -top-1.5 grid size-6 place-items-center rounded-full bg-gold text-[0.55rem] font-bold text-ink">
                0
              </span>
            </span>
            <p className="mt-5 font-display text-[1.85rem] leading-tight text-cream">The best seats are still empty.</p>
            <p className="mt-2 max-w-[250px] text-[0.78rem] font-light leading-relaxed text-mist">
              Find a show, choose your tickets, and we&apos;ll keep them right here for you.
            </p>
            <Button onClick={goBrowse} size="md" className="mt-6">
              Explore events <ArrowRight size={15} />
            </Button>
            <p className="mt-4 text-[0.64rem] text-mist-dim">Instant e-tickets · No hidden fees</p>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
              <div className="mb-4 flex items-center justify-between">
                <span className="text-[0.63rem] font-bold uppercase tracking-[0.14em] text-mist-dim">
                  {cartCount} ticket{cartCount === 1 ? "" : "s"}
                </span>
                <span className="inline-flex items-center gap-1 text-[0.63rem] text-sage">
                  <span className="size-1.5 rounded-full bg-sage" /> Available
                </span>
              </div>
              <div className="space-y-4">
                {cart.map((line) => (
                  <div key={line.key} className="flex gap-3.5 border-b border-line-soft pb-4">
                    <Link
                      to={`/events/${line.eventSlug}`}
                      onClick={closeOverlay}
                      className="relative h-[92px] w-[76px] shrink-0 overflow-hidden rounded-xl border border-line-soft"
                    >
                      <img src={line.image} alt="" className="h-full w-full object-cover" />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <Link
                        to={`/events/${line.eventSlug}`}
                        onClick={closeOverlay}
                        className="block truncate font-sans text-[0.83rem] font-semibold text-cream hover:text-gold-bright"
                      >
                        {line.eventTitle}
                      </Link>
                      <p className="mt-1 inline-flex items-center gap-1 text-[0.64rem] text-mist">
                        <Ticket size={10} className="text-gold/80" /> {line.tierName}
                      </p>
                      <p className="mt-0.5 text-[0.61rem] text-mist-dim">{formatShortDate(line.eventDate)}</p>
                      <div className="mt-2.5 flex items-center justify-between">
                        <div className="flex items-center rounded-full border border-line">
                          <button
                            type="button"
                            onClick={() => setQuantity(line.key, line.quantity - 1)}
                            aria-label={`Remove one ${line.tierName} ticket`}
                            className="grid size-7 place-items-center text-mist transition-colors hover:text-gold"
                          >
                            <Minus size={11} />
                          </button>
                          <span className="w-6 text-center font-sans text-[0.7rem] font-bold text-cream" aria-live="polite">
                            {line.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => setQuantity(line.key, line.quantity + 1)}
                            disabled={line.quantity >= 10}
                            aria-label={`Add one ${line.tierName} ticket`}
                            className="grid size-7 place-items-center text-mist transition-colors hover:text-gold disabled:opacity-30"
                          >
                            <Plus size={11} />
                          </button>
                        </div>
                        <div className="text-right">
                          <p className="text-[0.84rem] font-bold text-gold">{formatZAR(line.price * line.quantity)}</p>
                          <button
                            type="button"
                            onClick={() => removeLine(line.key)}
                            aria-label={`Remove ${line.tierName} tickets`}
                            className="mt-0.5 inline-flex items-center gap-1 text-[0.56rem] text-mist-dim transition-colors hover:text-coral"
                          >
                            <Trash2 size={9} /> Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 rounded-xl border border-gold/15 bg-gold/[0.04] p-3.5">
                <p className="font-sans text-[0.72rem] font-semibold text-cream">Everything included.</p>
                <p className="mt-1 text-[0.65rem] font-light leading-relaxed text-mist">
                  Booking fees and VAT are included in the prices shown. Your e-tickets arrive the moment you pay.
                </p>
              </div>
            </div>

            <div className="border-t border-line-soft bg-surface/45 px-5 py-5 sm:px-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[0.72rem] text-mist">
                  <span>Subtotal</span>
                  <span className="text-cream">{formatZAR(cartSubtotal)}</span>
                </div>
                <div className="flex items-center justify-between text-[0.72rem] text-mist">
                  <span>Booking fee</span>
                  <span className="text-sage">Included</span>
                </div>
                <div className="mt-1 flex items-end justify-between border-t border-line-soft pt-3">
                  <span className="text-[0.65rem] font-bold uppercase tracking-[0.13em] text-cream">Total due</span>
                  <span className="font-sans text-[1.35rem] font-bold tracking-tight text-gold">{formatZAR(cartSubtotal)}</span>
                </div>
              </div>
              <Button
                size="lg"
                onClick={() => openOverlay("checkout")}
                className="mt-4 w-full justify-between px-5"
              >
                <span>Secure checkout</span>
                <ArrowRight size={17} />
              </Button>
              <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[0.61rem] text-mist-dim">
                <LockKeyhole size={10} /> Encrypted payment · Instant confirmation
              </p>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
