import { useState } from "react";
import { ArrowUp, ArrowUpRight, Check, LockKeyhole, Mail } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Link } from "../../lib/router";
import { Logo } from "../ui/Logo";
import { cn } from "../../utils/cn";

const GROUPS = [
  {
    title: "Discover",
    links: [
      { label: "All events", to: "/events" },
      { label: "Music", to: "/events?category=Music" },
      { label: "Comedy", to: "/events?category=Comedy" },
      { label: "Theatre", to: "/events?category=Theatre" },
      { label: "Festivals", to: "/events?category=Festivals" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "FAQs", to: "/faqs" },
      { label: "Contact us", to: "/faqs" },
      { label: "Refunds & exchanges", to: "/faqs" },
      { label: "Accessibility", to: "/faqs" },
      { label: "Ticket transfer", to: "/faqs" },
    ],
  },
  {
    title: "OpenTickets",
    links: [
      { label: "Our story", to: "/" },
      { label: "For organisers", to: "/" },
      { label: "Careers", to: "/" },
      { label: "Privacy", to: "/" },
      { label: "Terms of use", to: "/" },
    ],
  },
];

const paymentMethods = ["VISA", "Mastercard", "SnapScan", "PayFast", "Zapper", "Apple Pay"];

const InstagramMark = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.4" cy="6.6" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

const FacebookMark = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M14 8.5V6.8c0-.8.5-1 1-1h2.5V2.2L14.1 2C10.8 2 9.3 4 9.3 6.5v2H6.8V12h2.5v10h4.2V12h3l.5-3.5H14Z" />
  </svg>
);

const YoutubeMark = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="2.5" y="5.5" width="19" height="13" rx="4" stroke="currentColor" strokeWidth="1.7" />
    <path d="m10.4 9.3 4.4 2.7-4.4 2.7V9.3Z" fill="currentColor" />
  </svg>
);

export function Footer() {
  const { notify } = useApp();
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState("");

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setSubscribed(true);
    notify("You're on the list. Welcome to OpenTickets.");
    setEmail("");
  };

  return (
    <footer className="relative mt-6 overflow-hidden border-t border-line-soft bg-ink-deep">
      <div
        className="pointer-events-none absolute -right-40 top-0 h-[420px] w-[520px] rounded-full opacity-50 blur-[120px]"
        style={{ background: "rgba(228,199,142,0.1)" }}
        aria-hidden="true"
      />
      <div className="shell relative">
        <div className="grid gap-10 py-14 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:gap-20 lg:py-20">
          <div>
            <span className="eyebrow">The insider list</span>
            <h2 className="mt-4 max-w-xl font-display text-[2.7rem] leading-[0.98] text-cream sm:text-[3.5rem]">
              Never miss a <em className="text-gold">moment.</em>
            </h2>
            <p className="mt-4 max-w-md text-[0.83rem] font-light leading-[1.8] text-mist">
              New tours, presale codes and Friday&apos;s shortlist of the best things happening in your city.
              No noise. Just the good stuff.
            </p>
          </div>

          <div className="rounded-2xl border border-gold/20 bg-surface/45 p-5 sm:p-7">
            {subscribed ? (
              <div className="flex min-h-[118px] flex-col items-start justify-center gap-3">
                <span className="grid size-10 place-items-center rounded-full bg-gold/15 text-gold">
                  <Check size={20} />
                </span>
                <div>
                  <p className="font-display text-2xl text-cream">You&apos;re on the list.</p>
                  <p className="mt-1 text-[0.78rem] font-light text-mist">
                    Your first curated edit lands in your inbox on Friday.
                  </p>
                </div>
              </div>
            ) : (
              <form onSubmit={submit} noValidate>
                <label htmlFor="newsletter-email" className="mb-2.5 block text-[0.65rem] font-bold uppercase tracking-[0.16em] text-cream/80">
                  Your email address
                </label>
                <div className="flex flex-col gap-2.5 sm:flex-row">
                  <div className="relative flex-1">
                    <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist-dim" aria-hidden="true" />
                    <input
                      id="newsletter-email"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(event) => {
                        setEmail(event.target.value);
                        setError("");
                      }}
                      placeholder="you@example.co.za"
                      aria-invalid={Boolean(error)}
                      aria-describedby={error ? "newsletter-error" : undefined}
                      className="field pl-10"
                    />
                  </div>
                  <button
                    type="submit"
                    className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[10px] bg-gold px-5 text-[0.76rem] font-bold tracking-[0.04em] text-ink transition-all hover:bg-gold-bright active:scale-[0.98]"
                  >
                    Join the list <ArrowUpRight size={15} />
                  </button>
                </div>
                {error && (
                  <p id="newsletter-error" className="mt-2 text-[0.7rem] text-coral">
                    {error}
                  </p>
                )}
                <p className="mt-3 flex items-start gap-1.5 text-[0.65rem] font-light leading-relaxed text-mist-dim">
                  <LockKeyhole size={11} className="mt-0.5 shrink-0" />
                  Your details stay with us. Unsubscribe anytime. Read our privacy promise.
                </p>
              </form>
            )}
          </div>
        </div>

        <div className="gold-rule" />

        <div className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_repeat(3,0.7fr)] lg:gap-12">
          <div>
            <Link to="/" aria-label="OpenTickets home">
              <Logo />
            </Link>
            <p className="mt-5 max-w-[280px] text-[0.78rem] font-light leading-[1.8] text-mist">
              South Africa&apos;s home of live entertainment. We connect you to the nights you&apos;ll be talking about
              for years.
            </p>
            <div className="mt-6 flex items-center gap-2">
              {[
                { label: "Instagram", icon: InstagramMark, href: "https://www.instagram.com/openticketsza" },
                { label: "Facebook", icon: FacebookMark, href: "https://www.facebook.com/openticketsza" },
                { label: "YouTube", icon: YoutubeMark, href: "https://www.youtube.com/@openticketsza" },
              ].map(({ label, icon: Icon, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={`OpenTickets on ${label}`}
                  className="grid size-9 place-items-center rounded-full border border-line text-mist transition-all hover:border-gold/50 hover:bg-gold/10 hover:text-gold"
                >
                  <Icon size={14} />
                </a>
              ))}
            </div>
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-line-soft px-3 py-1.5">
              <span className="flex h-2.5 w-4 overflow-hidden rounded-[1px]" aria-hidden="true">
                <span className="h-full w-1/3 bg-[#007a4d]" />
                <span className="h-full w-1/3 bg-[#ffb612]" />
                <span className="h-full w-1/3 bg-[#de3831]" />
              </span>
              <span className="text-[0.6rem] font-bold uppercase tracking-[0.13em] text-mist">Proudly South African</span>
            </div>
          </div>

          {GROUPS.map((group) => (
            <div key={group.title}>
              <h3 className="font-sans text-[0.62rem] font-bold uppercase tracking-[0.18em] text-gold">{group.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="group inline-flex items-center gap-1 text-[0.77rem] font-light text-mist transition-colors hover:text-cream"
                    >
                      {link.label}
                      <ArrowUpRight
                        size={10}
                        className="opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
                      />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="gold-rule" />

        <div className="flex flex-col gap-5 py-6 lg:flex-row lg:items-center lg:justify-between">
          <p className="text-[0.66rem] font-light text-mist-dim">
            © {new Date().getFullYear()} OpenTickets (Pty) Ltd · opentickets.co.za · All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1.5 inline-flex items-center gap-1 text-[0.6rem] font-bold uppercase tracking-[0.12em] text-mist-dim">
              <LockKeyhole size={10} /> Secure payments
            </span>
            {paymentMethods.map((method) => (
              <span
                key={method}
                className={cn(
                  "rounded-[4px] border border-white/10 bg-white/[0.055] px-1.5 py-1 text-[0.52rem] font-extrabold uppercase tracking-[-0.01em] text-cream/70",
                  method === "VISA" && "font-serif italic tracking-normal"
                )}
              >
                {method}
              </span>
            ))}
          </div>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="inline-flex items-center gap-2 self-start text-[0.63rem] font-bold uppercase tracking-[0.14em] text-mist transition-colors hover:text-gold lg:self-auto"
          >
            Back to top <ArrowUp size={13} />
          </button>
        </div>
      </div>
    </footer>
  );
}
