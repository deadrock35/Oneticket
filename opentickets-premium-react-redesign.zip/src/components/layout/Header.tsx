import { useEffect, useRef, useState } from "react";
import { Heart, LogOut, Menu, Search, ShoppingBag, Ticket, UserRound, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { EVENTS } from "../../data/events";
import { Link, useRouter } from "../../lib/router";
import { cn } from "../../utils/cn";
import { Logo } from "../ui/Logo";

const NAV_ITEMS = [
  { label: "Home", to: "/" },
  { label: "Events", to: "/events" },
  { label: "Search", to: "/search" },
  { label: "FAQs", to: "/faqs" },
];

export function Header() {
  const { path, isActive } = useRouter();
  const { user, cartCount, saved, orders, openOverlay, signOut } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const accountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setAccountOpen(false);
  }, [path]);

  useEffect(() => {
    if (!accountOpen) return;
    const onClick = (event: MouseEvent) => {
      if (accountRef.current && !accountRef.current.contains(event.target as Node)) setAccountOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [accountOpen]);

  useEffect(() => {
    if (!mobileOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [mobileOpen]);

  const handleAccount = () => {
    if (!user) {
      openOverlay("auth");
    } else {
      setAccountOpen((value) => !value);
    }
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
        scrolled || mobileOpen
          ? "border-b border-line-soft bg-ink/88 shadow-[0_18px_40px_-30px_rgba(0,0,0,0.9)] backdrop-blur-2xl"
          : "border-b border-transparent bg-gradient-to-b from-ink/70 to-transparent"
      )}
    >
      <div
        className={cn(
          "shell flex items-center justify-between gap-4 transition-[height] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
          scrolled ? "h-[68px]" : "h-[80px] sm:h-[88px]"
        )}
      >
        <Link to="/" aria-label="OpenTickets home" className="relative z-10 shrink-0">
          <Logo />
        </Link>

        <nav aria-label="Primary navigation" className="hidden items-center gap-8 lg:flex">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="nav-link"
              data-active={isActive(item.to) || (item.to === "/events" && path.startsWith("/events/"))}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => openOverlay("search")}
            aria-label="Search events"
            className="grid size-9 place-items-center rounded-full text-cream/80 transition-all hover:bg-white/[0.07] hover:text-gold-bright sm:size-10"
          >
            <Search size={17} strokeWidth={1.8} />
          </button>

          <div className="relative hidden lg:block" ref={accountRef}>
            <button
              type="button"
              onClick={handleAccount}
              aria-label={user ? "Open your account" : "Sign in to OpenTickets"}
              aria-expanded={accountOpen}
              className={cn(
                "flex h-9 items-center gap-2 rounded-full px-2 text-[0.75rem] font-semibold text-cream/80 transition-all hover:bg-white/[0.07] hover:text-cream",
                accountOpen && "bg-white/[0.07] text-cream"
              )}
            >
              {user ? (
                <span className="grid size-7 place-items-center rounded-full border border-gold/40 bg-gold/15 font-sans text-[0.62rem] font-extrabold uppercase tracking-wide text-gold-bright">
                  {user.name
                    .split(" ")
                    .map((part) => part[0])
                    .slice(0, 2)
                    .join("")}
                </span>
              ) : (
                <UserRound size={17} strokeWidth={1.8} />
              )}
              <span className="max-w-[88px] truncate">{user ? user.name.split(" ")[0] : "Sign in"}</span>
            </button>

            {accountOpen && user && (
              <div className="animate-modal absolute right-0 top-12 w-64 overflow-hidden rounded-2xl border border-line bg-raised shadow-2xl">
                <div className="border-b border-line-soft p-4">
                  <p className="text-[0.6rem] font-bold uppercase tracking-[0.18em] text-gold">Signed in</p>
                  <p className="mt-1 truncate font-sans text-sm font-semibold text-cream">{user.name}</p>
                  <p className="truncate text-[0.7rem] text-mist">{user.email}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setAccountOpen(false);
                    openOverlay("auth");
                  }}
                  className="flex w-full items-center justify-between px-4 py-3 text-left text-[0.76rem] text-cream/85 transition-colors hover:bg-white/[0.05] hover:text-gold"
                >
                  <span className="inline-flex items-center gap-2">
                    <Ticket size={14} /> My tickets
                  </span>
                  <span className="rounded-full bg-white/[0.06] px-1.5 py-0.5 text-[0.6rem] text-mist">{orders.length}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAccountOpen(false);
                    openOverlay("auth");
                  }}
                  className="flex w-full items-center justify-between px-4 py-3 text-left text-[0.76rem] text-cream/85 transition-colors hover:bg-white/[0.05] hover:text-gold"
                >
                  <span className="inline-flex items-center gap-2">
                    <Heart size={14} /> Saved events
                  </span>
                  <span className="rounded-full bg-white/[0.06] px-1.5 py-0.5 text-[0.6rem] text-mist">{saved.length}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAccountOpen(false);
                    signOut();
                  }}
                  className="flex w-full items-center gap-2 border-t border-line-soft px-4 py-3 text-left text-[0.76rem] text-mist transition-colors hover:bg-white/[0.05] hover:text-coral"
                >
                  <LogOut size={14} /> Sign out
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => openOverlay("cart")}
            aria-label={`Open ticket selection. ${cartCount} ticket${cartCount === 1 ? "" : "s"}`}
            className="relative grid size-9 place-items-center rounded-full text-cream/80 transition-all hover:bg-white/[0.07] hover:text-gold-bright sm:size-10"
          >
            <ShoppingBag size={17} strokeWidth={1.8} />
            {cartCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 grid min-w-[17px] place-items-center rounded-full border border-ink bg-gold px-1 py-px font-sans text-[0.55rem] font-extrabold leading-[1.2] text-ink">
                {cartCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((value) => !value)}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            className="grid size-9 place-items-center rounded-full text-cream/85 transition-colors hover:bg-white/[0.07] hover:text-gold lg:hidden"
          >
            {mobileOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </div>

      {/* Mobile navigation */}
      <div
        className={cn(
          "overflow-hidden border-line-soft bg-ink backdrop-blur-2xl transition-[max-height,opacity] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] lg:hidden",
          mobileOpen ? "max-h-[calc(100dvh-68px)] border-t opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <div className="shell h-[calc(100dvh-68px)] overflow-y-auto pb-8 pt-4">
          <nav aria-label="Mobile navigation" className="flex flex-col">
            {NAV_ITEMS.map((item, index) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center justify-between border-b border-line-soft py-4 transition-colors",
                  isActive(item.to) ? "text-gold" : "text-cream"
                )}
              >
                <span className="flex items-baseline gap-3">
                  <span className="font-sans text-[0.58rem] font-bold tracking-[0.18em] text-mist-dim">0{index + 1}</span>
                  <span className="font-display text-[1.9rem] leading-none">{item.label}</span>
                </span>
                <span className="text-[0.6rem] font-bold uppercase tracking-[0.15em] text-mist-dim">View</span>
              </Link>
            ))}
          </nav>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                openOverlay("search");
              }}
              className="flex min-h-12 items-center justify-center gap-2 rounded-[10px] border border-line bg-surface/60 text-[0.75rem] font-semibold text-cream"
            >
              <Search size={15} /> Search
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                openOverlay("auth");
              }}
              className="flex min-h-12 items-center justify-center gap-2 rounded-[10px] bg-gold text-[0.75rem] font-bold text-ink"
            >
              <UserRound size={15} /> {user ? "My account" : "Sign in"}
            </button>
          </div>

          <div className="mt-6 flex items-center justify-between text-[0.65rem] text-mist-dim">
            <span>{EVENTS.length} live experiences</span>
            <a href="mailto:support@opentickets.co.za" className="text-gold/90 hover:text-gold">
              support@opentickets.co.za
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
