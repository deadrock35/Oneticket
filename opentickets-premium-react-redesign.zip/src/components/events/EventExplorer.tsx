import { useLayoutEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { CATEGORIES, EVENTS, categoryCount, type Category, type EventItem } from "../../data/events";
import { cn } from "../../utils/cn";
import { EventCard } from "./EventCard";

type Filter = Category | "All";
const FILTERS: Filter[] = ["All", ...CATEGORIES.map((category) => category.label)];

export function EventExplorer({
  events = EVENTS,
  initialFilter = "All",
  className,
}: {
  events?: EventItem[];
  initialFilter?: Filter;
  className?: string;
}) {
  const [active, setActive] = useState<Filter>(initialFilter);
  const [expanded, setExpanded] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);
  const positions = useRef<Map<string, DOMRect>>(new Map());

  const filtered = active === "All" ? events : events.filter((event) => event.category === active);
  const baseFiltered = initialFilter === "All" ? events : events.filter((event) => event.category === initialFilter);
  const limit = 9;
  const hasMore = filtered.length > limit;
  const shown = hasMore && !expanded ? filtered.slice(0, limit) : filtered;

  const capturePositions = () => {
    const grid = gridRef.current;
    if (!grid) return;
    const next = new Map<string, DOMRect>();
    grid.querySelectorAll<HTMLElement>("[data-flip-id]").forEach((element) => {
      next.set(element.dataset.flipId ?? "", element.getBoundingClientRect());
    });
    positions.current = next;
  };

  const selectFilter = (filter: Filter) => {
    if (filter === active) return;
    capturePositions();
    setActive(filter);
    setExpanded(false);
  };

  useLayoutEffect(() => {
    const grid = gridRef.current;
    if (!grid || positions.current.size === 0) return;
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    const previous = positions.current;

    grid.querySelectorAll<HTMLElement>("[data-flip-id]").forEach((element) => {
      const id = element.dataset.flipId ?? "";
      const before = previous.get(id);
      const after = element.getBoundingClientRect();

      if (!before) {
        if (!reduced) {
          element.animate(
            [
              { opacity: 0, transform: "translateY(16px) scale(0.985)" },
              { opacity: 1, transform: "none" },
            ],
            { duration: 420, easing: "cubic-bezier(0.22,1,0.36,1)", fill: "both" }
          );
        }
        return;
      }

      const deltaX = before.left - after.left;
      const deltaY = before.top - after.top;
      if (reduced || (Math.abs(deltaX) < 1 && Math.abs(deltaY) < 1)) return;
      element.animate(
        [
          { transform: `translate(${deltaX}px, ${deltaY}px)` },
          { transform: "translate(0, 0)" },
        ],
        { duration: 500, easing: "cubic-bezier(0.22,1,0.36,1)" }
      );
    });

    positions.current = new Map();
  }, [active, expanded]);

  return (
    <div className={cn(className)}>
      <div className="flex flex-col gap-5 border-y border-line-soft py-4 lg:flex-row lg:items-center lg:justify-between">
        <div
          className="no-scrollbar -mx-1 flex items-center gap-1.5 overflow-x-auto px-1 pb-1 lg:pb-0"
          role="tablist"
          aria-label="Filter events by category"
        >
          {FILTERS.map((filter) => {
            const count = initialFilter === "All" ? categoryCount(filter) : baseFiltered.filter((e) => filter === "All" || e.category === filter).length;
            const isActive = active === filter;
            return (
              <button
                key={filter}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => selectFilter(filter)}
                className={cn(
                  "relative inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2 text-[0.72rem] font-semibold tracking-[0.025em] transition-all duration-300 sm:px-4",
                  isActive
                    ? "border-gold bg-gold text-ink shadow-[0_8px_25px_-12px_rgba(228,199,142,0.7)]"
                    : "border-transparent text-mist hover:border-line hover:bg-white/[0.04] hover:text-cream"
                )}
              >
                {filter === "All" ? "All events" : filter}
                <span
                  className={cn(
                    "rounded-full px-1.5 py-0.5 text-[0.56rem] font-bold leading-none",
                    isActive ? "bg-ink/15 text-ink/80" : "bg-white/[0.06] text-mist-dim"
                  )}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3 text-[0.67rem] font-semibold uppercase tracking-[0.13em] text-mist-dim">
          <span className="hidden h-3 w-px bg-line sm:block" />
          <span>
            <span className="text-cream">{filtered.length}</span> experience{filtered.length === 1 ? "" : "s"} to discover
          </span>
        </div>
      </div>

      <div
        ref={gridRef}
        className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 xl:grid-cols-3"
        aria-live="polite"
      >
        {shown.map((event) => (
          <div key={event.slug} data-flip-id={event.slug} className="relative">
            <EventCard event={event} className="h-full" />
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="mt-6 rounded-2xl border border-line-soft bg-surface/40 px-6 py-16 text-center">
          <p className="font-display text-3xl text-cream">No shows in this collection — yet.</p>
          <p className="mt-2 text-sm text-mist">Try another category or explore everything that&apos;s on.</p>
        </div>
      )}

      {hasMore && (
        <div className="mt-8 flex justify-center">
          <button
            type="button"
            onClick={() => {
              capturePositions();
              setExpanded((value) => !value);
            }}
            className="group inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-cream/85 transition-all hover:border-gold/45 hover:bg-gold/5 hover:text-gold-bright"
          >
            {expanded ? "Show fewer events" : `Show all ${filtered.length} events`}
            <ChevronDown size={15} className={cn("transition-transform duration-300", expanded && "rotate-180")} />
          </button>
        </div>
      )}
    </div>
  );
}
