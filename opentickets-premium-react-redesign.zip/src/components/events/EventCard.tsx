import { ArrowUpRight, Heart, MapPin } from "lucide-react";
import { useApp } from "../../context/AppContext";
import {
  eventImage,
  formatEventDate,
  formatZAR,
  getDateBadge,
  getVenue,
  type EventItem,
} from "../../data/events";
import { Link } from "../../lib/router";
import { cn } from "../../utils/cn";

interface EventCardProps {
  event: EventItem;
  className?: string;
  compact?: boolean;
}

export function EventCard({ event, className, compact = false }: EventCardProps) {
  const { saved, toggleSaved } = useApp();
  const isSaved = saved.includes(event.slug);
  const badge = getDateBadge(event.date);
  const venue = getVenue(event);

  return (
    <article
      className={cn(
        "card-lift group relative flex flex-col overflow-hidden rounded-[18px] border border-line-soft bg-surface/55",
        className
      )}
    >
      <Link to={`/events/${event.slug}`} className="block focus-visible:outline-offset-4" aria-label={`View ${event.title}`}>
        <div className="relative overflow-hidden bg-raised">
          <img
            src={eventImage(event, "card")}
            alt={`${event.title} — ${event.artist}`}
            loading="lazy"
            style={{ objectPosition: event.imagePosition ?? "center" }}
            className={cn(
              "w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.055]",
              compact ? "aspect-[16/10]" : "aspect-[4/3]"
            )}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/5 to-ink/10" aria-hidden="true" />

          <div className="absolute left-3.5 top-3.5 overflow-hidden rounded-[10px] border border-white/15 bg-cream text-center text-ink shadow-lg backdrop-blur">
            <span className="block px-3 pb-0.5 pt-1.5 font-display text-[1.35rem] leading-none">{badge.day}</span>
            <span className="block bg-ink/90 px-3 pb-1 pt-0.5 text-[0.52rem] font-extrabold tracking-[0.18em] text-gold">
              {badge.month}
            </span>
          </div>

          <span className="absolute bottom-3.5 left-3.5 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-ink/55 px-2.5 py-1 text-[0.58rem] font-bold uppercase tracking-[0.16em] text-cream backdrop-blur-md">
            <span
              className={cn(
                "size-1.5 rounded-full",
                event.category === "Music" && "bg-gold",
                event.category === "Comedy" && "bg-coral",
                event.category === "Theatre" && "bg-violet",
                event.category === "Festivals" && "bg-sage"
              )}
            />
            {event.category}
          </span>

          {event.badge && (
            <span className="absolute bottom-3.5 right-3.5 hidden rounded-full border border-gold/25 bg-gold/12 px-2.5 py-1 text-[0.58rem] font-bold uppercase tracking-[0.14em] text-gold-bright backdrop-blur sm:inline-flex">
              {event.badge}
            </span>
          )}
        </div>

        <div className={cn("flex flex-1 flex-col px-4", compact ? "pb-4 pt-4" : "pb-5 pt-4 sm:px-5")}>
          <div className="flex items-center gap-1.5 text-[0.65rem] font-semibold uppercase tracking-[0.13em] text-mist-dim">
            <MapPin size={11} strokeWidth={2} className="text-gold/80" />
            <span>{venue.city}</span>
            <span className="text-line-strong">·</span>
            <span className="normal-case tracking-normal">{formatEventDate(event.date)}</span>
          </div>

          <h3
            className={cn(
              "mt-2 font-display leading-[1.08] tracking-[-0.015em] text-cream transition-colors duration-300 group-hover:text-gold-bright",
              compact ? "text-[1.22rem]" : "text-[1.43rem] sm:text-[1.52rem]"
            )}
          >
            {event.title}
          </h3>
          <p className="mt-1.5 line-clamp-1 text-[0.76rem] font-light tracking-wide text-mist">{event.artist}</p>

          <div className="mt-auto flex items-end justify-between gap-3 border-t border-line-soft pt-4">
            <div>
              <span className="block text-[0.56rem] font-bold uppercase tracking-[0.18em] text-mist-dim">Tickets from</span>
              <span className="mt-0.5 block font-sans text-[1.03rem] font-bold tracking-[-0.02em] text-gold">
                {formatZAR(event.priceFrom)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {event.status !== "On sale" && (
                <span
                  className={cn(
                    "text-[0.58rem] font-bold uppercase tracking-[0.11em]",
                    event.status === "Few left" ? "text-coral" : "text-gold/85"
                  )}
                >
                  {event.status}
                </span>
              )}
              <span className="grid size-8 place-items-center rounded-full border border-line text-cream/75 transition-all duration-300 group-hover:border-gold group-hover:bg-gold group-hover:text-ink">
                <ArrowUpRight size={14} strokeWidth={1.8} />
              </span>
            </div>
          </div>
        </div>
      </Link>

      <button
        type="button"
        onClick={() => toggleSaved(event.slug)}
        aria-label={isSaved ? `Remove ${event.title} from saved events` : `Save ${event.title}`}
        aria-pressed={isSaved}
        className={cn(
          "absolute right-3 top-3 z-20 grid size-9 place-items-center rounded-full border backdrop-blur-md transition-all duration-300",
          isSaved
            ? "border-gold/50 bg-gold text-ink"
            : "border-white/15 bg-ink/35 text-cream/85 hover:border-gold/50 hover:bg-ink/70 hover:text-gold"
        )}
      >
        <Heart size={15} strokeWidth={1.9} fill={isSaved ? "currentColor" : "none"} />
      </button>
    </article>
  );
}
