import { useState } from "react";
import { Clock3, LockKeyhole, Minus, Plus, ShieldCheck, ShoppingBag, Ticket, UserRound } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { formatZAR, type EventItem, type EventTier } from "../../data/events";
import { cn } from "../../utils/cn";
import { Button } from "../ui/Button";
import { SeatMap } from "./SeatMap";

export function BookingCard({ event }: { event: EventItem }) {
  const { addToCart, openOverlay } = useApp();
  const firstAvailable = event.tiers.find((tier) => tier.availability !== "Sold out") ?? event.tiers[0];
  const [selectedId, setSelectedId] = useState(firstAvailable.id);
  const [quantity, setQuantity] = useState(1);

  const selected = event.tiers.find((tier) => tier.id === selectedId) ?? firstAvailable;

  const chooseTier = (tier: EventTier) => {
    if (tier.availability === "Sold out") return;
    setSelectedId(tier.id);
    setQuantity(1);
  };

  const add = () => {
    addToCart({ eventSlug: event.slug, tierId: selected.id, quantity });
    openOverlay("cart");
  };

  return (
    <div id="tickets" className="glass overflow-hidden rounded-2xl border-gold/25 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.95)]">
      <div className="border-b border-line-soft bg-gold/[0.045] px-4 py-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <p className="text-[0.53rem] font-bold uppercase tracking-[0.17em] text-gold">Official tickets</p>
            <h2 className="mt-0.5 font-display text-[1.65rem] leading-none text-cream">Choose your seats</h2>
          </div>
          <span className="grid size-9 place-items-center rounded-full border border-gold/25 bg-gold/[0.08] text-gold">
            <Ticket size={16} />
          </span>
        </div>
        <div className="mt-3.5">
          <div className="flex items-center justify-between text-[0.56rem]">
            <span className="text-mist">{event.soldPercent}% sold</span>
            <span className={cn("font-semibold", event.status === "Few left" ? "text-coral" : "text-gold")}>
              {event.status === "Few left" ? "Going fast" : event.status}
            </span>
          </div>
          <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/[0.07]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-gold-deep via-gold to-gold-bright"
              style={{ width: `${event.soldPercent}%` }}
            />
          </div>
        </div>
      </div>

      <div className="p-4">
        <SeatMap tiers={event.tiers} selectedId={selectedId} onSelect={chooseTier} />

        <div className="mt-4 space-y-2" role="radiogroup" aria-label="Ticket types">
          {event.tiers.map((tier) => {
            const soldOut = tier.availability === "Sold out";
            const isSelected = selectedId === tier.id;
            return (
              <button
                key={tier.id}
                type="button"
                role="radio"
                aria-checked={isSelected}
                disabled={soldOut}
                onClick={() => chooseTier(tier)}
                className={cn(
                  "flex w-full items-start gap-2.5 rounded-xl border p-3 text-left transition-all duration-300",
                  isSelected
                    ? "border-gold/60 bg-gold/[0.075]"
                    : "border-line-soft bg-ink/20 hover:border-line-strong hover:bg-white/[0.025]",
                  soldOut && "cursor-not-allowed opacity-45 hover:border-line-soft"
                )}
              >
                <span
                  className={cn(
                    "mt-0.5 grid size-4 shrink-0 place-items-center rounded-full border",
                    isSelected ? "border-gold" : "border-mist-dim"
                  )}
                >
                  {isSelected && <span className="size-2 rounded-full bg-gold" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="text-[0.75rem] font-semibold text-cream">{tier.name}</span>
                    <span className={cn("shrink-0 text-[0.78rem] font-bold", soldOut ? "text-mist-dim line-through" : "text-gold")}>
                      {formatZAR(tier.price)}
                    </span>
                  </span>
                  <span className="mt-0.5 block text-[0.66rem] font-light leading-relaxed text-mist">{tier.description}</span>
                  {tier.availability !== "Sold out" && tier.availability === "Few left" && (
                    <span className="mt-1 inline-block text-[0.53rem] font-bold uppercase tracking-[0.1em] text-coral">Few left</span>
                  )}
                  {soldOut && <span className="mt-1 inline-block text-[0.53rem] font-bold uppercase tracking-[0.1em] text-mist-dim">Sold out</span>}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-4 rounded-xl border border-line-soft bg-ink/30 p-3">
          <div className="flex items-center justify-between gap-3">
            <span className="text-[0.65rem] font-semibold text-cream">Quantity</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setQuantity((value) => Math.max(1, value - 1))}
                disabled={quantity <= 1}
                aria-label="Decrease ticket quantity"
                className="grid size-7 place-items-center rounded-full border border-line text-mist transition-colors hover:border-gold/40 hover:text-gold disabled:opacity-30"
              >
                <Minus size={11} />
              </button>
              <span className="w-5 text-center font-sans text-[0.8rem] font-bold text-cream" aria-live="polite">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((value) => Math.min(10, value + 1))}
                disabled={quantity >= 10}
                aria-label="Increase ticket quantity"
                className="grid size-7 place-items-center rounded-full border border-line text-mist transition-colors hover:border-gold/40 hover:text-gold disabled:opacity-30"
              >
                <Plus size={11} />
              </button>
            </div>
          </div>
          <div className="mt-2.5 flex items-end justify-between border-t border-line-soft pt-2.5">
            <div>
              <p className="text-[0.53rem] font-bold uppercase tracking-[0.13em] text-mist-dim">Total incl. fees</p>
              <p className="mt-0.5 text-[1.25rem] font-bold tracking-tight text-gold">{formatZAR(selected.price * quantity)}</p>
            </div>
            <span className="text-[0.56rem] text-mist-dim">Max 10 per guest</span>
          </div>
        </div>

        <Button size="lg" className="mt-3 w-full justify-between px-4" onClick={add}>
          <span className="inline-flex items-center gap-2">
            <ShoppingBag size={16} /> Add to selection
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Plus size={14} /> {quantity}
          </span>
        </Button>

        <div className="mt-3 grid grid-cols-3 gap-1.5 border-t border-line-soft pt-3">
          {[
            { icon: LockKeyhole, label: "Secure" },
            { icon: Clock3, label: "Instant" },
            { icon: ShieldCheck, label: "Official" },
          ].map(({ icon: Icon, label }) => (
            <div key={label} className="flex flex-col items-center gap-1 text-center">
              <Icon size={13} className="text-gold/80" />
              <span className="text-[0.52rem] font-medium text-mist-dim">{label}</span>
            </div>
          ))}
        </div>
        <p className="mt-2 flex items-center justify-center gap-1 text-[0.53rem] font-light text-mist-dim">
          <UserRound size={9} /> Name changes allowed up to 48h before
        </p>
      </div>
    </div>
  );
}
