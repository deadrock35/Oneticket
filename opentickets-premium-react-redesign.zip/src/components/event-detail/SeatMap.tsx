import { cn } from "../../utils/cn";
import { formatZARShort, type EventTier } from "../../data/events";

interface SeatMapProps {
  tiers: EventTier[];
  selectedId: string;
  onSelect: (tier: EventTier) => void;
}

export function SeatMap({ tiers, selectedId, onSelect }: SeatMapProps) {
  return (
    <div className="rounded-xl border border-line-soft bg-ink/45 p-3">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-[0.52rem] font-bold uppercase tracking-[0.15em] text-mist-dim">Interactive seating preview</span>
        <span className="text-[0.5rem] uppercase tracking-[0.1em] text-gold/80">Tap a zone</span>
      </div>

      <div className="relative mx-auto mb-2 h-4 w-3/4 overflow-hidden rounded-t-[40px] border border-gold/25 bg-gradient-to-b from-gold/20 to-gold/[0.03]">
        <span className="absolute inset-x-0 top-1/2 -translate-y-1/2 text-center text-[0.46rem] font-bold uppercase tracking-[0.3em] text-gold/80">
          Stage
        </span>
      </div>

      <div className="mb-2 flex justify-center gap-1" aria-hidden="true">
        {Array.from({ length: 8 }).map((_, index) => (
          <span key={index} className="h-0.5 w-4 rounded-full bg-white/10" />
        ))}
      </div>

      <div className={cn("grid gap-1.5", tiers.length === 2 ? "grid-cols-2" : "grid-cols-3")}>
        {tiers.map((tier) => {
          const soldOut = tier.availability === "Sold out";
          const selected = selectedId === tier.id;
          return (
            <button
              key={tier.id}
              type="button"
              disabled={soldOut}
              onClick={() => onSelect(tier)}
              aria-pressed={selected}
              aria-label={`Select ${tier.name} zone, ${tier.availability}, from ${formatZARShort(tier.price)}`}
              className={cn(
                "group relative flex min-h-[46px] flex-col items-center justify-center rounded-[5px] border px-1 py-1.5 text-center transition-all duration-300",
                selected
                  ? "border-gold bg-gold/20 shadow-[0_0_20px_-6px_rgba(228,199,142,0.5)]"
                  : "border-white/10 bg-white/[0.045] hover:border-gold/40 hover:bg-gold/10",
                soldOut && "cursor-not-allowed opacity-35 hover:border-white/10 hover:bg-white/[0.045]"
              )}
            >
              <span className={cn("text-[0.45rem] font-bold uppercase tracking-[0.08em]", selected ? "text-gold-bright" : "text-cream/80")}>
                {tier.zone}
              </span>
              <span className={cn("mt-0.5 text-[0.45rem]", soldOut ? "text-coral/80" : "text-mist-dim")}>
                {soldOut ? "Sold out" : formatZARShort(tier.price)}
              </span>
              {selected && <span className="absolute right-1 top-1 size-1 rounded-full bg-gold" />}
            </button>
          );
        })}
      </div>
      <p className="mt-2.5 text-center text-[0.53rem] font-light leading-relaxed text-mist-dim">
        Seats are assigned best available within your selected zone.
      </p>
    </div>
  );
}
