import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { EVENTS, eventImage, getEvent } from "../data/events";

export type Overlay = "search" | "cart" | "auth" | "checkout" | null;

export interface CartLine {
  key: string;
  eventSlug: string;
  eventTitle: string;
  eventDate: string;
  image: string;
  tierId: string;
  tierName: string;
  price: number;
  quantity: number;
}

export interface User {
  name: string;
  email: string;
}

export interface Order {
  reference: string;
  createdAt: string;
  total: number;
  email: string;
  items: CartLine[];
}

interface Toast {
  id: number;
  message: string;
}

interface AppContextValue {
  cart: CartLine[];
  cartCount: number;
  cartSubtotal: number;
  addToCart: (input: { eventSlug: string; tierId: string; quantity: number }) => void;
  setQuantity: (key: string, quantity: number) => void;
  removeLine: (key: string) => void;
  clearCart: () => void;
  saved: string[];
  toggleSaved: (slug: string) => void;
  user: User | null;
  signIn: (user: User) => void;
  signOut: () => void;
  overlay: Overlay;
  openOverlay: (overlay: Exclude<Overlay, null>) => void;
  closeOverlay: () => void;
  orders: Order[];
  placeOrder: (details: { name: string; email: string }) => Order;
  toast: Toast | null;
  notify: (message: string) => void;
  dismissToast: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* Storage is a progressive enhancement. */
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>(() => readStorage<CartLine[]>("ot.cart", []));
  const [saved, setSaved] = useState<string[]>(() => readStorage<string[]>("ot.saved", []));
  const [user, setUser] = useState<User | null>(() => readStorage<User | null>("ot.user", null));
  const [orders, setOrders] = useState<Order[]>(() => readStorage<Order[]>("ot.orders", []));
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<number | null>(null);

  useEffect(() => writeStorage("ot.cart", cart), [cart]);
  useEffect(() => writeStorage("ot.saved", saved), [saved]);
  useEffect(() => writeStorage("ot.user", user), [user]);
  useEffect(() => writeStorage("ot.orders", orders), [orders]);

  useEffect(() => {
    const original = document.body.style.overflow;
    document.body.style.overflow = overlay ? "hidden" : original;
    return () => {
      document.body.style.overflow = original;
    };
  }, [overlay]);

  const closeOverlay = useCallback(() => setOverlay(null), []);

  useEffect(() => {
    if (!overlay) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOverlay(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [overlay]);

  const notify = useCallback((message: string) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), message });
    toastTimer.current = window.setTimeout(() => setToast(null), 3400);
  }, []);

  useEffect(
    () => () => {
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    },
    []
  );

  const addToCart = useCallback(
    ({ eventSlug, tierId, quantity }: { eventSlug: string; tierId: string; quantity: number }) => {
      const event = getEvent(eventSlug);
      const tier = event?.tiers.find((item) => item.id === tierId);
      if (!event || !tier || tier.availability === "Sold out" || quantity < 1) return;
      const key = `${eventSlug}:${tierId}`;
      setCart((current) => {
        const existing = current.find((line) => line.key === key);
        if (existing) {
          return current.map((line) =>
            line.key === key ? { ...line, quantity: Math.min(10, line.quantity + quantity) } : line
          );
        }
        return [
          ...current,
          {
            key,
            eventSlug,
            eventTitle: event.title,
            eventDate: event.date,
            image: eventImage(event, "card"),
            tierId,
            tierName: tier.name,
            price: tier.price,
            quantity: Math.min(10, quantity),
          },
        ];
      });
      notify(`${quantity} × ${tier.name} added to your selection`);
    },
    [notify]
  );

  const setQuantity = useCallback((key: string, quantity: number) => {
    setCart((current) =>
      current.flatMap((line) => {
        if (line.key !== key) return [line];
        if (quantity <= 0) return [];
        return [{ ...line, quantity: Math.min(10, quantity) }];
      })
    );
  }, []);

  const removeLine = useCallback((key: string) => {
    setCart((current) => current.filter((line) => line.key !== key));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleSaved = useCallback(
    (slug: string) => {
      setSaved((current) => {
        const next = current.includes(slug) ? current.filter((item) => item !== slug) : [...current, slug];
        notify(current.includes(slug) ? "Removed from saved events" : "Saved to your shortlist");
        return next;
      });
    },
    [notify]
  );

  const signIn = useCallback(
    (nextUser: User) => {
      setUser(nextUser);
      setOverlay(null);
      notify(`Welcome back, ${nextUser.name.split(" ")[0]}`);
    },
    [notify]
  );

  const signOut = useCallback(() => {
    setUser(null);
    setOverlay(null);
    notify("You have been signed out");
  }, [notify]);

  const placeOrder = useCallback(
    (details: { name: string; email: string }) => {
      const stamp = Date.now().toString().slice(-5);
      const reference = `OT-${new Date().getFullYear()}-${stamp}`;
      const order: Order = {
        reference,
        createdAt: new Date().toISOString(),
        total: cart.reduce((sum, line) => sum + line.price * line.quantity, 0),
        email: details.email,
        items: cart,
      };
      setOrders((current) => [order, ...current]);
      setCart([]);
      return order;
    },
    [cart]
  );

  const value = useMemo<AppContextValue>(
    () => ({
      cart,
      cartCount: cart.reduce((count, line) => count + line.quantity, 0),
      cartSubtotal: cart.reduce((sum, line) => sum + line.price * line.quantity, 0),
      addToCart,
      setQuantity,
      removeLine,
      clearCart,
      saved,
      toggleSaved,
      user,
      signIn,
      signOut,
      overlay,
      openOverlay: (next) => setOverlay(next),
      closeOverlay,
      orders,
      placeOrder,
      toast,
      notify,
      dismissToast: () => setToast(null),
    }),
    [
      cart,
      saved,
      addToCart,
      setQuantity,
      removeLine,
      clearCart,
      toggleSaved,
      user,
      signIn,
      signOut,
      overlay,
      closeOverlay,
      orders,
      placeOrder,
      toast,
      notify,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}

export const savedEventDetails = (saved: string[]) =>
  saved.map((slug) => EVENTS.find((event) => event.slug === slug)).filter((event) => event !== undefined);
