import { useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronRight,
  Clock3,
  Headphones,
  MapPin,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Ticket,
  Zap,
} from "lucide-react";
import { EventExplorer } from "../components/events/EventExplorer";
import { Link, useRouter } from "../lib/router";
import {
  CATEGORIES,
  EVENTS,
  eventImage,
  formatEventDate,
  formatZAR,
  getVenue,
} from "../data/events";
import { Reveal } from "../components/ui/Reveal";

const HERO_IMAGE =
  "https://images.pexels.com/photos/4218027/pexels-photo-4218027.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1920&h=1280";

const CITIES = ["All cities", "Cape Town", "Johannesburg", "Pretoria", "Darling", "Franschhoek"];
const WHEN_OPTIONS = [
  { label: "Any time", value: "any" },
  { label: "Late 2026", value: "2026" },
  { label: "Early 2027", value: "2027-q1" },
  { label: "Mid 2027", value: "2027-q2" },
  { label: "Spring 2027", value: "2027-q3" },
];

const categoryPhoto = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=1100`;

const VENUE_LINE = [
  "Kirstenbosch",
  "Artscape",
  "Teatro",
  "Sun Arena",
  "CTICC",
  "GrandWest",
  "Joburg Theatre",
];

export function HomePage() {
  const { navigate } = useRouter();
  const [query, setQuery] = useState("");
  const [city, setCity] = useState("All cities");
  const [when, setWhen] = useState("any");
  const featured = EVENTS[0];
  const featuredVenue = getVenue(featured);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (city !== "All cities") params.set("city", city);
    if (when !== "any") params.set("when", when);
    navigate(`/search${params.toString() ? `?${params.toString()}` : ""}`);
  };

  return (
    <>
      {/* ============================= HERO ============================= */}
      <section className="grain relative isolate min-h-[760px] overflow-hidden pb-0 lg:min-h-[820px]">
        <img
          src={HERO_IMAGE}
          alt="A crowd enjoying a live concert under golden stage lights"
          className="absolute inset-0 h-full w-full object-cover object-[58%_center] opacity-[0.58]"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(90deg, #070b12 0%, rgba(7,11,18,0.96) 28%, rgba(7,11,18,0.7) 55%, rgba(7,11,18,0.45) 78%, rgba(7,11,18,0.88) 100%)",
          }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/60" aria-hidden="true" />
        <div
          className="pointer-events-none absolute -left-40 top-1/3 h-[460px] w-[520px] rounded-full blur-[130px]"
          style={{ background: "rgba(228,199,142,0.12)" }}
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute right-[8%] top-[14%] h-[360px] w-[360px] rounded-full blur-[120px]"
          style={{ background: "rgba(148,129,239,0.13)" }}
          aria-hidden="true"
        />

        <div className="shell relative z-10 grid gap-12 pb-12 pt-[122px] sm:pt-[140px] lg:grid-cols-[1.35fr_0.65fr] lg:items-center lg:gap-8 lg:pb-16 lg:pt-[160px]">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-full border border-gold/25 bg-gold/[0.07] px-3 py-1.5 text-[0.62rem] font-bold uppercase tracking-[0.16em] text-gold-bright backdrop-blur">
                <span className="live-dot size-1.5 rounded-full bg-gold" />
                Season 26/27 · Now booking
              </span>
              <span className="hidden items-center gap-1.5 text-[0.64rem] font-medium text-cream/65 sm:inline-flex">
                <Sparkles size={12} className="text-gold/80" />
                Proudly South African
              </span>
            </div>

            <h1 className="mt-6 max-w-[690px] font-display text-[clamp(3.35rem,7.3vw,6.65rem)] leading-[0.91] tracking-[-0.035em] text-cream">
              Live moments.
              <br />
              Beautifully <em className="text-gold">booked.</em>
            </h1>

            <p className="mt-6 max-w-[490px] text-[0.9rem] font-light leading-[1.85] text-cream/75 sm:text-[0.97rem]">
              From sold-out arena tours to candlelit jazz in the winelands. Discover South Africa&apos;s most
              extraordinary nights, and hold the good seats before anyone else.
            </p>

            <form
              onSubmit={submitSearch}
              className="glass mt-8 max-w-[760px] rounded-2xl p-2 shadow-[0_30px_80px_-35px_rgba(0,0,0,0.9)]"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1.45fr_0.9fr_0.95fr_auto]">
                <label className="group relative flex min-h-[54px] items-center gap-2.5 rounded-xl px-3 transition-colors focus-within:bg-white/[0.03]">
                  <Search size={16} className="shrink-0 text-gold/90" aria-hidden="true" />
                  <span className="min-w-0 flex-1">
                    <span className="block text-[0.53rem] font-bold uppercase tracking-[0.16em] text-mist-dim">
                      What&apos;s on
                    </span>
                    <input
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      placeholder="Event, artist or venue"
                      aria-label="Search events, artists or venues"
                      className="mt-0.5 w-full border-0 bg-transparent p-0 font-sans text-[0.77rem] font-medium text-cream placeholder:text-mist-dim focus:outline-none focus:ring-0"
                    />
                  </span>
                </label>

                <label className="relative flex min-h-[54px] flex-col justify-center border-t border-line-soft px-3 sm:border-l sm:border-t-0">
                  <span className="flex items-center gap-1.5 text-[0.53rem] font-bold uppercase tracking-[0.16em] text-mist-dim">
                    <MapPin size={9} /> Where
                  </span>
                  <select
                    value={city}
                    onChange={(event) => setCity(event.target.value)}
                    aria-label="Choose a city"
                    className="mt-0.5 w-[calc(100%-1rem)] cursor-pointer appearance-none border-0 bg-transparent p-0 font-sans text-[0.77rem] font-medium text-cream focus:outline-none"
                    style={{ colorScheme: "dark" }}
                  >
                    {CITIES.map((option) => (
                      <option key={option} value={option} className="bg-raised text-cream">
                        {option}
                      </option>
                    ))}
                  </select>
                  <ChevronRight size={11} className="pointer-events-none absolute bottom-[21px] right-3 rotate-90 text-mist-dim" />
                </label>

                <label className="relative flex min-h-[54px] flex-col justify-center border-t border-line-soft px-3 sm:border-t-0 lg:border-l">
                  <span className="flex items-center gap-1.5 text-[0.53rem] font-bold uppercase tracking-[0.16em] text-mist-dim">
                    <CalendarDays size={9} /> When
                  </span>
                  <select
                    value={when}
                    onChange={(event) => setWhen(event.target.value)}
                    aria-label="Choose a date range"
                    className="mt-0.5 w-[calc(100%-1rem)] cursor-pointer appearance-none border-0 bg-transparent p-0 font-sans text-[0.77rem] font-medium text-cream focus:outline-none"
                    style={{ colorScheme: "dark" }}
                  >
                    {WHEN_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value} className="bg-raised text-cream">
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <ChevronRight size={11} className="pointer-events-none absolute bottom-[21px] right-3 rotate-90 text-mist-dim" />
                </label>

                <div className="p-1 sm:col-span-2 lg:col-span-1 lg:p-0 lg:pl-2">
                  <button
                    type="submit"
                    className="group inline-flex min-h-[54px] w-full items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-gold px-5 text-[0.72rem] font-bold uppercase tracking-[0.09em] text-ink transition-all hover:bg-gold-bright hover:shadow-[0_0_35px_-8px_rgba(228,199,142,0.55)] lg:w-auto"
                  >
                    Find tickets
                    <ArrowRight size={15} className="transition-transform duration-300 group-hover:translate-x-0.5" />
                  </button>
                </div>
              </div>
            </form>

            <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-3">
              <div className="flex items-center gap-2">
                <div className="flex gap-0.5 text-gold" aria-label="Rated 4.9 out of 5">
                  {[0, 1, 2, 3, 4].map((star) => (
                    <Star key={star} size={11} fill="currentColor" />
                  ))}
                </div>
                <span className="text-[0.68rem] text-cream/65">
                  <span className="font-semibold text-cream">4.9</span> from 2,400+ guests
                </span>
              </div>
              <span className="hidden h-3 w-px bg-white/15 sm:block" />
              <span className="inline-flex items-center gap-1.5 text-[0.68rem] text-cream/65">
                <ShieldCheck size={12} className="text-sage" /> Secure, instant e-tickets
              </span>
              <span className="hidden h-3 w-px bg-white/15 sm:block" />
              <span className="inline-flex items-center gap-1.5 text-[0.68rem] text-cream/65">
                <Headphones size={12} className="text-gold/80" /> Local support, 7 days
              </span>
            </div>

            {/* Mobile spotlight */}
            <Link
              to={`/events/${featured.slug}`}
              className="glass group mt-8 flex items-center gap-3 rounded-2xl p-2.5 lg:hidden"
            >
              <img
                src={eventImage(featured, "card")}
                alt=""
                className="h-[78px] w-[66px] shrink-0 rounded-xl object-cover"
              />
              <div className="min-w-0 flex-1">
                <span className="block text-[0.52rem] font-bold uppercase tracking-[0.16em] text-gold">
                  Featured · {featured.category}
                </span>
                <span className="mt-0.5 block truncate font-display text-[1.35rem] leading-tight text-cream">
                  {featured.title}
                </span>
                <span className="mt-1 block text-[0.61rem] text-mist">
                  {formatEventDate(featured.date)} · {featuredVenue.city}
                </span>
              </div>
              <span className="grid size-8 shrink-0 place-items-center rounded-full border border-gold/30 text-gold transition-colors group-hover:bg-gold group-hover:text-ink">
                <ArrowUpRight size={14} />
              </span>
            </Link>
          </div>

          {/* Desktop spotlight card */}
          <div className="hidden lg:block">
            <Link
              to={`/events/${featured.slug}`}
              className="group relative block overflow-hidden rounded-[26px] border border-gold/25 bg-surface/35 p-2.5 shadow-[0_40px_100px_-50px_rgba(0,0,0,1)] backdrop-blur-xl transition-all duration-500 hover:border-gold/45 hover:shadow-[0_40px_100px_-40px_rgba(228,199,142,0.2)]"
            >
              <div className="flex items-center justify-between px-2 pb-2.5 pt-1">
                <span className="inline-flex items-center gap-1.5 text-[0.56rem] font-bold uppercase tracking-[0.17em] text-gold">
                  <span className="live-dot size-1.5 rounded-full bg-gold" /> The season&apos;s spotlight
                </span>
                <span className="text-[0.55rem] font-semibold tracking-[0.13em] text-cream/50">02 / 13 / 27</span>
              </div>
              <div className="relative overflow-hidden rounded-[18px]">
                <img
                  src={eventImage(featured, "poster")}
                  alt={`${featured.title} featuring ${featured.artist}`}
                  className="aspect-[0.89] w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" aria-hidden="true" />
                <span className="absolute left-3 top-3 rounded-full border border-white/20 bg-ink/45 px-2.5 py-1 text-[0.52rem] font-bold uppercase tracking-[0.14em] text-cream backdrop-blur">
                  {featured.category} · {featured.badge}
                </span>
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <p className="text-[0.53rem] font-bold uppercase tracking-[0.16em] text-gold">
                    {formatEventDate(featured.date)} · One night only
                  </p>
                  <h2 className="mt-1 font-display text-[2.05rem] leading-[0.96] text-cream">{featured.title}</h2>
                  <p className="mt-1.5 flex items-center gap-1.5 text-[0.62rem] font-light text-cream/70">
                    <MapPin size={10} /> {featuredVenue.name}, {featuredVenue.city}
                  </p>
                </div>
              </div>
              <div className="flex items-end justify-between gap-3 px-2 pb-1 pt-3.5">
                <div>
                  <p className="text-[0.49rem] font-bold uppercase tracking-[0.17em] text-mist-dim">Tickets from</p>
                  <p className="mt-0.5 text-[1.02rem] font-bold text-gold">{formatZAR(featured.priceFrom)}</p>
                </div>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-2 text-[0.6rem] font-bold uppercase tracking-[0.11em] text-cream/80 transition-colors group-hover:border-gold group-hover:bg-gold group-hover:text-ink">
                  Book tickets <ArrowUpRight size={12} />
                </span>
              </div>
            </Link>
            <div className="mt-3 flex items-center justify-between px-2 text-[0.57rem] font-medium text-cream/45">
              <span className="inline-flex items-center gap-1.5">
                <Ticket size={10} /> {featured.soldPercent}% sold
              </span>
              <span>Official OpenTickets partner</span>
            </div>
          </div>
        </div>

        <div className="shell relative z-10 mt-2 hidden border-t border-white/10 py-4 sm:block">
          <div className="flex flex-wrap items-center justify-between gap-x-8 gap-y-2">
            <span className="text-[0.55rem] font-bold uppercase tracking-[0.19em] text-cream/35">
              The stages you love
            </span>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
              {VENUE_LINE.slice(0, 6).map((venue) => (
                <span key={venue} className="font-display text-[1.05rem] text-cream/55">
                  {venue}
                </span>
              ))}
            </div>
            <span className="inline-flex items-center gap-1.5 text-[0.6rem] text-cream/40">
              <Zap size={11} className="text-gold/60" /> 2,400+ events booked this season
            </span>
          </div>
        </div>
      </section>

      {/* ============================= EVENT GRID ============================= */}
      <section className="section-y relative" id="events">
        <div className="shell">
          <Reveal className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <span className="eyebrow">Curated for you</span>
              <h2 className="mt-4 max-w-xl text-[clamp(2.65rem,4.5vw,4.2rem)] leading-[0.95] text-cream">
                The season&apos;s <em className="text-gold">best seats.</em>
              </h2>
              <p className="mt-4 max-w-lg text-[0.84rem] font-light leading-[1.85] text-mist">
                Hand-picked by people who actually go. Filter by the kind of night you&apos;re in the mood for — we&apos;ll
                handle the rest.
              </p>
            </div>
            <Link to="/events" className="group inline-flex shrink-0 items-center gap-2.5 text-[0.7rem] font-bold uppercase tracking-[0.14em] text-gold">
              Explore all events
              <span className="grid size-8 place-items-center rounded-full border border-gold/30 transition-all group-hover:bg-gold group-hover:text-ink">
                <ArrowRight size={13} />
              </span>
            </Link>
          </Reveal>

          <Reveal className="mt-10" delay={100}>
            <EventExplorer events={EVENTS} />
          </Reveal>
        </div>
      </section>

      {/* ============================= CATEGORIES ============================= */}
      <section className="relative overflow-hidden border-y border-line-soft bg-midnight/40 py-16 sm:py-20 lg:py-24">
        <div
          className="pointer-events-none absolute right-0 top-0 h-full w-1/2 opacity-40"
          style={{ background: "radial-gradient(circle at 75% 20%, rgba(228,199,142,0.08), transparent 60%)" }}
        />
        <div className="shell relative">
          <Reveal className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div>
              <span className="eyebrow">Find your frequency</span>
              <h2 className="mt-4 text-[clamp(2.45rem,4vw,3.7rem)] leading-none text-cream">
                However you <em className="text-gold">feel alive.</em>
              </h2>
            </div>
            <p className="max-w-xs text-[0.78rem] font-light leading-relaxed text-mist sm:text-right">
              Four stages, one home. Discover the kind of night that stays with you long after the lights go up.
            </p>
          </Reveal>

          <div className="mt-9 grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
            {CATEGORIES.map((category, index) => (
              <Reveal key={category.label} delay={index * 70}>
                <Link
                  to={`/events?category=${category.label}`}
                  className="group relative block h-full min-h-[330px] overflow-hidden rounded-[18px] border border-line-soft transition-all duration-500 hover:border-gold/40"
                >
                  <img
                    src={categoryPhoto(category.imageId)}
                    alt=""
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover opacity-65 transition-all duration-[1100ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105 group-hover:opacity-85"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-ink/10 transition-opacity duration-500 group-hover:from-ink/95" />
                  <div className="relative flex h-full min-h-[330px] flex-col justify-between p-5">
                    <div className="flex items-start justify-between">
                      <span className="grid size-9 place-items-center rounded-full border border-white/20 bg-ink/30 text-gold backdrop-blur-md">
                        <Sparkles size={15} strokeWidth={1.7} />
                      </span>
                      <span className="text-[0.55rem] font-bold uppercase tracking-[0.15em] text-cream/60">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                    </div>
                    <div>
                      <p className="text-[0.56rem] font-bold uppercase tracking-[0.16em] text-gold">
                        {categoryCountLabel(category.label)}
                      </p>
                      <div className="mt-1.5 flex items-end justify-between gap-2">
                        <h3 className="font-display text-[2.1rem] leading-none text-cream">{category.label}</h3>
                        <span className="mb-0.5 grid size-8 shrink-0 place-items-center rounded-full border border-gold/40 text-gold transition-all duration-300 group-hover:bg-gold group-hover:text-ink">
                          <ArrowUpRight size={14} />
                        </span>
                      </div>
                      <p className="mt-2 max-w-[220px] text-[0.68rem] font-light leading-relaxed text-cream/65">
                        {category.description}
                      </p>
                    </div>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============================= PROMISE ============================= */}
      <section className="section-y relative overflow-hidden">
        <div
          className="pointer-events-none absolute left-[5%] top-1/2 h-[380px] w-[380px] -translate-y-1/2 rounded-full blur-[130px]"
          style={{ background: "rgba(148,129,239,0.08)" }}
        />
        <div className="shell grid gap-10 lg:grid-cols-[0.92fr_1.08fr] lg:items-center lg:gap-20">
          <Reveal>
            <span className="eyebrow">The OpenTickets difference</span>
            <h2 className="mt-4 max-w-md text-[clamp(2.6rem,4.4vw,4rem)] leading-[0.96] text-cream">
              The night is yours.
              <br />
              The <em className="text-gold">fuss is ours.</em>
            </h2>
            <p className="mt-5 max-w-sm text-[0.84rem] font-light leading-[1.85] text-mist">
              We started OpenTickets because finding an incredible night out should feel as good as being there. No
              hidden fees. No endless forms. Just the good seats and a promise we keep.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/events"
                className="inline-flex min-h-12 items-center gap-2 rounded-[10px] bg-gold px-5 text-[0.73rem] font-bold tracking-[0.03em] text-ink transition-all hover:bg-gold-bright"
              >
                Find something brilliant <ArrowRight size={15} />
              </Link>
              <Link
                to="/faqs"
                className="inline-flex min-h-12 items-center gap-2 rounded-[10px] border border-line px-5 text-[0.73rem] font-semibold text-cream transition-all hover:border-gold/40 hover:text-gold"
              >
                How it works
              </Link>
            </div>
            <div className="mt-8 flex items-center gap-5 border-t border-line-soft pt-5">
              <div>
                <p className="font-display text-3xl text-cream">18k+</p>
                <p className="mt-1 text-[0.58rem] font-semibold uppercase tracking-[0.14em] text-mist-dim">Happy guests</p>
              </div>
              <div className="h-8 w-px bg-line" />
              <div>
                <p className="font-display text-3xl text-cream">120+</p>
                <p className="mt-1 text-[0.58rem] font-semibold uppercase tracking-[0.14em] text-mist-dim">Live partners</p>
              </div>
              <div className="h-8 w-px bg-line" />
              <div>
                <p className="flex items-center gap-1 font-display text-3xl text-cream">
                  4.9 <Star size={13} fill="#e4c78e" className="text-gold" />
                </p>
                <p className="mt-1 text-[0.58rem] font-semibold uppercase tracking-[0.14em] text-mist-dim">Guest rating</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120} className="space-y-3">
            {[
              {
                number: "01",
                icon: ShieldCheck,
                title: "Fair from the first click.",
                copy: "The price you see is the price you pay. Booking fees are included, always — no ugly surprises at the final step.",
              },
              {
                number: "02",
                icon: Zap,
                title: "Your tickets, instantly.",
                copy: "Secure e-tickets land in your inbox and account the moment you book. Show your QR code at the door and walk in.",
              },
              {
                number: "03",
                icon: Headphones,
                title: "Real humans, on your side.",
                copy: "Our Cape Town support team knows the venues, the shows and the shortcuts. Seven days a week, from 08:00 to 21:00.",
              },
            ].map(({ number, icon: Icon, title, copy }) => (
              <div
                key={number}
                className="group flex gap-4 rounded-2xl border border-line-soft bg-surface/30 p-5 transition-all duration-300 hover:border-gold/25 hover:bg-surface/55 sm:gap-5 sm:p-6"
              >
                <div className="flex shrink-0 flex-col items-center gap-2.5">
                  <span className="grid size-10 place-items-center rounded-full border border-gold/25 bg-gold/[0.07] text-gold">
                    <Icon size={17} strokeWidth={1.6} />
                  </span>
                  <span className="font-sans text-[0.5rem] font-bold tracking-[0.16em] text-mist-dim">{number}</span>
                </div>
                <div>
                  <h3 className="font-sans text-[0.9rem] font-semibold tracking-[-0.015em] text-cream">{title}</h3>
                  <p className="mt-1.5 text-[0.76rem] font-light leading-[1.8] text-mist">{copy}</p>
                </div>
                <Check size={14} className="ml-auto mt-1 hidden shrink-0 text-gold/0 transition-colors group-hover:text-gold/70 sm:block" />
              </div>
            ))}
            <div className="flex items-center gap-2 px-2 pt-2 text-[0.62rem] font-light text-mist-dim">
              <Clock3 size={11} className="text-gold/70" />
              Average booking time: 90 seconds. We timed it.
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============================= TESTIMONIAL / CTA ============================= */}
      <section className="relative overflow-hidden border-t border-line-soft">
        <img
          src="https://images.pexels.com/photos/34862400/pexels-photo-34862400.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1800&h=800"
          alt=""
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/92 to-ink/70" />
        <div className="shell relative py-16 sm:py-20 lg:py-24">
          <div className="grid gap-10 lg:grid-cols-[1.06fr_0.94fr] lg:items-center">
            <Reveal>
              <span className="eyebrow">Words from the floor</span>
              <blockquote className="mt-5 max-w-xl font-display text-[clamp(2.2rem,4.2vw,3.6rem)] leading-[1.03] text-cream">
                “Finally, a ticketing site that feels like the <em className="text-gold">night itself.</em>”
              </blockquote>
              <div className="mt-5 flex items-center gap-3">
                <span className="grid size-9 place-items-center rounded-full border border-gold/30 bg-gold/10 text-[0.65rem] font-bold text-gold">
                  ZM
                </span>
                <div>
                  <p className="text-[0.73rem] font-semibold text-cream">Zanele M.</p>
                  <p className="text-[0.61rem] text-mist">Kirstenbosch · Cape Town</p>
                </div>
                <div className="ml-3 flex gap-0.5 text-gold">
                  {[0, 1, 2, 3, 4].map((star) => (
                    <Star key={star} size={10} fill="currentColor" />
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={120} className="glass rounded-2xl p-6 sm:p-8">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-[0.56rem] font-bold uppercase tracking-[0.17em] text-gold">There&apos;s always something on</p>
                  <h2 className="mt-2 font-display text-[2rem] leading-none text-cream">Your next great night starts here.</h2>
                </div>
                <Ticket size={28} className="shrink-0 text-gold/50" strokeWidth={1.2} />
              </div>
              <p className="mt-3 text-[0.76rem] font-light leading-relaxed text-mist">
                From the front row to the picnic lawn. One account, instant tickets and a shortlist of the nights worth
                clearing your calendar for.
              </p>
              <Link
                to="/events"
                className="group mt-5 inline-flex min-h-12 w-full items-center justify-between rounded-[10px] bg-gold px-4 text-[0.73rem] font-bold tracking-[0.04em] text-ink transition-colors hover:bg-gold-bright"
              >
                Explore all events
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
              </Link>
              <div className="mt-4 grid grid-cols-3 gap-2 border-t border-line-soft pt-4">
                {[
                  { value: "12", label: "Curated events" },
                  { value: "7", label: "Cities" },
                  { value: "24/7", label: "Secure access" },
                ].map((stat) => (
                  <div key={stat.label}>
                    <p className="font-display text-xl text-cream">{stat.value}</p>
                    <p className="mt-0.5 text-[0.53rem] uppercase tracking-[0.1em] text-mist-dim">{stat.label}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}

function categoryCountLabel(category: string) {
  return `${EVENTS.filter((event) => event.category === category).length} experiences`;
}
