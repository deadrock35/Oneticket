import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  ChevronDown,
  Grid2X2,
  List,
  RotateCcw,
  Search,
  SearchX,
  SlidersHorizontal,
  Sparkles,
  X,
} from "lucide-react";
import { EventCard } from "../components/events/EventCard";
import { EventListItem } from "../components/search/EventListItem";
import { FilterPanel, SEASONS, type FilterState } from "../components/search/FilterPanel";
import { CATEGORIES, EVENTS, formatZAR, getVenue, type Category } from "../data/events";
import { Link, useRouter } from "../lib/router";
import { cn } from "../utils/cn";

type SortKey = "popular" | "date" | "price-low" | "price-high";
type ViewMode = "grid" | "list";

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "popular", label: "Most popular" },
  { value: "date", label: "Date: soonest" },
  { value: "price-low", label: "Price: low to high" },
  { value: "price-high", label: "Price: high to low" },
];

const DEFAULT_FILTERS: FilterState = {
  categories: [],
  city: "All cities",
  venue: "All venues",
  dateFrom: "",
  dateTo: "",
  season: "any",
  maxPrice: 3500,
};

const HERO_IMAGE =
  "https://images.pexels.com/photos/39004762/pexels-photo-39004762.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900";

const prettyDate = (value: string) => {
  if (!value) return "";
  const date = new Date(`${value}T12:00:00+02:00`);
  return new Intl.DateTimeFormat("en-ZA", { day: "numeric", month: "short", year: "numeric", timeZone: "Africa/Johannesburg" }).format(date);
};

export function SearchPage() {
  const { path, query, navigate } = useRouter();
  const browseMode = path === "/events";
  const queryKey = query.toString();
  const [term, setTerm] = useState("");
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortKey>("popular");
  const [view, setView] = useState<ViewMode>("grid");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const urlTerm = query.get("q") ?? "";
    const categoryParam = query.get("category");
    const matchedCategory = CATEGORIES.find((category) => category.label.toLowerCase() === categoryParam?.toLowerCase());
    const seasonParam = query.get("when") ?? "any";
    const season = SEASONS.find((item) => item.value === seasonParam);
    setTerm(urlTerm);
    setFilters({
      ...DEFAULT_FILTERS,
      categories: matchedCategory ? [matchedCategory.label] : [],
      city: query.get("city") ?? "All cities",
      season: season?.value ?? "any",
      dateFrom: season?.from ?? "",
      dateTo: season?.to ?? "",
    });
    setSort("popular");
    // Read the URL whenever the hash route changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey]);

  useEffect(() => {
    if (!filtersOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [filtersOpen]);

  const updateFilters = (next: Partial<FilterState>) => setFilters((current) => ({ ...current, ...next }));

  const toggleCategory = (category: Category) =>
    setFilters((current) => ({
      ...current,
      categories: current.categories.includes(category)
        ? current.categories.filter((item) => item !== category)
        : [...current.categories, category],
    }));

  const applySeason = (value: string) => {
    const nextSeason = SEASONS.find((season) => season.value === value);
    updateFilters({
      season: value,
      dateFrom: nextSeason?.from ?? "",
      dateTo: nextSeason?.to ?? "",
    });
  };

  const resetAll = () => {
    setFilters(DEFAULT_FILTERS);
    setTerm("");
  };

  const results = useMemo(() => {
    const needle = term.trim().toLowerCase();
    const filtered = EVENTS.filter((event) => {
      const venue = getVenue(event);
      const haystack = [event.title, event.artist, event.category, event.tagline, event.description.join(" "), venue.name, venue.city]
        .join(" ")
        .toLowerCase();
      if (needle && !haystack.includes(needle)) return false;
      if (filters.categories.length > 0 && !filters.categories.includes(event.category)) return false;
      if (filters.city !== "All cities" && venue.city !== filters.city) return false;
      if (filters.venue !== "All venues" && venue.name !== filters.venue) return false;
      if (event.priceFrom > filters.maxPrice) return false;
      const eventDay = event.date.slice(0, 10);
      if (filters.dateFrom && eventDay < filters.dateFrom) return false;
      if (filters.dateTo && eventDay > filters.dateTo) return false;
      return true;
    });

    return filtered.sort((a, b) => {
      if (sort === "date") return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (sort === "price-low") return a.priceFrom - b.priceFrom;
      if (sort === "price-high") return b.priceFrom - a.priceFrom;
      return Number(Boolean(b.trending)) - Number(Boolean(a.trending)) || b.soldPercent - a.soldPercent;
    });
  }, [term, filters, sort]);

  const activeCount =
    (term.trim() ? 1 : 0) +
    filters.categories.length +
    (filters.city !== "All cities" ? 1 : 0) +
    (filters.venue !== "All venues" ? 1 : 0) +
    (filters.dateFrom || filters.dateTo ? 1 : 0) +
    (filters.maxPrice < 3500 ? 1 : 0);

  const activeChips: { key: string; label: string; onClear: () => void }[] = [];
  if (term.trim()) activeChips.push({ key: "term", label: `“${term.trim()}”`, onClear: () => setTerm("") });
  filters.categories.forEach((category) =>
    activeChips.push({
      key: `cat-${category}`,
      label: category,
      onClear: () => setFilters((current) => ({ ...current, categories: current.categories.filter((item) => item !== category) })),
    })
  );
  if (filters.city !== "All cities")
    activeChips.push({ key: "city", label: filters.city, onClear: () => updateFilters({ city: "All cities" }) });
  if (filters.venue !== "All venues")
    activeChips.push({ key: "venue", label: filters.venue, onClear: () => updateFilters({ venue: "All venues" }) });
  if (filters.dateFrom || filters.dateTo)
    activeChips.push({
      key: "date",
      label: `${filters.dateFrom ? prettyDate(filters.dateFrom) : "Any"} – ${filters.dateTo ? prettyDate(filters.dateTo) : "Any"}`,
      onClear: () => updateFilters({ dateFrom: "", dateTo: "", season: "any" }),
    });
  if (filters.maxPrice < 3500)
    activeChips.push({
      key: "price",
      label: `Up to ${formatZAR(filters.maxPrice)}`,
      onClear: () => updateFilters({ maxPrice: 3500 }),
    });

  const searchHeadline = (() => {
    if (browseMode) {
      return (
        <>
          Every night worth <em className="text-gold">your time.</em>
        </>
      );
    }
    if (term.trim()) {
      return (
        <>
          Results for <em className="text-gold">“{term.trim()}”.</em>
        </>
      );
    }
    return (
      <>
        Find your next <em className="text-gold">great night.</em>
      </>
    );
  })();

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      {/* ============================= HEADER ============================= */}
      <section className="relative overflow-hidden border-b border-line-soft pt-[118px] sm:pt-[138px]">
        <img src={HERO_IMAGE} alt="" className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.2]" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/94 to-ink/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
        <div
          className="pointer-events-none absolute right-[8%] top-1/3 h-[260px] w-[340px] rounded-full blur-[110px]"
          style={{ background: "rgba(228,199,142,0.11)" }}
        />
        <div className="shell relative pb-10 sm:pb-12">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 pt-4 text-[0.62rem] font-medium text-mist-dim sm:pt-0">
            <Link to="/" className="transition-colors hover:text-gold">
              Home
            </Link>
            <span className="text-line-strong">/</span>
            <span className="text-cream/70">{browseMode ? "All events" : "Search"}</span>
          </nav>

          <div className="mt-6 grid gap-7 lg:grid-cols-[1fr_0.7fr] lg:items-end">
            <div>
              <span className="eyebrow">{browseMode ? "The full season" : "Discover something extraordinary"}</span>
              <h1 className="mt-4 max-w-[720px] text-[clamp(2.9rem,5.8vw,5rem)] leading-[0.94] text-cream">{searchHeadline}</h1>
              <p className="mt-4 max-w-xl text-[0.84rem] font-light leading-[1.8] text-mist">
                {browseMode
                  ? "From stadium anthems and late-night comedy to brave new theatre and long festival weekends. It's all here, and it's all yours."
                  : "Search by artist, venue or mood. Every ticket comes with our fair-price promise and instant delivery."}
              </p>
            </div>
            <div className="flex flex-wrap gap-2 lg:justify-end">
              {CATEGORIES.map((category) => (
                <Link
                  key={category.label}
                  to={`/search?category=${category.label}`}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[0.64rem] font-semibold transition-all",
                    filters.categories.includes(category.label)
                      ? "border-gold/60 bg-gold/12 text-gold"
                      : "border-line text-mist hover:border-gold/35 hover:text-cream"
                  )}
                >
                  <span className="size-1 rounded-full bg-current opacity-70" /> {category.label}
                </Link>
              ))}
            </div>
          </div>

          <form onSubmit={submitSearch} className="glass mt-7 flex flex-col gap-2 rounded-xl p-2 sm:flex-row">
            <div className="relative flex-1">
              <Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gold" />
              <input
                type="search"
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                aria-label="Search events, artists, venues or cities"
                placeholder="Search events, artists, venues or cities"
                className="min-h-[48px] w-full rounded-lg border-0 bg-transparent pl-10 pr-3 text-[0.8rem] text-cream placeholder:text-mist-dim focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setFiltersOpen(true)}
                className="inline-flex min-h-[48px] items-center gap-1.5 rounded-lg border border-line px-3 text-[0.7rem] font-semibold text-mist transition-colors hover:border-gold/40 hover:text-cream lg:hidden"
              >
                <SlidersHorizontal size={14} /> Filters
                {activeCount > 0 && <span className="grid size-4 place-items-center rounded-full bg-gold text-[0.5rem] text-ink">{activeCount}</span>}
              </button>
              <button
                type="submit"
                className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-lg bg-gold px-5 text-[0.72rem] font-bold uppercase tracking-[0.08em] text-ink transition-colors hover:bg-gold-bright sm:flex-none"
              >
                Update search <ArrowRight size={14} />
              </button>
            </div>
          </form>

          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.64rem] text-cream/55">
            <span className="inline-flex items-center gap-1.5">
              <Sparkles size={11} className="text-gold" /> {EVENTS.length} curated experiences
            </span>
            <span className="hidden h-2.5 w-px bg-white/15 sm:block" />
            <span>Johannesburg · Cape Town · Pretoria · Winelands</span>
            <span className="hidden h-2.5 w-px bg-white/15 sm:block" />
            <span>Fair fees, always</span>
          </div>
        </div>
      </section>

      {/* ============================= RESULTS ============================= */}
      <section className="pb-16 pt-6 sm:pb-20 sm:pt-8" ref={resultsRef}>
        <div className="shell grid gap-7 lg:grid-cols-[276px_minmax(0,1fr)] lg:gap-8 xl:gap-10">
          <aside className="hidden lg:block">
            <div className="sticky top-[92px]">
              <FilterPanel
                filters={filters}
                onChange={updateFilters}
                onReset={resetAll}
                onSeason={applySeason}
                onToggleCategory={toggleCategory}
                resultCount={results.length}
              />
            </div>
          </aside>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line-soft pb-4">
              <div>
                <p className="font-sans text-[0.78rem] font-semibold text-cream">
                  {results.length} event{results.length === 1 ? "" : "s"}
                  {filters.categories.length > 0 && <span className="text-mist"> in {filters.categories.join(" & ")}</span>}
                </p>
                <p className="mt-0.5 text-[0.62rem] text-mist-dim">
                  {browseMode ? "The complete OpenTickets collection" : "Matching your search and filters"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setFiltersOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3 py-2 text-[0.66rem] font-semibold text-cream transition-colors hover:border-gold/40 lg:hidden"
                >
                  <SlidersHorizontal size={13} /> Filters
                  {activeCount > 0 && <span className="text-gold">({activeCount})</span>}
                </button>
                <div className="relative">
                  <label htmlFor="sort-events" className="sr-only">
                    Sort events
                  </label>
                  <select
                    id="sort-events"
                    value={sort}
                    onChange={(event) => setSort(event.target.value as SortKey)}
                    className="h-9 appearance-none rounded-lg border border-line bg-surface/55 pl-3 pr-8 text-[0.66rem] font-medium text-cream focus:outline-none focus-visible:border-gold"
                  >
                    {SORT_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value} className="bg-raised">
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={11} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-mist-dim" />
                </div>
                <div className="hidden items-center rounded-lg border border-line p-0.5 sm:flex">
                  <button
                    type="button"
                    onClick={() => setView("grid")}
                    aria-label="Grid view"
                    aria-pressed={view === "grid"}
                    className={cn(
                      "grid size-8 place-items-center rounded-md transition-colors",
                      view === "grid" ? "bg-gold text-ink" : "text-mist hover:text-cream"
                    )}
                  >
                    <Grid2X2 size={14} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setView("list")}
                    aria-label="List view"
                    aria-pressed={view === "list"}
                    className={cn(
                      "grid size-8 place-items-center rounded-md transition-colors",
                      view === "list" ? "bg-gold text-ink" : "text-mist hover:text-cream"
                    )}
                  >
                    <List size={15} />
                  </button>
                </div>
              </div>
            </div>

            {activeChips.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 py-3">
                <span className="mr-1 text-[0.58rem] font-bold uppercase tracking-[0.11em] text-mist-dim">Active</span>
                {activeChips.map((chip) => (
                  <button
                    key={chip.key}
                    type="button"
                    onClick={chip.onClear}
                    className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/[0.07] py-1 pl-2.5 pr-1.5 text-[0.62rem] font-medium text-gold-bright transition-colors hover:bg-gold/15"
                  >
                    {chip.label}
                    <span className="grid size-4 place-items-center rounded-full bg-gold/15 text-gold">
                      <X size={9} />
                    </span>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={resetAll}
                  className="ml-1 inline-flex items-center gap-1 text-[0.59rem] font-semibold text-mist underline-offset-4 hover:text-cream hover:underline"
                >
                  <RotateCcw size={9} /> Clear all
                </button>
              </div>
            )}

            {results.length > 0 ? (
              view === "grid" ? (
                <div className={cn("grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3", activeChips.length > 0 ? "mt-1" : "mt-5")}>
                  {results.map((event) => (
                    <EventCard key={event.slug} event={event} />
                  ))}
                </div>
              ) : (
                <div className={cn("space-y-3", activeChips.length > 0 ? "mt-1" : "mt-5")}>
                  {results.map((event) => (
                    <EventListItem key={event.slug} event={event} />
                  ))}
                </div>
              )
            ) : (
              <div className="relative mt-5 overflow-hidden rounded-2xl border border-line-soft bg-surface/30 px-6 py-16 text-center sm:py-20">
                <div
                  className="pointer-events-none absolute left-1/2 top-0 h-64 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full blur-[100px]"
                  style={{ background: "rgba(228,199,142,0.09)" }}
                />
                <div className="relative mx-auto grid size-16 place-items-center rounded-full border border-line bg-ink/50 text-gold">
                  <SearchX size={25} strokeWidth={1.5} />
                  <span className="absolute -inset-3 rounded-full border border-line-soft" />
                  <span className="absolute -inset-7 rounded-full border border-white/[0.045]" />
                </div>
                <span className="eyebrow no-rule relative mt-7 justify-center text-gold">Nothing on just yet</span>
                <h2 className="relative mt-3 font-display text-[2.2rem] leading-tight text-cream sm:text-[2.7rem]">
                  No nights match that combination.
                </h2>
                <p className="relative mx-auto mt-2 max-w-md text-[0.8rem] font-light leading-relaxed text-mist">
                  Try widening your date range, lifting the price cap or exploring another category. The perfect night is
                  still out there.
                </p>
                <div className="relative mt-6 flex flex-col items-center justify-center gap-2.5 sm:flex-row">
                  <button
                    type="button"
                    onClick={resetAll}
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-gold px-5 text-[0.71rem] font-bold uppercase tracking-[0.06em] text-ink transition-colors hover:bg-gold-bright"
                  >
                    <RotateCcw size={13} /> Clear all filters
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate("/events")}
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-4 text-[0.71rem] font-semibold text-cream transition-colors hover:border-gold/40 hover:text-gold"
                  >
                    Browse everything <ArrowRight size={13} />
                  </button>
                </div>
                <div className="relative mt-7 flex flex-wrap items-center justify-center gap-2">
                  <span className="text-[0.58rem] uppercase tracking-[0.12em] text-mist-dim">Try</span>
                  {(["Music", "Comedy", "Theatre", "Festivals"] as Category[]).map((category) => (
                    <button
                      key={category}
                      type="button"
                      onClick={() => {
                        resetAll();
                        setFilters((current) => ({ ...current, categories: [category] }));
                      }}
                      className="rounded-full border border-line px-3 py-1 text-[0.63rem] text-mist transition-colors hover:border-gold/40 hover:text-gold"
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Mobile filter drawer */}
      {filtersOpen && (
        <div
          className="fixed inset-0 z-[78] bg-ink/75 backdrop-blur-sm animate-overlay lg:hidden"
          onClick={() => setFiltersOpen(false)}
          role="presentation"
        >
          <div
            onClick={(event) => event.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label="Filter events"
            className="animate-slide-in ml-auto flex h-full w-full max-w-[350px] flex-col border-l border-line bg-midnight shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-line-soft px-4 py-4">
              <div>
                <p className="text-[0.55rem] font-bold uppercase tracking-[0.16em] text-gold">Refine the search</p>
                <h2 className="mt-0.5 font-display text-2xl text-cream">Find your night</h2>
              </div>
              <button
                type="button"
                onClick={() => setFiltersOpen(false)}
                aria-label="Close filters"
                className="grid size-8 place-items-center rounded-full border border-line text-mist transition-colors hover:text-cream"
              >
                <X size={15} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <FilterPanel
                filters={filters}
                onChange={updateFilters}
                onReset={resetAll}
                onSeason={applySeason}
                onToggleCategory={toggleCategory}
                resultCount={results.length}
                className="border-0 bg-transparent p-0"
              />
            </div>
            <div className="border-t border-line-soft p-4">
              <button
                type="button"
                onClick={() => setFiltersOpen(false)}
                className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-[10px] bg-gold text-[0.73rem] font-bold text-ink"
              >
                Show {results.length} event{results.length === 1 ? "" : "s"} <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
