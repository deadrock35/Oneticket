import { useMemo, useState } from "react";
import {
  ArrowRight,
  ChevronRight,
  CircleHelp,
  Clock3,
  CreditCard,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Search,
  SearchX,
  ShieldCheck,
  Sparkles,
  Ticket,
  UserRound,
  X,
} from "lucide-react";
import { Accordion } from "../components/ui/Accordion";
import { FAQ_CATEGORIES } from "../data/faqs";
import { Link } from "../lib/router";
import { cn } from "../utils/cn";

const ICONS = {
  ticket: Ticket,
  venue: MapPin,
  account: UserRound,
  general: CircleHelp,
};

const ALL = "all";

export function FaqsPage() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>(ALL);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return FAQ_CATEGORIES.filter((category) => activeCategory === ALL || category.id === activeCategory)
      .map((category) => ({
        ...category,
        items: needle
          ? category.items.filter((item) => `${item.q} ${item.a}`.toLowerCase().includes(needle))
          : category.items,
      }))
      .filter((category) => category.items.length > 0);
  }, [query, activeCategory]);

  const resultCount = filtered.reduce((count, category) => count + category.items.length, 0);
  const totalQuestions = FAQ_CATEGORIES.reduce((count, category) => count + category.items.length, 0);

  const scrollToArticle = (id: string) => {
    setActiveCategory(id);
    window.setTimeout(() => {
      document.getElementById(`faq-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 40);
  };

  return (
    <>
      {/* ============================= HERO ============================= */}
      <section className="relative overflow-hidden border-b border-line-soft pt-[120px] sm:pt-[140px]">
        <div
          className="pointer-events-none absolute -right-24 top-0 h-[480px] w-[520px] rounded-full blur-[130px]"
          style={{ background: "rgba(228,199,142,0.11)" }}
        />
        <div
          className="pointer-events-none absolute -left-20 bottom-0 h-[320px] w-[380px] rounded-full blur-[120px]"
          style={{ background: "rgba(148,129,239,0.07)" }}
        />
        <div
          className="pointer-events-none absolute right-[7%] top-24 hidden select-none font-display text-[22rem] italic leading-none text-gold/[0.035] lg:block"
          aria-hidden="true"
        >
          ?
        </div>

        <div className="shell relative pb-12">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-[0.62rem] font-medium text-mist-dim">
            <Link to="/" className="transition-colors hover:text-gold">
              Home
            </Link>
            <ChevronRight size={10} />
            <span className="text-cream/70">Help & FAQs</span>
          </nav>

          <div className="mt-7 max-w-3xl">
            <span className="eyebrow">We&apos;ve got you</span>
            <h1 className="mt-4 text-[clamp(2.9rem,6vw,5rem)] leading-[0.93] text-cream">
              Answers, before <em className="text-gold">the applause.</em>
            </h1>
            <p className="mt-4 max-w-xl text-[0.86rem] font-light leading-[1.85] text-mist">
              Everything you need to know about booking, your tickets and the night itself. If you can&apos;t find it here,
              our Cape Town team is one message away.
            </p>
          </div>

          <div className="glass mt-7 max-w-2xl rounded-2xl p-2">
            <div className="relative">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gold" />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search the answer you're looking for"
                aria-label="Search frequently asked questions"
                className="h-[52px] w-full rounded-xl border border-transparent bg-transparent pl-11 pr-11 text-[0.83rem] text-cream placeholder:text-mist-dim focus:border-line focus:bg-ink/30 focus:outline-none"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Clear FAQ search"
                  className="absolute right-3 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-full border border-line text-mist transition-colors hover:text-cream"
                >
                  <X size={12} />
                </button>
              )}
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-[0.64rem]">
            <span className="font-bold uppercase tracking-[0.13em] text-mist-dim">Quick answers</span>
            {["Refunds", "Transfer tickets", "Accessibility", "Payment methods"].map((topic) => (
              <button
                key={topic}
                type="button"
                onClick={() => setQuery(topic.split(" ")[0])}
                className="rounded-full border border-line px-2.5 py-1 text-mist transition-colors hover:border-gold/40 hover:text-gold"
              >
                {topic}
              </button>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-line-soft pt-4 text-[0.64rem] text-mist">
            <span className="inline-flex items-center gap-1.5">
              <Clock3 size={11} className="text-gold/80" /> Average response: 2 hours
            </span>
            <span className="hidden h-3 w-px bg-line sm:block" />
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck size={11} className="text-sage" /> {totalQuestions} answers, always up to date
            </span>
            <span className="hidden h-3 w-px bg-line sm:block" />
            <span className="inline-flex items-center gap-1.5">
              <MessageCircle size={11} className="text-gold/80" /> Support open 08:00–21:00
            </span>
          </div>
        </div>
      </section>

      {/* ============================= CONTENT ============================= */}
      <section className="section-y pt-10 sm:pt-12">
        <div className="shell grid gap-8 lg:grid-cols-[256px_minmax(0,1fr)] xl:gap-12">
          <aside>
            <div className="lg:sticky lg:top-[92px]">
              <div className="rounded-2xl border border-line bg-surface/35 p-4">
                <p className="text-[0.57rem] font-bold uppercase tracking-[0.17em] text-gold">Browse by topic</p>
                <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto lg:flex-col lg:overflow-visible">
                  <button
                    type="button"
                    onClick={() => setActiveCategory(ALL)}
                    className={cn(
                      "flex shrink-0 items-center gap-2 rounded-lg px-3 py-2.5 text-left text-[0.71rem] font-medium transition-all lg:w-full",
                      activeCategory === ALL ? "bg-gold text-ink" : "text-mist hover:bg-white/[0.05] hover:text-cream"
                    )}
                  >
                    <Sparkles size={13} /> All questions
                    <span className={cn("ml-auto hidden text-[0.58rem] lg:block", activeCategory === ALL ? "text-ink/60" : "text-mist-dim")}>
                      {totalQuestions}
                    </span>
                  </button>
                  {FAQ_CATEGORIES.map((category) => {
                    const Icon = ICONS[category.icon];
                    const active = activeCategory === category.id;
                    return (
                      <button
                        key={category.id}
                        type="button"
                        onClick={() => scrollToArticle(category.id)}
                        className={cn(
                          "flex shrink-0 items-center gap-2 rounded-lg px-3 py-2.5 text-left text-[0.71rem] font-medium transition-all lg:w-full",
                          active ? "bg-gold text-ink" : "text-mist hover:bg-white/[0.05] hover:text-cream"
                        )}
                      >
                        <Icon size={13} /> {category.title}
                        <span className={cn("ml-auto hidden text-[0.58rem] lg:block", active ? "text-ink/60" : "text-mist-dim")}>
                          {category.items.length}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="mt-3 hidden rounded-2xl border border-gold/20 bg-gradient-to-br from-gold/[0.08] to-transparent p-4 lg:block">
                <span className="grid size-9 place-items-center rounded-full border border-gold/30 bg-gold/10 text-gold">
                  <MessageCircle size={16} />
                </span>
                <p className="mt-3 font-display text-[1.4rem] leading-tight text-cream">Still stuck?</p>
                <p className="mt-1 text-[0.67rem] font-light leading-relaxed text-mist">
                  A real person from our Cape Town team will sort it out.
                </p>
                <a
                  href="mailto:support@opentickets.co.za"
                  className="mt-3 inline-flex items-center gap-1 text-[0.62rem] font-bold uppercase tracking-[0.08em] text-gold hover:text-gold-bright"
                >
                  Email support <ArrowRight size={11} />
                </a>
              </div>
            </div>
          </aside>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line-soft pb-4">
              <div>
                <p className="font-sans text-[0.78rem] font-semibold text-cream">
                  {query.trim() ? `${resultCount} answer${resultCount === 1 ? "" : "s"} for “${query.trim()}”` : "Frequently asked questions"}
                </p>
                <p className="mt-0.5 text-[0.62rem] text-mist-dim">
                  {activeCategory === ALL ? "Everything, in one place" : FAQ_CATEGORIES.find((category) => category.id === activeCategory)?.description}
                </p>
              </div>
              {(query || activeCategory !== ALL) && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery("");
                    setActiveCategory(ALL);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[0.62rem] text-mist transition-colors hover:border-gold/40 hover:text-gold"
                >
                  <X size={10} /> Clear search
                </button>
              )}
            </div>

            {filtered.length > 0 ? (
              <div className="mt-6 space-y-8">
                {filtered.map((category) => {
                  const Icon = ICONS[category.icon];
                  return (
                    <section
                      key={category.id}
                      id={`faq-${category.id}`}
                      className="scroll-mt-28 rounded-2xl border border-line-soft bg-surface/25 p-5 sm:p-6"
                    >
                      <div className="mb-3 flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3">
                          <span className="grid size-9 shrink-0 place-items-center rounded-full border border-gold/25 bg-gold/[0.07] text-gold">
                            <Icon size={16} strokeWidth={1.6} />
                          </span>
                          <div>
                            <h2 className="font-display text-[1.7rem] leading-none text-cream">{category.title}</h2>
                            <p className="mt-1 text-[0.66rem] font-light text-mist">{category.description}</p>
                          </div>
                        </div>
                        <span className="rounded-full border border-line px-2 py-0.5 text-[0.55rem] text-mist-dim">
                          {category.items.length}
                        </span>
                      </div>
                      <Accordion items={category.items} defaultOpen={0} highlight={query} />
                    </section>
                  );
                })}
              </div>
            ) : (
              <div className="relative mt-6 overflow-hidden rounded-2xl border border-line-soft bg-surface/30 px-6 py-16 text-center">
                <div
                  className="pointer-events-none absolute left-1/2 top-0 h-56 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full blur-[90px]"
                  style={{ background: "rgba(228,199,142,0.1)" }}
                />
                <span className="relative mx-auto grid size-14 place-items-center rounded-full border border-line bg-ink/50 text-gold">
                  <SearchX size={23} strokeWidth={1.5} />
                </span>
                <p className="relative mt-5 font-display text-[2.1rem] leading-tight text-cream">No answer for that — yet.</p>
                <p className="relative mx-auto mt-2 max-w-sm text-[0.78rem] font-light leading-relaxed text-mist">
                  Try another phrase or topic. If you still can&apos;t find it, ask us directly — we usually reply within two
                  hours.
                </p>
                <div className="relative mt-5 flex flex-col items-center justify-center gap-2.5 sm:flex-row">
                  <button
                    type="button"
                    onClick={() => {
                      setQuery("");
                      setActiveCategory(ALL);
                    }}
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-gold px-4 text-[0.69rem] font-bold uppercase tracking-[0.05em] text-ink hover:bg-gold-bright"
                  >
                    Reset FAQ filters
                  </button>
                  <a
                    href="mailto:support@opentickets.co.za"
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-4 text-[0.69rem] font-semibold text-cream hover:border-gold/40 hover:text-gold"
                  >
                    <Mail size={13} /> Email our team
                  </a>
                </div>
              </div>
            )}

            {/* Support channels */}
            <div className="mt-10">
              <span className="eyebrow">Talk to a human</span>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                {[
                  {
                    icon: Mail,
                    title: "Email us",
                    detail: "support@opentickets.co.za",
                    note: "Replies within 2 hours",
                    href: "mailto:support@opentickets.co.za",
                  },
                  {
                    icon: Phone,
                    title: "Call the team",
                    detail: "021 555 0198",
                    note: "08:00–21:00, 7 days",
                    href: "tel:+27215550198",
                  },
                  {
                    icon: CreditCard,
                    title: "Payment help",
                    detail: "payments@opentickets.co.za",
                    note: "Secure payment support",
                    href: "mailto:payments@opentickets.co.za",
                  },
                ].map(({ icon: Icon, title, detail, note, href }) => (
                  <a
                    key={title}
                    href={href}
                    className="group rounded-xl border border-line-soft bg-surface/35 p-4 transition-all hover:border-gold/30 hover:bg-surface/55"
                  >
                    <span className="grid size-8 place-items-center rounded-full border border-gold/25 bg-gold/[0.07] text-gold">
                      <Icon size={14} />
                    </span>
                    <p className="mt-3 text-[0.73rem] font-semibold text-cream">{title}</p>
                    <p className="mt-0.5 truncate text-[0.65rem] text-gold/90">{detail}</p>
                    <p className="mt-1 text-[0.58rem] text-mist-dim">{note}</p>
                  </a>
                ))}
              </div>
            </div>

            <div className="mt-5 flex flex-col items-start justify-between gap-4 rounded-2xl border border-line bg-gradient-to-r from-raised/80 to-surface/30 p-5 sm:flex-row sm:items-center">
              <div className="flex items-start gap-3">
                <Sparkles size={18} className="mt-0.5 shrink-0 text-gold" />
                <div>
                  <p className="text-[0.8rem] font-semibold text-cream">Planning your next night out?</p>
                  <p className="mt-0.5 text-[0.68rem] font-light text-mist">
                    Presales, new tours and the Friday shortlist — straight to your inbox.
                  </p>
                </div>
              </div>
              <Link
                to="/events"
                className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-gold px-4 py-2.5 text-[0.67rem] font-bold uppercase tracking-[0.06em] text-ink transition-colors hover:bg-gold-bright"
              >
                Explore events <ArrowRight size={13} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
