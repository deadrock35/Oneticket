import { useEffect, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronRight,
  Clock3,
  ExternalLink,
  Heart,
  Info,
  MapPin,
  ParkingCircle,
  PlaneTakeoff,
  Share2,
  ShieldCheck,
  Sparkles,
  Ticket,
  Users,
  DoorOpen,
  Music2,
  Theater,
  Accessibility,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import {
  EVENTS,
  eventFaqs,
  eventImage,
  eventTerms,
  formatEventDate,
  formatShortDate,
  formatZAR,
  getEvent,
  getVenue,
  type EventItem,
} from "../data/events";
import { Link } from "../lib/router";
import { EventCard } from "../components/events/EventCard";
import { BookingCard } from "../components/event-detail/BookingCard";
import { Accordion } from "../components/ui/Accordion";
import { Reveal } from "../components/ui/Reveal";
import { cn } from "../utils/cn";

const addMinutes = (time: string, minutes: number) => {
  const [rawHours, rawMins] = time.split(":").map(Number);
  const date = new Date();
  date.setHours(rawHours, rawMins + minutes, 0, 0);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
};

const buildSchedule = (event: EventItem) => [
  {
    time: event.doors,
    title: "Doors open",
    detail: "Security checks begin, bars and merchandise open. Arrive early and settle in.",
    icon: DoorOpen,
  },
  {
    time: addMinutes(event.doors, 30),
    title: event.category === "Festivals" ? "Gates & grounds open" : "Pre-show",
    detail:
      event.category === "Festivals"
        ? "Food traders, marketplace and all stages open to pass holders."
        : "Grab a drink and find your seat. The atmosphere starts warming up.",
    icon: Users,
  },
  {
    time: event.time,
    title: event.category === "Theatre" ? "Curtain up" : event.category === "Comedy" ? "Show starts" : "Main show",
    detail: `${event.artist} takes the stage. Latecomers are seated at a suitable break.`,
    icon: event.category === "Theatre" ? Theater : Music2,
  },
  {
    time: addMinutes(event.time, 130),
    title: "Approximate finish",
    detail: "Last orders at the bars. Safe travels — book your ride ahead where possible.",
    icon: PlaneTakeoff,
  },
];

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "lineup", label: "Line-up" },
  { id: "venue", label: "The venue" },
  { id: "schedule", label: "Schedule" },
  { id: "good-to-know", label: "Good to know" },
];

export function EventDetailPage({ slug }: { slug: string }) {
  const event = getEvent(slug);
  const { saved, toggleSaved, notify, cartCount, openOverlay } = useApp();
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    setActiveTab("overview");
  }, [slug]);

  if (!event) {
    return (
      <section className="shell flex min-h-[80vh] flex-col items-center justify-center pb-20 pt-[140px] text-center">
        <Ticket size={36} className="text-gold/70" />
        <h1 className="mt-5 font-display text-[3.2rem] leading-none text-cream">That show has left the stage.</h1>
        <p className="mt-3 max-w-md text-[0.85rem] font-light text-mist">
          We couldn&apos;t find that event. It may have ended or the link may be out of date — but there&apos;s always
          something else worth your time.
        </p>
        <Link
          to="/events"
          className="mt-6 inline-flex min-h-12 items-center gap-2 rounded-lg bg-gold px-5 text-[0.74rem] font-bold text-ink hover:bg-gold-bright"
        >
          Browse all events <ArrowRight size={15} />
        </Link>
      </section>
    );
  }

  const venue = getVenue(event);
  const isSaved = saved.includes(event.slug);
  const highlights = event.highlights;
  const schedule = buildSchedule(event);
  const faqs = eventFaqs(event);
  const terms = eventTerms(event);
  const related = EVENTS.filter((item) => item.slug !== event.slug)
    .sort((a, b) => Number(b.category === event.category) - Number(a.category === event.category))
    .slice(0, 3);

  const scrollTo = (id: string) => {
    setActiveTab(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const scrollToTickets = () => {
    document.getElementById("tickets")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const share = async () => {
    const url = window.location.href;
    const shareData = { title: `${event.title} — OpenTickets`, text: `${event.title} · ${formatEventDate(event.date)} · ${venue.name}`, url };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        return;
      }
      await navigator.clipboard.writeText(url);
      notify("Event link copied to your clipboard");
    } catch {
      try {
        await navigator.clipboard.writeText(url);
        notify("Event link copied to your clipboard");
      } catch {
        notify("Copy this page's address to share the event");
      }
    }
  };

  return (
    <div className="pb-20 lg:pb-0">
      {/* ============================= HERO ============================= */}
      <section className="relative isolate overflow-hidden pb-0 pt-[95px]">
        <div className="absolute inset-0 -z-10">
          <img
            src={eventImage(event, "wide")}
            alt=""
            className="h-[110%] w-full object-cover object-center opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-ink/75 via-ink/80 to-ink" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/65 to-transparent" />
          <div
            className="absolute left-1/3 top-1/4 h-[420px] w-[440px] rounded-full blur-[130px]"
            style={{ background: "rgba(228,199,142,0.09)" }}
          />
        </div>

        <div className="shell relative">
          <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1.5 py-5 text-[0.61rem] font-medium text-mist-dim">
            <Link to="/" className="transition-colors hover:text-gold">
              Home
            </Link>
            <ChevronRight size={10} />
            <Link to="/events" className="transition-colors hover:text-gold">
              Events
            </Link>
            <ChevronRight size={10} />
            <Link to={`/events?category=${event.category}`} className="transition-colors hover:text-gold">
              {event.category}
            </Link>
            <ChevronRight size={10} />
            <span className="max-w-[190px] truncate text-cream/75 sm:max-w-none">{event.title}</span>
          </nav>

          <div className="grid gap-7 pb-8 sm:grid-cols-[180px_minmax(0,1fr)] lg:grid-cols-[244px_minmax(0,1fr)] lg:gap-9 lg:pb-10">
            <div className="relative mx-auto hidden w-full max-w-[244px] pt-2 sm:mx-0 sm:block">
              <div className="absolute left-4 top-4 h-full w-full rounded-2xl border border-gold/25 bg-gold/[0.06]" aria-hidden="true" />
              <div className="relative overflow-hidden rounded-2xl border border-white/15 bg-raised shadow-[0_30px_60px_-30px_rgba(0,0,0,0.9)]">
                <img
                  src={eventImage(event, "poster")}
                  alt={`${event.title} event poster`}
                  className="h-[272px] w-full object-cover sm:h-[300px] lg:h-[328px]"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink to-transparent p-3">
                  <p className="text-[0.48rem] font-bold uppercase tracking-[0.2em] text-gold">OpenTickets exclusive</p>
                  <p className="mt-0.5 font-display text-[1.05rem] leading-tight text-cream">{event.category} season</p>
                </div>
              </div>
            </div>

            <div className="min-w-0 text-center sm:text-left">
              <div className="mx-auto mb-5 flex max-w-[330px] items-center gap-3 text-left sm:hidden">
                <img
                  src={eventImage(event, "poster")}
                  alt={`${event.title} event poster`}
                  className="h-[92px] w-[72px] shrink-0 rounded-xl border border-white/15 object-cover shadow-lg"
                />
                <div className="min-w-0 border-l border-line pl-3">
                  <p className="text-[0.5rem] font-bold uppercase tracking-[0.16em] text-gold">OpenTickets official</p>
                  <p className="mt-1 text-[0.66rem] font-medium leading-snug text-cream/80">
                    {event.organiser}
                  </p>
                  <p className="mt-1 text-[0.6rem] text-mist">
                    {formatShortDate(event.date)} · {venue.city}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-gold/25 bg-gold/[0.08] px-2.5 py-1 text-[0.56rem] font-bold uppercase tracking-[0.14em] text-gold-bright">
                  <Sparkles size={9} /> {event.category}
                </span>
                <span
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.56rem] font-bold uppercase tracking-[0.11em]",
                    event.status === "Few left"
                      ? "border-coral/25 bg-coral/[0.07] text-coral"
                      : "border-sage/20 bg-sage/[0.06] text-sage"
                  )}
                >
                  <span className="size-1 rounded-full bg-current" /> {event.status}
                </span>
                {event.runNote && (
                  <span className="rounded-full border border-line px-2.5 py-1 text-[0.56rem] font-medium text-mist">
                    {event.runNote}
                  </span>
                )}
              </div>

              <p className="mt-4 text-[0.62rem] font-bold uppercase tracking-[0.22em] text-gold/90">{event.artist}</p>
              <h1 className="mt-2.5 max-w-[760px] text-[clamp(2.6rem,5vw,4.65rem)] leading-[0.93] text-cream">
                {event.title}
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-[0.85rem] font-light leading-relaxed text-cream/70 sm:mx-0 sm:text-[0.92rem]">
                {event.tagline}
              </p>

              <div className="mt-6 flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <button
                  type="button"
                  onClick={scrollToTickets}
                  className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-[10px] bg-gold px-4 text-[0.7rem] font-bold uppercase tracking-[0.05em] text-ink transition-all hover:bg-gold-bright hover:shadow-[0_0_35px_-8px_rgba(228,199,142,0.5)] sm:w-auto sm:px-5 sm:text-[0.72rem]"
                >
                  <Ticket size={15} /> Book tickets · from {formatZAR(event.priceFrom)}
                </button>
                <div className="flex w-full gap-2 sm:w-auto">
                  <button
                    type="button"
                    onClick={() => toggleSaved(event.slug)}
                    aria-pressed={isSaved}
                    className={cn(
                      "inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-[10px] border px-3.5 text-[0.68rem] font-semibold transition-all sm:flex-none",
                      isSaved ? "border-gold/60 bg-gold/15 text-gold" : "border-line bg-ink/30 text-cream/80 hover:border-gold/40 hover:text-gold"
                    )}
                  >
                    <Heart size={14} fill={isSaved ? "currentColor" : "none"} /> {isSaved ? "Saved" : "Save"}
                  </button>
                  <button
                    type="button"
                    onClick={share}
                    className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-[10px] border border-line bg-ink/30 px-3.5 text-[0.68rem] font-semibold text-cream/80 transition-all hover:border-gold/40 hover:text-gold sm:flex-none"
                  >
                    <Share2 size={14} /> Share
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="glass mb-8 grid grid-cols-2 gap-y-4 rounded-2xl px-4 py-4 sm:grid-cols-4 sm:px-5">
            {[
              { icon: CalendarDays, label: "Date", value: formatEventDate(event.date) },
              { icon: Clock3, label: "Time", value: `${event.time} · doors ${event.doors}` },
              { icon: MapPin, label: "Venue", value: `${venue.name}, ${venue.city}` },
              { icon: Users, label: "Age & duration", value: `${event.age} · ${event.duration}` },
            ].map(({ icon: Icon, label, value }, index) => (
              <div
                key={label}
                className={cn(
                  "flex min-w-0 items-start gap-2.5 px-1 sm:px-3",
                  index > 0 && "sm:border-l sm:border-line-soft",
                  index === 2 && "border-t border-line-soft pt-4 sm:border-t-0 sm:pt-0"
                )}
              >
                <Icon size={15} className="mt-0.5 shrink-0 text-gold/85" />
                <div className="min-w-0">
                  <p className="text-[0.51rem] font-bold uppercase tracking-[0.15em] text-mist-dim">{label}</p>
                  <p className="mt-0.5 text-[0.68rem] font-medium leading-snug text-cream">{value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="sticky top-[68px] z-30 border-y border-line-soft bg-ink/88 backdrop-blur-2xl">
          <div className="shell no-scrollbar flex items-center justify-between gap-4 overflow-x-auto">
            <div className="flex items-center" role="tablist" aria-label="Event sections">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  onClick={() => scrollTo(tab.id)}
                  className={cn(
                    "relative shrink-0 px-3 py-3.5 text-[0.66rem] font-semibold tracking-[0.02em] transition-colors sm:px-4",
                    activeTab === tab.id ? "text-cream" : "text-mist hover:text-cream"
                  )}
                >
                  {tab.label}
                  {activeTab === tab.id && <span className="absolute inset-x-2 bottom-0 h-px bg-gold sm:inset-x-3" />}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => scrollToTickets()}
              className="hidden shrink-0 items-center gap-1.5 text-[0.64rem] font-bold uppercase tracking-[0.1em] text-gold md:inline-flex"
            >
              Buy tickets <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </section>

      {/* ============================= MAIN ============================= */}
      <div className="shell grid gap-8 lg:grid-cols-[minmax(0,1fr)_352px] lg:items-start xl:grid-cols-[minmax(0,1fr)_382px] xl:gap-10">
        <main className="min-w-0 py-10 sm:py-12">
          <Reveal as="section" className="scroll-mt-28" id="overview">
            <span className="eyebrow">The full picture</span>
            <h2 className="mt-3.5 text-[clamp(2.1rem,3.6vw,3rem)] leading-none text-cream">
              More than a <em className="text-gold">night out.</em>
            </h2>
            <div className="mt-5 space-y-4">
              {event.description.map((paragraph, index) => (
                <p
                  key={index}
                  className={cn(
                    "font-light leading-[1.9] text-mist",
                    index === 0 ? "text-[0.9rem] text-cream/80" : "text-[0.84rem]"
                  )}
                >
                  {paragraph}
                </p>
              ))}
            </div>
            <div className="mt-6 grid gap-2.5 rounded-2xl border border-gold/15 bg-gold/[0.035] p-4 sm:grid-cols-3 sm:p-5">
              {highlights.map((highlight) => (
                <div key={highlight} className="flex items-start gap-2.5">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-gold/12 text-gold">
                    <Check size={10} strokeWidth={2.5} />
                  </span>
                  <p className="text-[0.71rem] font-medium leading-relaxed text-cream/85">{highlight}</p>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal as="section" id="lineup" className="mt-12 scroll-mt-28">
            <div className="flex items-end justify-between gap-4">
              <div>
                <span className="eyebrow">On the line-up</span>
                <h2 className="mt-3 text-[2.15rem] leading-none text-cream">Who you&apos;ll see.</h2>
              </div>
              <Music2 size={26} className="hidden text-gold/40 sm:block" strokeWidth={1.2} />
            </div>
            <div className="mt-5 divide-y divide-line-soft border-y border-line-soft">
              {event.lineup.map((artist, index) => (
                <div key={artist} className="group flex items-center gap-4 py-4">
                  <span className="w-6 shrink-0 font-sans text-[0.55rem] font-bold tracking-[0.12em] text-gold/70">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span className="size-1 rounded-full bg-line-strong" />
                  <p className="flex-1 font-display text-[1.35rem] leading-tight text-cream transition-colors group-hover:text-gold-bright">
                    {artist}
                  </p>
                  <span className="hidden text-[0.54rem] font-bold uppercase tracking-[0.13em] text-mist-dim sm:block">
                    {index === 0 ? "Main event" : "Appearing"}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[0.63rem] font-light text-mist-dim">
              Line-up and set times are subject to change by the organiser.
            </p>
          </Reveal>

          <Reveal as="section" id="venue" className="mt-12 scroll-mt-28">
            <span className="eyebrow">The venue</span>
            <h2 className="mt-3 text-[2.15rem] leading-none text-cream">
              {venue.name}, <em className="text-gold">{venue.city}.</em>
            </h2>
            <div className="mt-5 overflow-hidden rounded-2xl border border-line-soft bg-surface/35">
              <div className="venue-map relative flex h-[200px] items-center justify-center overflow-hidden sm:h-[230px]">
                <div className="absolute inset-0 bg-gradient-to-t from-ink/75 to-transparent" />
                <span className="absolute left-[28%] top-[38%] size-2 rounded-full bg-gold/50" />
                <span className="absolute right-[20%] top-[30%] size-1.5 rounded-full bg-violet/50" />
                <span className="absolute bottom-[26%] left-[42%] h-px w-16 rotate-[28deg] bg-gold/25" />
                <div className="relative flex flex-col items-center">
                  <span className="grid size-12 place-items-center rounded-full border border-gold/40 bg-ink/80 text-gold shadow-[0_0_35px_-5px_rgba(228,199,142,0.4)] backdrop-blur">
                    <MapPin size={20} />
                  </span>
                  <span className="mt-2 rounded-full border border-line bg-ink/85 px-3 py-1 text-[0.6rem] font-semibold text-cream backdrop-blur">
                    {venue.name}
                  </span>
                </div>
                <span className="absolute bottom-3 left-3 rounded border border-white/10 bg-ink/60 px-2 py-1 text-[0.48rem] uppercase tracking-[0.12em] text-mist backdrop-blur">
                  {venue.address}
                </span>
              </div>
              <div className="grid gap-4 p-5 sm:grid-cols-[1.4fr_1fr] sm:p-6">
                <div>
                  <p className="text-[0.83rem] font-light leading-[1.85] text-mist">{venue.description}</p>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(venue.address)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-4 inline-flex items-center gap-1.5 text-[0.68rem] font-bold uppercase tracking-[0.1em] text-gold transition-colors hover:text-gold-bright"
                  >
                    Get directions <ExternalLink size={11} />
                  </a>
                </div>
                <div className="space-y-3 rounded-xl border border-line-soft bg-ink/25 p-4">
                  {[
                    { icon: Users, label: "Capacity", value: venue.capacity },
                    { icon: ParkingCircle, label: "Parking", value: venue.parking },
                    { icon: Accessibility, label: "Accessibility", value: venue.accessibility },
                  ].map(({ icon: Icon, label, value }) => (
                    <div key={label} className="flex items-start gap-2.5">
                      <Icon size={13} className="mt-0.5 shrink-0 text-gold/80" />
                      <div>
                        <p className="text-[0.53rem] font-bold uppercase tracking-[0.11em] text-mist-dim">{label}</p>
                        <p className="mt-0.5 text-[0.64rem] font-light leading-relaxed text-cream/80">{value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal as="section" id="schedule" className="mt-12 scroll-mt-28">
            <span className="eyebrow">Your evening, mapped</span>
            <h2 className="mt-3 text-[2.15rem] leading-none text-cream">The run of show.</h2>
            <p className="mt-2 text-[0.77rem] font-light text-mist">
              {formatEventDate(event.date)} · {venue.name}, {venue.city}
            </p>
            <div className="mt-5 rounded-2xl border border-line-soft bg-surface/30 p-4 sm:p-6">
              {schedule.map((item, index) => (
                <div key={`${item.time}-${item.title}`} className="flex gap-3.5 sm:gap-5">
                  <div className="flex w-12 shrink-0 flex-col items-center">
                    <span className="font-sans text-[0.65rem] font-bold tracking-[0.03em] text-gold">{item.time}</span>
                    <span className="mt-1.5 grid size-6 place-items-center rounded-full border border-line bg-ink text-mist">
                      <item.icon size={11} />
                    </span>
                    {index < schedule.length - 1 && <span className="my-1 w-px flex-1 bg-line-soft" />}
                  </div>
                  <div className={cn(index < schedule.length - 1 ? "pb-6" : "pb-1")}>
                    <p className="font-sans text-[0.79rem] font-semibold text-cream">{item.title}</p>
                    <p className="mt-1 max-w-lg text-[0.68rem] font-light leading-relaxed text-mist">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-2.5 flex items-center gap-1.5 text-[0.61rem] font-light text-mist-dim">
              <Info size={10} /> Set times are approximate and may shift on the night.
            </p>
          </Reveal>

          <Reveal as="section" id="good-to-know" className="mt-12 scroll-mt-28">
            <span className="eyebrow">Before you go</span>
            <h2 className="mt-3 text-[2.15rem] leading-none text-cream">The good to know.</h2>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {[
                {
                  icon: DoorOpen,
                  title: "Arrive early",
                  copy: `Doors open at ${event.doors}. Security checks can take a few minutes, so leave a little room in your evening.`,
                },
                {
                  icon: Ticket,
                  title: "Mobile-first entry",
                  copy: "Your QR code is scanned at the door. No printing needed — but make sure your phone is charged.",
                },
                {
                  icon: ShieldCheck,
                  title: "Ticket protection",
                  copy: "All tickets purchased through OpenTickets are verified and single-use. Only buy from official channels.",
                },
                {
                  icon: Accessibility,
                  title: "Access needs",
                  copy: `Email access@opentickets.co.za at least 72 hours before the show and our team will arrange support at ${venue.name}.`,
                },
              ].map(({ icon: Icon, title, copy }) => (
                <div key={title} className="rounded-xl border border-line-soft bg-surface/30 p-4">
                  <Icon size={16} className="text-gold" />
                  <p className="mt-2.5 text-[0.77rem] font-semibold text-cream">{title}</p>
                  <p className="mt-1 text-[0.68rem] font-light leading-relaxed text-mist">{copy}</p>
                </div>
              ))}
            </div>

            <details className="group mt-5 rounded-xl border border-line-soft bg-surface/25">
              <summary className="flex items-center justify-between gap-4 px-4 py-4 sm:px-5">
                <span className="text-[0.8rem] font-semibold text-cream">Full ticket terms & conditions</span>
                <span className="acc-icon grid size-6 shrink-0 place-items-center rounded-full border border-line text-gold transition-transform duration-300">
                  +
                </span>
              </summary>
              <div className="border-t border-line-soft px-4 py-4 sm:px-5">
                <ul className="space-y-2.5">
                  {terms.map((term, index) => (
                    <li key={term} className="flex items-start gap-2.5 text-[0.69rem] font-light leading-relaxed text-mist">
                      <span className="mt-0.5 font-sans text-[0.55rem] font-bold text-gold/70">{String(index + 1).padStart(2, "0")}</span>
                      {term}
                    </li>
                  ))}
                </ul>
              </div>
            </details>

            <div className="mt-10">
              <span className="eyebrow">Event questions</span>
              <h2 className="mt-3 text-[2.15rem] leading-none text-cream">You might be wondering.</h2>
              <Accordion items={faqs} className="mt-4" />
            </div>
          </Reveal>

          <div className="mt-10 flex flex-col items-start justify-between gap-4 rounded-2xl border border-gold/20 bg-gradient-to-br from-gold/[0.075] to-transparent p-5 sm:flex-row sm:items-center">
            <div>
              <p className="font-display text-[1.65rem] leading-tight text-cream">Ready to make a night of it?</p>
              <p className="mt-1 text-[0.72rem] font-light text-mist">
                From {formatZAR(event.priceFrom)} per ticket · instant e-ticket delivery.
              </p>
            </div>
            <div className="flex w-full gap-2 sm:w-auto">
              <button
                type="button"
                onClick={scrollToTickets}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-gold px-4 text-[0.7rem] font-bold uppercase tracking-[0.06em] text-ink transition-colors hover:bg-gold-bright sm:flex-none"
              >
                Choose tickets <ArrowRight size={13} />
              </button>
              {cartCount > 0 && (
                <button
                  type="button"
                  onClick={() => openOverlay("cart")}
                  className="inline-flex min-h-11 items-center gap-1.5 rounded-lg border border-line px-3 text-[0.66rem] font-semibold text-cream transition-colors hover:border-gold/40 hover:text-gold"
                >
                  Selection ({cartCount})
                </button>
              )}
            </div>
          </div>
        </main>

        <aside className="relative min-w-0 pb-8 lg:py-10">
          <div className="sticky top-[94px]">
            <BookingCard event={event} />
            <div className="mt-3 rounded-xl border border-line-soft bg-surface/35 p-4">
              <div className="flex items-start gap-2.5">
                <span className="grid size-8 shrink-0 place-items-center rounded-full border border-gold/25 bg-gold/[0.07] text-gold">
                  <Sparkles size={13} />
                </span>
                <div>
                  <p className="text-[0.71rem] font-semibold text-cream">Need a hand choosing?</p>
                  <p className="mt-0.5 text-[0.63rem] font-light leading-relaxed text-mist">
                    Our local team is on live chat until 21:00, seven days a week.
                  </p>
                  <a
                    href="mailto:support@opentickets.co.za"
                    className="mt-2 inline-flex items-center gap-1 text-[0.6rem] font-bold uppercase tracking-[0.08em] text-gold hover:text-gold-bright"
                  >
                    Talk to a human <ArrowUpRight size={10} />
                  </a>
                </div>
              </div>
            </div>
            <div className="mt-3 flex items-center justify-center gap-2 text-[0.56rem] text-mist-dim">
              <ShieldCheck size={10} /> Official OpenTickets partner
              <span className="text-line-strong">·</span>
              <LockIcon /> Secure checkout
            </div>
          </div>
        </aside>
      </div>

      {/* ============================= RELATED ============================= */}
      <section className="border-t border-line-soft bg-midnight/35 py-12 sm:py-14">
        <div className="shell">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <span className="eyebrow">Keep the night going</span>
              <h2 className="mt-3 text-[clamp(2.1rem,3.5vw,2.9rem)] leading-none text-cream">
                You might also <em className="text-gold">love.</em>
              </h2>
            </div>
            <Link
              to={`/events?category=${event.category}`}
              className="group inline-flex items-center gap-2 text-[0.66rem] font-bold uppercase tracking-[0.12em] text-gold"
            >
              More {event.category.toLowerCase()}{" "}
              <span className="grid size-7 place-items-center rounded-full border border-gold/30 transition-colors group-hover:bg-gold group-hover:text-ink">
                <ArrowRight size={11} />
              </span>
            </Link>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((item) => (
              <EventCard key={item.slug} event={item} />
            ))}
          </div>
        </div>
      </section>

      {/* Mobile purchase bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-gold/20 bg-ink/95 px-3 py-2.5 shadow-[0_-20px_40px_-20px_rgba(0,0,0,0.9)] backdrop-blur-2xl lg:hidden">
        <div className="mx-auto flex max-w-lg items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="truncate text-[0.58rem] font-bold uppercase tracking-[0.1em] text-mist-dim">
              {formatShortDate(event.date)} · {venue.city}
            </p>
            <p className="mt-0.5 text-[0.78rem] font-bold text-gold">
              {formatZAR(event.priceFrom)} <span className="text-[0.56rem] font-normal text-mist">from</span>
            </p>
          </div>
          <button
            type="button"
            onClick={() => (cartCount > 0 ? openOverlay("cart") : scrollToTickets())}
            className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-lg bg-gold px-4 text-[0.7rem] font-bold uppercase tracking-[0.05em] text-ink"
          >
            {cartCount > 0 ? "View selection" : "Select tickets"} <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

function LockIcon() {
  return (
    <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <rect x="4" y="10" width="16" height="11" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </svg>
  );
}
