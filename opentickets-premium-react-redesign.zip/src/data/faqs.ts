export interface FaqCategory {
  id: string;
  title: string;
  description: string;
  icon: "ticket" | "venue" | "account" | "general";
  items: { q: string; a: string }[];
}

export const FAQ_CATEGORIES: FaqCategory[] = [
  {
    id: "ticketing",
    title: "Ticketing & Refunds",
    description: "Everything about buying, changing and using your tickets.",
    icon: "ticket",
    items: [
      {
        q: "How do I receive my tickets after payment?",
        a: "Your e-tickets are issued instantly and emailed to the address on your booking. They are also available under Account → My tickets. Each ticket carries a unique QR code — present it on your phone at the door, or print it at home if you prefer.",
      },
      {
        q: "Can I get a refund or exchange my tickets?",
        a: "As with most live events, all sales are final once confirmed. If an event is cancelled or postponed by the organiser, you will be contacted directly with the option of a full refund or a credit to your OpenTickets wallet. We can help with a name transfer up to 48 hours before the event.",
      },
      {
        q: "Are there additional booking fees?",
        a: "The price you see is the price you pay. OpenTickets includes the booking fee in every displayed ticket price and never adds a surprise fee at checkout. Where a venue or organiser applies a levy, it is shown clearly before you pay.",
      },
      {
        q: "What happens if I lose my ticket?",
        a: "No stress. Sign in to your OpenTickets account to access your tickets at any time, or use the “Resend tickets” option in your confirmation email. Each QR code is single-use and regenerates securely if required.",
      },
      {
        q: "Can I buy tickets for friends and family?",
        a: "Absolutely. You can purchase up to 10 tickets per transaction, subject to the event's limits. When all tickets are on one booking, they arrive in a single email and can be shown together at the door or transferred to your guests from your account.",
      },
    ],
  },
  {
    id: "venue",
    title: "Venue Access",
    description: "Getting there, access needs and what to expect on the night.",
    icon: "venue",
    items: [
      {
        q: "What time should I arrive at the venue?",
        a: "Your ticket lists the official doors time. We recommend arriving at least 30–45 minutes before the performance start time to allow for security checks, parking and finding your seat. For festival sites, allow extra time for shuttle transfers.",
      },
      {
        q: "Is accessible seating available?",
        a: "Yes. Each venue page lists its accessible facilities, and wheelchair bays can be booked directly through OpenTickets. For specific access requirements, email access@opentickets.co.za at least 72 hours before your event and our team will coordinate with the venue.",
      },
      {
        q: "What can I bring with me?",
        a: "You may bring small personal bags. Cameras, recording equipment, glass, and outside food or drinks are not permitted. Outdoor venues such as Kirstenbosch and Cloof Wine Estate allow picnic blankets and closed picnic baskets — check your event's terms for details.",
      },
      {
        q: "Is parking available?",
        a: "Most venues offer secure paid parking, and several events include park-and-ride shuttles from central points. We recommend checking the venue section on your event page or using a ride-hailing service for late shows, as parking can fill quickly.",
      },
    ],
  },
  {
    id: "account",
    title: "Account & Payments",
    description: "Your profile, payment options and account security.",
    icon: "account",
    items: [
      {
        q: "Which payment methods can I use?",
        a: "We accept Visa, Mastercard, American Express, SnapScan, Zapper, Instant EFT and PayFast. All payments are processed over a secure, PCI-DSS-compliant connection, and we never store your full card details on our servers.",
      },
      {
        q: "Do I need an account to buy tickets?",
        a: "You can complete a purchase as a guest, but creating an account gives you instant access to your tickets, saved events and booking history across all your devices. It takes less than 30 seconds using your email address.",
      },
      {
        q: "How do I change my account details?",
        a: "Sign in and open Account settings to update your name, email, phone number, and communication preferences. If you have moved, remember to update your billing address before your next purchase.",
      },
      {
        q: "Is my payment information secure?",
        a: "Yes. All transactions are encrypted with TLS 1.3 and processed by a licensed South African payment provider. OpenTickets uses 3D Secure authentication on card payments and never sees or stores your CVV.",
      },
      {
        q: "How do I reset my password?",
        a: "Select “Forgot password” on the sign-in screen and enter your email address. You'll receive a secure reset link within a few minutes. If it doesn't arrive, check your spam folder or contact our support team.",
      },
    ],
  },
  {
    id: "general",
    title: "General",
    description: "The essentials about OpenTickets, support and season passes.",
    icon: "general",
    items: [
      {
        q: "What is OpenTickets?",
        a: "OpenTickets is South Africa's home of live entertainment — a proudly local, independently operated platform connecting people to the music, comedy, theatre and festival moments that matter. We work directly with promoters and venues to make booking delightful.",
      },
      {
        q: "How can I contact the team?",
        a: "Our Cape Town support team is available seven days a week, from 08:00 to 21:00. Email support@opentickets.co.za or use the live chat on this page for the fastest response. For urgent day-of-event issues, call 021 555 0198.",
      },
      {
        q: "Do you offer gift cards?",
        a: "Yes — an OpenTickets gift card is the perfect way to give someone a night to remember. Gift cards are available in denominations from R250 to R2,500 and never expire. They can be redeemed against any event on the platform.",
      },
      {
        q: "How do I stay in the loop?",
        a: "Join our newsletter for first access to new tours, presale codes and Friday's curated shortlist. You can also follow @openticketsza on Instagram for behind-the-scenes stories and event-day updates.",
      },
    ],
  },
];
