export type Category = "Music" | "Comedy" | "Theatre" | "Festivals";

export interface EventTier {
  id: string;
  name: string;
  description: string;
  price: number;
  availability: "Available" | "Few left" | "Sold out";
  zone: string;
}

export interface Venue {
  key: string;
  name: string;
  city: string;
  province: string;
  address: string;
  capacity: string;
  parking: string;
  accessibility: string;
  description: string;
  imageId: number;
}

export interface EventItem {
  slug: string;
  title: string;
  artist: string;
  category: Category;
  tagline: string;
  description: string[];
  venueKey: string;
  date: string;
  time: string;
  doors: string;
  priceFrom: number;
  priceTo: number;
  imageId: number;
  imagePosition?: string;
  featured?: boolean;
  trending?: boolean;
  badge?: string;
  status: "On sale" | "Few left" | "Final release";
  soldPercent: number;
  age: string;
  duration: string;
  organiser: string;
  lineup: string[];
  highlights: string[];
  tiers: EventTier[];
  runNote?: string;
}

const photo = (id: number, w = 1200, h = 800) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const eventImage = (event: EventItem, variant: "card" | "wide" | "poster" = "card") => {
  if (variant === "wide") return photo(event.imageId, 1920, 900);
  if (variant === "poster") return photo(event.imageId, 800, 1120);
  return photo(event.imageId, 900, 700);
};

export const VENUES: Record<string, Venue> = {
  "sun-arena": {
    key: "sun-arena",
    name: "Sun Arena at Time Square",
    city: "Pretoria",
    province: "Gauteng",
    address: "209 Aramist Ave, Waterkloof Glen, Pretoria, 0181",
    capacity: "8,500 guests",
    parking: "Secure underground parking available on-site, R40 per vehicle.",
    accessibility: "Step-free access, accessible ablutions and dedicated wheelchair bays.",
    description:
      "A world-class indoor arena connected to Time Square, with unobstructed sightlines, exceptional acoustics and a full hospitality concourse. Arrive early for a pre-show dinner at one of the adjoining restaurants.",
    imageId: 33622135,
  },
  kirstenbosch: {
    key: "kirstenbosch",
    name: "Kirstenbosch Summer Sunset Concerts",
    city: "Cape Town",
    province: "Western Cape",
    address: "Rhodes Drive, Newlands, Cape Town, 7735",
    capacity: "6,000 guests",
    parking: "Park & ride from UCT is recommended. Limited on-site parking from 16:00.",
    accessibility: "Accessible route from Gate 2. Wheelchair-friendly lawns and facilities.",
    description:
      "Undoubtedly one of the world's most beautiful outdoor music venues. Bring a picnic blanket, gather your people and settle in beneath Table Mountain as the sun sets over the botanical garden.",
    imageId: 34862400,
  },
  "grand-arena": {
    key: "grand-arena",
    name: "GrandWest Grand Arena",
    city: "Cape Town",
    province: "Western Cape",
    address: "1 Jakes Gerwel Dr, Goodwood, Cape Town, 7460",
    capacity: "5,000 guests",
    parking: "Free multi-storey parking with complimentary shuttles to the arena entrance.",
    accessibility: "Dedicated accessible drop-off at the north entrance, level access throughout.",
    description:
      "An entertainment destination in one. The Grand Arena hosts the country's biggest comedy and music tours with a refined, intimate arena feel and a lively pre-show bar scene.",
    imageId: 34862403,
  },
  teatro: {
    key: "teatro",
    name: "Teatro at Montecasino",
    city: "Johannesburg",
    province: "Gauteng",
    address: "Montecasino Boulevard, Fourways, Sandton, 2055",
    capacity: "1,500 guests",
    parking: "Secure undercover parking is available across the Montecasino precinct.",
    accessibility: "Wheelchair seating rows available in the stalls. Lift access from all parking levels.",
    description:
      "A jewel-box theatre designed in the spirit of an Italian opera house. Every seat is close to the action, making Teatro the ideal home for prestige musicals and once-in-a-lifetime performances.",
    imageId: 33622141,
  },
  "cloof-wine-estate": {
    key: "cloof-wine-estate",
    name: "Cloof Wine Estate",
    city: "Darling",
    province: "Western Cape",
    address: "Cloof Wine Estate, R315, Darling, 7345",
    capacity: "20,000 guests",
    parking: "Festival parking and shuttle services operate from Cape Town and Darling town.",
    accessibility: "Accessible viewing platform, parking and toilets. See the festival access guide.",
    description:
      "Rolling wheat fields, fynbos and a whole lot of electric energy. A short drive from Cape Town, this working wine estate transforms into the home of South Africa's most-loved open-air festival.",
    imageId: 14267300,
  },
  artscape: {
    key: "artscape",
    name: "Artscape Theatre Centre",
    city: "Cape Town",
    province: "Western Cape",
    address: "D.F. Malan St, Foreshore, Cape Town, 8001",
    capacity: "1,500 guests",
    parking: "Secure parking at the Artscape basement, accessed from D.F. Malan Street.",
    accessibility: "Wheelchair-accessible entrances, lift access and reserved seating in all theatres.",
    description:
      "Cape Town's beloved home of performing arts in the heart of the Foreshore. Expect warm hospitality, excellent sightlines and a programme that celebrates the best of South African stagecraft.",
    imageId: 34862403,
  },
  cticc: {
    key: "cticc",
    name: "Cape Town International Convention Centre",
    city: "Cape Town",
    province: "Western Cape",
    address: "1 Lower Long St, Cape Town City Centre, Cape Town, 8001",
    capacity: "12,000 guests",
    parking: "Undercover parking on-site, accessible from Lower Long Street.",
    accessibility: "Fully accessible venues with lift access and dedicated viewing areas.",
    description:
      "A landmark convention centre that comes alive for the city's flagship jazz weekend. Multiple stages, pop-up kitchens and world-class production make this a true cultural pilgrimage.",
    imageId: 34862403,
  },
  "joburg-theatre": {
    key: "joburg-theatre",
    name: "Joburg Theatre",
    city: "Johannesburg",
    province: "Gauteng",
    address: "163 Civic Blvd, Braamfontein, Johannesburg, 2001",
    capacity: "1,050 guests",
    parking: "Secure parking at the Civic Centre precinct, with attendants on duty until 23:00.",
    accessibility: "Level access from the Civic Boulevard entrance. Wheelchair bays available.",
    description:
      "A storied Johannesburg stage bringing world-class musicals, ballet and drama to Braamfontein. The theatre's restored auditorium blends old-world glamour with contemporary production.",
    imageId: 33622135,
  },
  "constitution-hill": {
    key: "constitution-hill",
    name: "Constitution Hill",
    city: "Johannesburg",
    province: "Gauteng",
    address: "11 Kotze St, Braamfontein, Johannesburg, 2001",
    capacity: "10,000 guests",
    parking: "Paid event parking is available in Braamfontein. Ride-hailing is recommended.",
    accessibility: "Accessible routes and dedicated viewing areas are available on all levels.",
    description:
      "A profoundly beautiful heritage site and a powerful home for culture. Afropunk takes over the sprawling lawns and historic courtyards for one extraordinary day of music, art and community.",
    imageId: 33622135,
  },
  franschhoek: {
    key: "franschhoek",
    name: "Franschhoek Wine Valley",
    city: "Franschhoek",
    province: "Western Cape",
    address: "Main Road, Franschhoek, Western Cape, 7690",
    capacity: "3,500 guests",
    parking: "Free park-and-ride shuttles run between the town square and festival venues.",
    accessibility: "Most tasting venues offer level access. A mobility shuttle is available on request.",
    description:
      "South Africa's culinary capital, framed by dramatic mountains and legendary wine estates. Uncorked is a roam-free weekend of exceptional wines, generous plates and golden valley light.",
    imageId: 20151743,
  },
  "theatre-on-the-bay": {
    key: "theatre-on-the-bay",
    name: "Theatre on the Bay",
    city: "Cape Town",
    province: "Western Cape",
    address: "Link St, Camps Bay, Cape Town, 8005",
    capacity: "220 guests",
    parking: "Limited street parking; arrive 30 minutes early. Valet available on request.",
    accessibility: "Assisted access via the main entrance. Please notify the box office in advance.",
    description:
      "Cape Town's most intimate comedy room, a few minutes from Camps Bay beach. Expect exceptional comics, a serious sense of occasion and an ocean sunset before curtain-up.",
    imageId: 34862403,
  },
};

export const EVENTS: EventItem[] = [
  {
    slug: "midnight-in-the-city",
    title: "Midnight in the City",
    artist: "Kabza De Small · Kelvin Momo · Mawhoo",
    category: "Music",
    tagline: "One night. Three generations of piano royalty.",
    description: [
      "Midnight in the City is a late-night love letter to South African electronic music. For one night only, three of the country's most influential music makers share a stage with a live 12-piece band, reimagining the sound that has taken the world by storm.",
      "Expect deep, late piano selections, front-of-house energy and a production designed to feel like the most beautiful after-party you have ever been invited to. Doors open at 18:00 for the golden-hour rooftop set.",
    ],
    venueKey: "sun-arena",
    date: "2027-02-13T19:00:00+02:00",
    time: "19:00",
    doors: "18:00",
    priceFrom: 450,
    priceTo: 1250,
    imageId: 14429344,
    featured: true,
    trending: true,
    badge: "Editorial pick",
    status: "Few left",
    soldPercent: 87,
    age: "18+",
    duration: "4 hours",
    organiser: "OpenTickets Sessions",
    lineup: ["Kabza De Small", "Kelvin Momo", "Mawhoo", "DJ Stokie", "Live all-stars band"],
    highlights: [
      "A live 12-piece band reworking amapiano classics",
      "Rooftop golden-hour warm-up with sundowner views",
      "Exclusive limited-edition show poster for VIP guests",
    ],
    tiers: [
      { id: "standing", name: "General Access", description: "Standing floor access to all supporting sets and the main show.", price: 450, availability: "Available", zone: "Floor" },
      { id: "golden", name: "Golden Circle", description: "Early entry, dedicated bar and a close-up view of the stage.", price: 850, availability: "Few left", zone: "Centre" },
      { id: "vip", name: "Piano Lounge", description: "Elevated VIP mezzanine with welcome cocktail and private ablutions.", price: 1250, availability: "Few left", zone: "Mezzanine" },
    ],
  },
  {
    slug: "jeremy-loops-summer-sessions",
    title: "Jeremy Loops — Summer Sessions",
    artist: "Jeremy Loops & special friends",
    category: "Music",
    tagline: "Folk-pop sunshine beneath Table Mountain.",
    description: [
      "Following a sell-out world tour, Jeremy Loops returns home for an intimate sunset performance in the Kirstenbosch amphitheatre. This is the third summer the OpenTickets community has made this evening its own — and the perfect excuse for a long picnic with the people you love.",
      "Bring a blanket, a well-stocked basket and a jersey for later. Supporting act Aimee deBeer opens the afternoon with a set of warm, widescreen folk.",
    ],
    venueKey: "kirstenbosch",
    date: "2027-03-14T17:30:00+02:00",
    time: "17:30",
    doors: "16:00",
    priceFrom: 395,
    priceTo: 595,
    imageId: 7502581,
    featured: true,
    trending: true,
    badge: "Selling fast",
    status: "Few left",
    soldPercent: 91,
    age: "All ages",
    duration: "3 hours",
    organiser: "OpenTickets Live",
    lineup: ["Jeremy Loops", "Aimee deBeer", "The Sunset Collective"],
    highlights: [
      "A full-band sunset set beneath Table Mountain",
      "Pre-show picnic lawns open from 16:00",
      "Exclusive summer sessions show poster included",
    ],
    tiers: [
      { id: "lawn", name: "Picnic Lawn", description: "General lawn access. Bring your own blanket and picnic.", price: 395, availability: "Available", zone: "Lawn" },
      { id: "garden", name: "Garden Reserved", description: "A reserved garden seat with an elevated view of the stage.", price: 595, availability: "Few left", zone: "Garden" },
    ],
  },
  {
    slug: "trevor-noah-off-the-record",
    title: "Trevor Noah: Off the Record",
    artist: "Trevor Noah",
    category: "Comedy",
    tagline: "The homecoming tour everyone's talking about.",
    description: [
      "He left South Africa a comic and returned a global storyteller. On his most personal homecoming tour yet, Trevor Noah turns his sharp eye on the absurdity of family WhatsApp groups, fame and finding your way home.",
      "This brand-new two-hour show visits the Grand Arena for one night only. Phones will be locked in Yondr pouches, so be present — and leave room for a genuinely unforgettable encore.",
    ],
    venueKey: "grand-arena",
    date: "2027-04-24T20:00:00+02:00",
    time: "20:00",
    doors: "18:30",
    priceFrom: 550,
    priceTo: 1450,
    imageId: 10078868,
    featured: true,
    trending: true,
    badge: "Just announced",
    status: "Final release",
    soldPercent: 94,
    age: "16+",
    duration: "2 hours",
    organiser: "Real Live Nation",
    lineup: ["Trevor Noah"],
    highlights: [
      "A brand-new two-hour stand-up show",
      "Strictly no phones — Yondr pouches provided",
      "One night only in Cape Town",
    ],
    tiers: [
      { id: "upper", name: "Upper Tier", description: "Elevated seating with clear sightlines to the full stage.", price: 550, availability: "Available", zone: "Upper" },
      { id: "stalls", name: "Stalls", description: "Ground-level seating in the heart of the arena.", price: 850, availability: "Few left", zone: "Stalls" },
      { id: "front", name: "Front Row", description: "Prime front-row seats and a post-show programme.", price: 1450, availability: "Sold out", zone: "Front" },
    ],
  },
  {
    slug: "six-the-musical",
    title: "SIX the Musical",
    artist: "The global smash-hit production",
    category: "Theatre",
    tagline: "The six wives of Henry VIII. Remixed.",
    description: [
      "From Tudor queens to pop princesses, the six wives of Henry VIII take to the mic to tell their own stories. SIX remixes 500 years of historical heartbreak into an 80-minute celebration of 21st-century girl power.",
      "Winner of two Tony Awards, this electrifying production lands at Teatro for a strictly limited season. Expect powerhouse vocals, a live on-stage band and the kind of finale that gets a full house on its feet.",
    ],
    venueKey: "teatro",
    date: "2027-05-14T19:30:00+02:00",
    time: "19:30",
    doors: "18:45",
    priceFrom: 350,
    priceTo: 790,
    imageId: 6899772,
    featured: true,
    badge: "Limited season",
    status: "On sale",
    soldPercent: 68,
    age: "PG 12",
    duration: "80 minutes, no interval",
    organiser: "Showtime South Africa",
    lineup: ["Directed by Lucy Moss", "Choreography by Carrie-Anne Ingrouille", "Live band on stage"],
    highlights: [
      "Tony Award-winning West End production",
      "80 minutes of hit after hit — no interval",
      "Meet-the-cast programme available at the merchandise desk",
    ],
    tiers: [
      { id: "circle", name: "Upper Circle", description: "Elevated seating with a full view of the stage.", price: 350, availability: "Available", zone: "Upper" },
      { id: "stalls", name: "Stalls", description: "Ground-level seating in the heart of the theatre.", price: 550, availability: "Available", zone: "Stalls" },
      { id: "royal", name: "Royal Box", description: "An exclusive box for two with interval refreshments.", price: 790, availability: "Few left", zone: "Box" },
    ],
    runNote: "Limited season: 14 May – 30 July 2027",
  },
  {
    slug: "rocking-the-daisies-2026",
    title: "Rocking the Daisies 2026",
    artist: "SA's most-loved music & lifestyle festival",
    category: "Festivals",
    tagline: "Four days. Five stages. One beautiful farm.",
    description: [
      "Rocking the Daisies returns to Cloof Wine Estate with its most ambitious line-up yet. Four days of music, comedy, food and good people, with more than 60 acts spread across five stages and a late-night electronic forest.",
      "Camping and glamping packages include secure sites, hot showers and shuttle access. The festival holds a leave-no-trace pledge, so bring your best energy and your reusable cup.",
    ],
    venueKey: "cloof-wine-estate",
    date: "2027-10-01T12:00:00+02:00",
    time: "12:00",
    doors: "10:00",
    priceFrom: 1295,
    priceTo: 3450,
    imageId: 14267300,
    trending: true,
    badge: "Bucket list",
    status: "On sale",
    soldPercent: 62,
    age: "All ages · under 18 with guardian",
    duration: "4 days",
    organiser: "Daisies Productions",
    lineup: ["60+ artists across five stages", "A-Reece", "Mahalia", "Sunset Stage DJs"],
    highlights: [
      "Four nights of camping under the stars",
      "Five stages, 60+ acts and a comedy tent",
      "Complimentary shuttle from Cape Town CBD",
    ],
    tiers: [
      { id: "day", name: "Single Day Pass", description: "Access to all stages and food trucks for one day.", price: 1295, availability: "Available", zone: "Festival" },
      { id: "weekend", name: "Weekend Pass", description: "Friday to Sunday access, including the campsite.", price: 1995, availability: "Available", zone: "Festival" },
      { id: "glamping", name: "Sundowner Glamping", description: "Pre-pitched luxury tent for two with bedding and showers.", price: 3450, availability: "Few left", zone: "Glamping" },
    ],
    runNote: "Gates open 1–4 October 2027",
  },
  {
    slug: "marc-lottering-wife-other-husband",
    title: "My Wife's Other Husband",
    artist: "Marc Lottering",
    category: "Comedy",
    tagline: "One couch. Two husbands. Zero decorum.",
    description: [
      "Marc Lottering is back with a brand-new comedy about the beautifully messy business of family. When Ben discovers that his wife has another husband — a very nice man, apparently — he decides the only sensible thing to do is invite him over for the weekend.",
      "Expect Lottering's signature warmth, whip-smart observations and at least one story about a braai that goes spectacularly wrong. A slick, feel-good evening out at the Artscape.",
    ],
    venueKey: "artscape",
    date: "2027-01-23T20:00:00+02:00",
    time: "20:00",
    doors: "19:15",
    priceFrom: 280,
    priceTo: 520,
    imageId: 7991579,
    badge: "Cape Town exclusive",
    status: "On sale",
    soldPercent: 54,
    age: "13+",
    duration: "95 minutes",
    organiser: "Lottering Live",
    lineup: ["Marc Lottering", "Special guest: Mel Jones"],
    highlights: [
      "A brand-new one-man comedy written by Marc Lottering",
      "Cape Town season only — 12 nights",
      "Includes a post-show Q&A on 23 January",
    ],
    tiers: [
      { id: "balcony", name: "Balcony", description: "Upper-level seating with a full view of the stage.", price: 280, availability: "Available", zone: "Upper" },
      { id: "stalls", name: "Stalls", description: "Ground-level seating in the centre of the action.", price: 380, availability: "Available", zone: "Stalls" },
      { id: "premium", name: "Premium Closer", description: "Front stalls with extra legroom and a show programme.", price: 520, availability: "Few left", zone: "Front" },
    ],
  },
  {
    slug: "cape-town-jazz-festival-2027",
    title: "Cape Town International Jazz Festival",
    artist: "A gathering of jazz royalty",
    category: "Festivals",
    tagline: "Two nights of the world's finest jazz.",
    description: [
      "The Mother City's flagship jazz weekend returns with a programme that moves from late-night bebop to future soul. Five stages bring together South African greats and international headliners under one roof at the CTICC.",
      "The full line-up drops in September. Subscribe to the OpenTickets newsletter for first access to the early-bird tiers and the official festival after-parties.",
    ],
    venueKey: "cticc",
    date: "2027-03-27T16:00:00+02:00",
    time: "16:00",
    doors: "15:00",
    priceFrom: 695,
    priceTo: 1850,
    imageId: 9418653,
    trending: true,
    badge: "Early bird",
    status: "On sale",
    soldPercent: 41,
    age: "18+",
    duration: "2 days",
    organiser: "espAfrika",
    lineup: ["Full programme announced in September", "Five stages · 40+ acts", "Late-night after-party programme"],
    highlights: [
      "40+ local and international acts",
      "Early-bird pricing available until 31 December",
      "Official after-party access for VIP ticket holders",
    ],
    tiers: [
      { id: "single", name: "Single Day", description: "One day across all five festival stages.", price: 695, availability: "Available", zone: "Festival" },
      { id: "weekend", name: "Weekend Pass", description: "Friday and Saturday access to all stages.", price: 1150, availability: "Available", zone: "Festival" },
      { id: "vip", name: "VIP Gold", description: "Weekend access, private lounge, fast track and welcome drink.", price: 1850, availability: "Few left", zone: "VIP" },
    ],
    runNote: "27–28 March 2027 · CTICC, Cape Town",
  },
  {
    slug: "mzansi-ballet-romeo-juliet",
    title: "Romeo & Juliet — A New Ballet",
    artist: "Ballet Cape & The Mzansi Orchestra",
    category: "Theatre",
    tagline: "The greatest love story, reimagined.",
    description: [
      "Ballet Cape presents a bold new staging of Shakespeare's timeless tragedy, set to a live performance of Prokofiev's soaring score by The Mzansi Orchestra. Verona becomes a sun-drenched Cape Town, and the familiar story finds new urgency.",
      "This production pairs world-class choreography with costume design from one of South Africa's most exciting young ateliers. A limited run of eight performances only.",
    ],
    venueKey: "joburg-theatre",
    date: "2027-02-24T19:00:00+02:00",
    time: "19:00",
    doors: "18:15",
    priceFrom: 260,
    priceTo: 620,
    imageId: 1719936,
    badge: "Live orchestra",
    status: "On sale",
    soldPercent: 47,
    age: "All ages",
    duration: "2 hours 20 minutes, one interval",
    organiser: "Ballet Cape",
    lineup: ["Ballet Cape Company", "The Mzansi Orchestra", "Choreography: David Sonnenberg"],
    highlights: [
      "Prokofiev's score performed live by a 40-piece orchestra",
      "Eight performances only",
      "Post-show talk with the company on 27 February",
    ],
    tiers: [
      { id: "balcony", name: "Balcony", description: "Upper-level seating with a sweeping view of the stage.", price: 260, availability: "Available", zone: "Upper" },
      { id: "stalls", name: "Stalls", description: "Ground-level seats with premium sightlines.", price: 420, availability: "Available", zone: "Stalls" },
      { id: "box", name: "Ballet Box", description: "A private box for two with interval drinks.", price: 620, availability: "Few left", zone: "Box" },
    ],
    runNote: "24 February – 7 March 2027",
  },
  {
    slug: "afropunk-joburg",
    title: "Afropunk Joburg",
    artist: "A celebration of Black culture & sound",
    category: "Festivals",
    tagline: "Where culture finds its people.",
    description: [
      "Afropunk returns to Constitution Hill with a line-up that spans alternative soul, amapiano, hip-hop and experimental performance. More than a concert, it's a gathering of the creatively fearless — with a marketplace of local makers, artist talks and a sunset headline set.",
      "Bring comfortable shoes, sunscreen and an open mind. The site is fully accessible and there are plentiful shaded spaces and food options throughout.",
    ],
    venueKey: "constitution-hill",
    date: "2027-04-03T12:00:00+02:00",
    time: "12:00",
    doors: "11:00",
    priceFrom: 795,
    priceTo: 1250,
    imageId: 39004762,
    badge: "Culture pick",
    status: "On sale",
    soldPercent: 58,
    age: "18+",
    duration: "1 day",
    organiser: "Afropunk SA",
    lineup: ["Headliners to be announced", "12+ local acts", "Marketplace of 60 makers"],
    highlights: [
      "Music across two stages, from midday to late",
      "Local makers' marketplace and food village",
      "Artist conversations and performance art all day",
    ],
    tiers: [
      { id: "general", name: "General Admission", description: "Access to all music, marketplace and food areas.", price: 795, availability: "Available", zone: "Festival" },
      { id: "vip", name: "Gold Circle", description: "Fast-track entry, elevated deck and dedicated bar.", price: 1250, availability: "Few left", zone: "VIP" },
    ],
  },
  {
    slug: "franschhoek-uncorked",
    title: "Franschhoek Uncorked",
    artist: "The valley's finest estates, open wide",
    category: "Festivals",
    tagline: "A weekend of extraordinary wine and food.",
    description: [
      "For one golden weekend, Franschhoek's most celebrated estates throw open their cellar doors for extraordinary tastings, long lunches and live music on the lawns. A hop-on-hop-off shuttle connects every venue, so everyone can enjoy the valley at their own pace.",
      "Your pass includes a tasting glass, a festival map and access to the Saturday evening harvest table at the town square.",
    ],
    venueKey: "franschhoek",
    date: "2026-11-07T11:00:00+02:00",
    time: "11:00",
    doors: "10:30",
    priceFrom: 395,
    priceTo: 695,
    imageId: 20151743,
    badge: "Weekend escape",
    status: "On sale",
    soldPercent: 66,
    age: "18+ (wine tasting)",
    duration: "2 days",
    organiser: "Franschhoek Wine Valley",
    lineup: ["Bellingham Estate", "La Motte", "Stony Brook", "20+ participating estates"],
    highlights: [
      "A tasting glass and estate pass on arrival",
      "Hop-on-hop-off shuttles between all estates",
      "Exclusive cellar-door tastings and food pairings",
    ],
    tiers: [
      { id: "day", name: "Saturday Pass", description: "One day of tastings, shuttles and the harvest table.", price: 395, availability: "Available", zone: "Wine pass" },
      { id: "weekend", name: "Weekend Pass", description: "Both days of tasting, shuttles and priority entry.", price: 695, availability: "Available", zone: "Wine pass" },
    ],
    runNote: "7–8 November 2026 · Franschhoek Wine Valley",
  },
  {
    slug: "zakes-bantwini-symphonic",
    title: "The Symphonic Experience",
    artist: "Zakes Bantwini with the Cape Philharmonic",
    category: "Music",
    tagline: "His greatest songs. A full symphony orchestra.",
    description: [
      "Grammy-winner Zakes Bantwini reimagines his catalogue for a 36-piece symphony orchestra in one extraordinary night. Osama, String Lullaby and new works come to life with sweeping strings, a full choir and a band assembled from South Africa's finest session players.",
      "This is a black-tie-optional evening at Artscape — arrive early for the pre-concert conversation with the conductor in the Opera Bar.",
    ],
    venueKey: "artscape",
    date: "2027-01-30T19:30:00+02:00",
    time: "19:30",
    doors: "18:30",
    priceFrom: 495,
    priceTo: 1100,
    imageId: 7763042,
    badge: "One night only",
    status: "Few left",
    soldPercent: 79,
    age: "All ages",
    duration: "1 hour 50 minutes",
    organiser: "OpenTickets Sessions",
    lineup: ["Zakes Bantwini", "Cape Philharmonic Orchestra", "Cape Town Gospel Choir"],
    highlights: [
      "A 36-piece orchestra and 30-voice choir",
      "Pre-concert conversation with the conductor",
      "Brand-new orchestral arrangements of his greatest hits",
    ],
    tiers: [
      { id: "balcony", name: "Balcony", description: "Upper-level seating with a full view of the orchestra.", price: 495, availability: "Available", zone: "Upper" },
      { id: "stalls", name: "Stalls", description: "Excellent ground-level seats close to the stage.", price: 795, availability: "Few left", zone: "Stalls" },
      { id: "premium", name: "Premium Front", description: "Front stalls, a programme and post-show drinks.", price: 1100, availability: "Few left", zone: "Front" },
    ],
  },
  {
    slug: "riaad-moosa-still-standing",
    title: "Riaad Moosa: Still Standing",
    artist: "Riaad Moosa",
    category: "Comedy",
    tagline: "The doctor is in. And he has notes.",
    description: [
      "Riaad Moosa returns with a new hour about family, fatherhood and the state of absolutely everything. Warm, wise and reliably hilarious, Riaad's newest show is a reminder of why he remains one of the country's most beloved comics.",
      "The late show is strictly 18+. The theatre bar is open from 18:30, and no alcohol is permitted inside the auditorium.",
    ],
    venueKey: "theatre-on-the-bay",
    date: "2026-11-20T20:00:00+02:00",
    time: "20:00",
    doors: "19:00",
    priceFrom: 250,
    priceTo: 495,
    imageId: 2101487,
    trending: true,
    badge: "Late show",
    status: "Final release",
    soldPercent: 84,
    age: "18+",
    duration: "75 minutes",
    organiser: "Comedy at the Bay",
    lineup: ["Riaad Moosa", "Support act announced on the night"],
    highlights: [
      "A brand-new, never-before-performed hour",
      "Intimate 220-seat theatre — no bad seat",
      "Oceanside sundowners before curtain-up",
    ],
    tiers: [
      { id: "standard", name: "Theatre Seat", description: "General reserved seating in the intimate theatre.", price: 250, availability: "Available", zone: "Stalls" },
      { id: "premium", name: "Front Table", description: "A front table for two with a welcome drink.", price: 495, availability: "Few left", zone: "Front" },
    ],
  },
];

export const CATEGORIES: { label: Category; icon: string; description: string; imageId: number }[] = [
  { label: "Music", icon: "music", description: "Live bands, DJs and once-in-a-lifetime sessions.", imageId: 14429344 },
  { label: "Comedy", icon: "mic", description: "The country's funniest voices, up close.", imageId: 10078868 },
  { label: "Theatre", icon: "drama", description: "West End spectacle and homegrown brilliance.", imageId: 6899772 },
  { label: "Festivals", icon: "sparkles", description: "Long weekends, big stages, beautiful people.", imageId: 14267300 },
];

export const getEvent = (slug: string) => EVENTS.find((event) => event.slug === slug);
export const getVenue = (event: EventItem) => VENUES[event.venueKey] ?? VENUES.artscape;
export const categoryCount = (category: Category | "All") =>
  category === "All" ? EVENTS.length : EVENTS.filter((event) => event.category === category).length;

const longDate = new Intl.DateTimeFormat("en-ZA", {
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
  timeZone: "Africa/Johannesburg",
});

const shortDate = new Intl.DateTimeFormat("en-ZA", {
  weekday: "short",
  day: "numeric",
  month: "short",
  timeZone: "Africa/Johannesburg",
});

const dayNumber = new Intl.DateTimeFormat("en-ZA", { day: "2-digit", timeZone: "Africa/Johannesburg" });
const monthShort = new Intl.DateTimeFormat("en-ZA", { month: "short", timeZone: "Africa/Johannesburg" });

export const formatEventDate = (iso: string) => longDate.format(new Date(iso)).replace(/,/g, "");
export const formatShortDate = (iso: string) => shortDate.format(new Date(iso)).replace(/,/g, "");
export const getDateBadge = (iso: string) => ({
  day: dayNumber.format(new Date(iso)),
  month: monthShort.format(new Date(iso)).toUpperCase(),
});

export const formatZAR = (value: number) =>
  `R${value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const formatZARShort = (value: number) => `R${value.toLocaleString("en-US")}`;

export const agePolicy = (event: EventItem) =>
  event.age.includes("18")
    ? "This event is strictly for guests 18 years and older. A valid ID may be requested at the entrance."
    : `This event is rated ${event.age}. Guests under 16 must be accompanied by an adult.`;

export const eventTerms = (event: EventItem) => [
  `All ticket sales are final. Tickets may be transferred once through your OpenTickets account, but not later than 48 hours before the event.`,
  agePolicy(event),
  `Please arrive at least 30 minutes before ${event.time}. Latecomers may be admitted at a suitable break at the venue's discretion.`,
  `Professional cameras, recording equipment, glass bottles and outside food or drinks are not permitted.`,
  `The organiser reserves the right to make changes to the line-up where necessary. Refunds are not issued for partial performances or line-up changes.`,
];

export const eventFaqs = (event: EventItem) => {
  const venue = getVenue(event);
  return [
    {
      q: "How will I receive my tickets?",
      a: "Your e-tickets are issued instantly after payment and are available in your OpenTickets account. Each ticket has a unique QR code that is scanned at the door — you can show it on your phone or print it at home.",
    },
    {
      q: "Can I choose my seats?",
      a:
        event.category === "Festivals"
          ? "This is a general admission festival. Your ticket grants access to the festival grounds; seating is not allocated. VIP and glamping guests should follow the dedicated signage on arrival."
          : `Tickets are sold by seating zone. Select your preferred tier when booking and you'll receive the best available seats within that zone. For accessible seating, contact support@opentickets.co.za before the show.`,
    },
    {
      q: "What time should I arrive?",
      a: `Doors open at ${event.doors} and the performance starts at ${event.time}. We recommend arriving early to find parking, enjoy a drink at the venue bar and settle in without rushing.`,
    },
    {
      q: "What is the weather policy?",
      a:
        venue.key === "kirstenbosch" || venue.key === "cloof-wine-estate"
          ? "Events proceed in light rain. In the event of severe weather, the organiser will communicate any changes via email and social media no later than 12 hours before doors. Bring a rain poncho and warm layers."
          : "This is an indoor event and will proceed as scheduled in all weather conditions.",
    },
    {
      q: "Will there be food and drinks?",
      a:
        event.category === "Festivals"
          ? "A curated selection of food traders, coffee, and alcoholic and non-alcoholic drinks will be available. All festival bars accept card payments."
          : "The venue bar and café will be open from doors. Only card payments are accepted. No outside food or beverages, except for necessary dietary items.",
    },
  ];
};
