# OpenTickets

A premium, conversion-focused ticketing experience for `opentickets.co.za` — built with React, Vite, TypeScript and Tailwind CSS v4. Every screen is responsive from 320px up and all buying flows are functional in-browser.

## Run

```bash
npm install
npm run dev
npm run build
```

## Routes

The app uses a hash router so it can be served as a single static file.

| Route | Screen |
| --- | --- |
| `#/` | Home — immersive hero, live search, filterable event grid, categories |
| `#/events` | Full event collection with advanced filters, sort and grid/list views |
| `#/search` | Search results; supports `?q=`, `?city=`, `?category=` and `?when=` |
| `#/events/:slug` | Event detail, line-up, venue, schedule, terms, event FAQs and sticky booking |
| `#/faqs` | Searchable, categorised FAQ hub and support channels |

## Project structure

```
src/
  data/            Realistic South African event, venue and FAQ content
  lib/router.tsx   Lightweight hash router with <Link /> and useRouter()
  context/         Cart, saved events, account, orders, overlays and toasts
  components/
    layout/        Header, Footer
    events/        EventCard, EventExplorer (Isotope-style FLIP grid)
    search/        FilterPanel, EventListItem
    event-detail/  BookingCard, SeatMap
    overlays/      Search, Cart, Auth, Checkout, Toast
    ui/            Button, Logo, Reveal, Accordion
  pages/           HomePage, SearchPage, EventDetailPage, FaqsPage
  styles tokens    src/index.css (`:root` + Tailwind `@theme inline`)
```

## Design tokens

All visual language is centralised in `src/index.css`. Change these values to retheme the whole product — no component changes required.

```css
--ot-ink: #070b12;         /* page background        */
--ot-midnight: #0b111b;    /* overlays / panels      */
--ot-surface: #101824;     /* cards                  */
--ot-cream: #f5f0e6;       /* primary text           */
--ot-gold: #e4c78e;        /* primary accent         */
--ot-coral: #ef8a6d;       /* urgency / few left     */
--ot-violet: #9481ef;      /* theatre accent         */
--ot-sage: #92b9a4;        /* success / availability */
--ot-font-display: "Instrument Serif", serif;
--ot-font-sans: "Manrope", sans-serif;
```

Tokens are also exposed as Tailwind utilities through `@theme inline` (for example `bg-ink`, `text-gold`, `border-line`, `font-display`). Spacing, radii, shadows and easing live in the same block (`--ot-section-y`, `--ot-radius-*`, `--ot-shadow-*`, `--ot-ease`).

## Key interaction notes

- **Filterable events grid:** `EventExplorer` captures card positions before filtering and replays the difference with the Web Animations API, giving smooth FLIP transitions without external libraries.
- **Cart & checkout:** selections persist in `localStorage`. Checkout validates guest details and card fields, generates a booking reference, clears the cart, and offers a downloadable `.ics` calendar file.
- **Search:** every header search, hero search, sidebar filter, sort option and view toggle reads/writes real state; results include empty states and active filter chips.
- **Accessibility:** semantic landmarks, labelled controls, keyboard-accessible overlays (Escape closes), focus-visible rings and a skip link. Motion respects `prefers-reduced-motion`.

## Extending: interactive seating maps

`src/components/event-detail/SeatMap.tsx` is intentionally isolated behind a small contract so a production seat-map provider (or a bespoke SVG map) can replace the zone preview without touching the booking flow:

```ts
interface SeatMapProps {
  tiers: EventTier[];
  selectedId: string;
  onSelect: (tier: EventTier) => void;
}
```

Keep `EventTier.id` as the single source of truth between the map, pricing tiers and cart line items. A full seat-level map can be added as a lazy-loaded modal, emitting `{ tierId, seatIds }` while leaving `BookingCard` and the cart untouched.

## Assets

Event photography is served from Pexels CDN URLs, referenced by photo ID in `src/data/events.ts`. Replace `eventImage()` with the client's DAM/CDN when integrating. Typography is loaded from Google Fonts in `index.html`.

## Notes

Checkout is a realistic, fully validated prototype and does not charge a card. Wire the `placeOrder` method in `src/context/AppContext.tsx` to the production payment and ticketing API (PayFast, SnapScan or Stripe) to go live.
